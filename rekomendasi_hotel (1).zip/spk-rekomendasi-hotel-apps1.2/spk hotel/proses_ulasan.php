<?php
include 'koneksi.php'; // Pastikan file ini menghubungkan ke database

// Cek apakah form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $hotel_id = $_POST['hotel_id'] ?? null;
    $rating_bintang = $_POST['rating_bintang'] ?? null;
    $ulasan = $_POST['ulasan'] ?? '';
    $terverifikasi = isset($_POST['terverifikasi']) ? 1 : 0;
    $tanggal_ulasan = date('Y-m-d H:i:s');

    // Validasi sederhana
    if (!$hotel_id || !$rating_bintang || empty($ulasan)) {
        echo "<script>alert('Semua data harus diisi.');history.back();</script>";
        exit;
    }

    // Siapkan query untuk simpan data ulasan
    $stmt = $conn->prepare("INSERT INTO ulasan (hotel_id, rating_bintang, ulasan, terverifikasi, tanggal_ulasan)
                            VALUES (?, ?, ?, ?, ?)");
    if ($stmt === false) {
        echo "<script>alert('Gagal menyiapkan query.');history.back();</script>";
        exit;
    }

    // Bind parameter (i = integer, s = string)
    $stmt->bind_param("iisis", $hotel_id, $rating_bintang, $ulasan, $terverifikasi, $tanggal_ulasan);

    // Eksekusi query
    if ($stmt->execute()) {
        echo "<script>alert('Ulasan berhasil disimpan!'); window.location.href = 'detail_hotel.php?id=$hotel_id';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan ulasan: " . $stmt->error . "'); history.back();</script>";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "<script>alert('Akses tidak valid.'); window.location.href = 'index.php';</script>";
}
