<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include 'koneksi.php';

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['nama_lengkap'];

// Get user's favorite hotels with SAW calculation
$sql = "SELECT 
    h.id,
    h.nama_hotel,
    h.alamat,
    h.harga_per_malam,
    h.rating_bintang,
    h.fasilitas,
    h.foto_utama,
    h.deskripsi,
    hcv1.nilai as harga_kriteria,
    hcv2.nilai as rating_kriteria,
    hcv3.nilai as jarak_km,
    (
        (150000 / hcv1.nilai * 0.40) +
        (hcv2.nilai / 5 * 0.35) +
        (0.5 / hcv3.nilai * 0.25)
    ) as saw_score,
    uf.created_at as favorited_at
FROM user_favorites uf
JOIN hotels h ON uf.hotel_id = h.id
LEFT JOIN hotel_criteria_values hcv1 ON h.id = hcv1.hotel_id AND hcv1.criteria_id = 1
LEFT JOIN hotel_criteria_values hcv2 ON h.id = hcv2.hotel_id AND hcv2.criteria_id = 2
LEFT JOIN hotel_criteria_values hcv3 ON h.id = hcv3.hotel_id AND hcv3.criteria_id = 3
WHERE uf.user_id = ? AND h.status = 'aktif'
ORDER BY uf.created_at DESC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$favorites = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Count total favorites
$total_favorites = count($favorites);

// Calculate average SAW score of favorites
$total_saw_score = 0;
if ($total_favorites > 0) {
    foreach ($favorites as $fav) {
        $total_saw_score += $fav['saw_score'];
    }
    $avg_saw_score = $total_saw_score / $total_favorites;
} else {
    $avg_saw_score = 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorit Saya - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/favorites.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
     <?php include "header.php" ?>

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="container">
            <nav class="breadcrumb-nav">
                <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
                <i class="fas fa-chevron-right"></i>
                <span>Favorit Saya</span>
            </nav>
        </div>
    </section>

    <!-- Favorites Content -->
    <section class="favorites-content">
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <div class="header-info">
                    <h1><i class="fas fa-heart"></i> Hotel Favorit Saya</h1>
                    <p>Kumpulan hotel pilihan terbaik yang telah Anda simpan</p>
                </div>
                <div class="favorites-stats">
                    <div class="stat-item">
                        <div class="stat-number"><?= $total_favorites ?></div>
                        <div class="stat-label">Total Favorit</div>
                    </div>
                    <?php if ($total_favorites > 0) { ?>
                    <div class="stat-item">
                        <div class="stat-number"><?= number_format($avg_saw_score, 2) ?></div>
                        <div class="stat-label">Rata-rata SAW Score</div>
                    </div>
                    <?php } ?>
                </div>
            </div>

            <?php if ($total_favorites > 0) { ?>
                <!-- Filter & Sort -->
                <div class="favorites-controls">
                    <div class="filter-section">
                        <label>Filter berdasarkan:</label>
                        <select id="filterRating" onchange="filterFavorites()">
                            <option value="">Semua Rating</option>
                            <option value="5">5 Bintang</option>
                            <option value="4">4 Bintang ke atas</option>
                            <option value="3">3 Bintang ke atas</option>
                        </select>
                        <select id="filterPrice" onchange="filterFavorites()">
                            <option value="">Semua Harga</option>
                            <option value="0-300000">Di bawah Rp 300.000</option>
                            <option value="300000-500000">Rp 300.000 - Rp 500.000</option>
                            <option value="500000-1000000">Di atas Rp 500.000</option>
                        </select>
                    </div>
                    <div class="sort-section">
                        <label>Urutkan:</label>
                        <select id="sortBy" onchange="sortFavorites()">
                            <option value="newest">Terbaru Ditambahkan</option>
                            <option value="oldest">Terlama Ditambahkan</option>
                            <option value="saw_high">SAW Score Tertinggi</option>
                            <option value="saw_low">SAW Score Terendah</option>
                            <option value="price_low">Harga Terendah</option>
                            <option value="price_high">Harga Tertinggi</option>
                            <option value="rating_high">Rating Tertinggi</option>
                        </select>
                    </div>
                </div>

                <!-- Favorites Grid -->
                <div class="favorites-grid" id="favoritesGrid">
                    <?php foreach ($favorites as $index => $hotel) { 
                        $fasilitas = explode(',', $hotel['fasilitas']);
                        
                        // Check for image
                        $foto_path = '';
                        if ($hotel['foto_utama']) {
                            $possible_paths = [
                                'assets/images/' . $hotel['foto_utama'],
                                $hotel['foto_utama']
                            ];
                            
                            foreach ($possible_paths as $path) {
                                if (file_exists($path)) {
                                    $foto_path = $path;
                                    break;
                                }
                            }
                        }
                    ?>
                        <div class="favorite-card" 
                             data-rating="<?= $hotel['rating_bintang'] ?>"
                             data-price="<?= $hotel['harga_per_malam'] ?>"
                             data-saw="<?= $hotel['saw_score'] ?>"
                             data-added="<?= strtotime($hotel['favorited_at']) ?>">
                            
                            <div class="card-header">
                                <div class="favorite-badge">
                                    <i class="fas fa-heart"></i>
                                    <span>Favorit #<?= $index + 1 ?></span>
                                </div>
                                <div class="saw-badge">
                                    <span>SAW</span>
                                    <strong><?= number_format($hotel['saw_score'], 3) ?></strong>
                                </div>
                            </div>

                            <div class="card-image">
                                <?php if (!empty($foto_path)) { ?>
                                    <img src="<?= $foto_path ?>" alt="<?= htmlspecialchars($hotel['nama_hotel']) ?>">
                                <?php } else { ?>
                                    <div class="default-image">
                                        <i class="fas fa-hotel"></i>
                                        <span><?= htmlspecialchars($hotel['nama_hotel']) ?></span>
                                    </div>
                                <?php } ?>
                                
                                <div class="image-overlay">
                                    <button class="btn-remove-favorite" onclick="removeFavorite(<?= $hotel['id'] ?>, this)" title="Hapus dari favorit">
                                        <i class="fas fa-heart-broken"></i>
                                    </button>
                                    <button class="btn-view-detail" onclick="window.location.href='detail_hotel.php?id=<?= $hotel['id'] ?>'" title="Lihat detail">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="card-content">
                                <div class="hotel-header">
                                    <h3><?= htmlspecialchars($hotel['nama_hotel']) ?></h3>
                                    <div class="rating">
                                        <?php for ($i = 1; $i <= 5; $i++) { ?>
                                            <i class="fas fa-star <?= $i <= $hotel['rating_bintang'] ? 'active' : '' ?>"></i>
                                        <?php } ?>
                                        <span><?= $hotel['rating_bintang'] ?> Bintang</span>
                                    </div>
                                </div>

                                <div class="location">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span><?= htmlspecialchars($hotel['alamat']) ?></span>
                                    <span class="distance">(<?= $hotel['jarak_km'] ?> km)</span>
                                </div>

                                <?php if (!empty($hotel['deskripsi'])) { ?>
                                <div class="description">
                                    <p><?= htmlspecialchars(substr($hotel['deskripsi'], 0, 100)) ?><?= strlen($hotel['deskripsi']) > 100 ? '...' : '' ?></p>
                                </div>
                                <?php } ?>

                                <div class="facilities">
                                    <?php foreach (array_slice($fasilitas, 0, 4) as $facility) { ?>
                                        <span class="facility-tag"><?= trim($facility) ?></span>
                                    <?php } ?>
                                    <?php if (count($fasilitas) > 4) { ?>
                                        <span class="facility-more">+<?= count($fasilitas) - 4 ?> lainnya</span>
                                    <?php } ?>
                                </div>

                                <div class="card-footer">
                                    <div class="price-section">
                                        <span class="price-amount">Rp <?= number_format($hotel['harga_per_malam'], 0, ',', '.') ?></span>
                                        <span class="price-unit">/malam</span>
                                    </div>
                                    <div class="favorite-date">
                                        <i class="fas fa-calendar-plus"></i>
                                        <span>Ditambahkan <?= date('d M Y', strtotime($hotel['favorited_at'])) ?></span>
                                    </div>
                                </div>

                                <!-- <div class="card-actions">
                                    <button class="btn-book" onclick="bookHotel(<?= $hotel['id'] ?>)">
                                        <i class="fas fa-calendar-check"></i>
                                        Pesan Sekarang
                                    </button>
                                    <button class="btn-compare" onclick="addToCompare(<?= $hotel['id'] ?>)">
                                        <i class="fas fa-balance-scale"></i>
                                        Bandingkan
                                    </button>
                                </div> -->
                            </div>
                        </div>
                    <?php } ?>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <h3>Aksi Cepat</h3>
                    <div class="action-buttons">
                        <button class="action-btn" onclick="clearAllFavorites()">
                            <i class="fas fa-trash-alt"></i>
                            <span>Hapus Semua Favorit</span>
                        </button>
                        <button class="action-btn" onclick="shareFavorites()">
                            <i class="fas fa-share-alt"></i>
                            <span>Bagikan Favorit</span>
                        </button>
                        <button class="action-btn" onclick="window.location.href='index.php#hotels'">
                            <i class="fas fa-plus"></i>
                            <span>Tambah Hotel Lain</span>
                        </button>
                    </div>
                </div>

            <?php } else { ?>
                <!-- Empty State -->
                <div class="empty-favorites">
                    <div class="empty-icon">
                        <i class="fas fa-heart-broken"></i>
                    </div>
                    <h2>Belum Ada Hotel Favorit</h2>
                    <p>Anda belum menambahkan hotel apapun ke daftar favorit. Jelajahi hotel-hotel terbaik dan simpan yang Anda sukai!</p>
                    
                    <div class="empty-actions">
                        <a href="index.php#hotels" class="btn-explore">
                            <i class="fas fa-search"></i>
                            Jelajahi Hotel
                        </a>
                        <a href="index.php#about" class="btn-learn">
                            <i class="fas fa-info-circle"></i>
                            Pelajari Metode SAW
                        </a>
                    </div>

                    <div class="tips-section">
                        <h4>💡 Tips Menggunakan Favorit:</h4>
                        <ul>
                            <li>Klik ikon ❤️ di kartu hotel untuk menambahkan ke favorit</li>
                            <li>Bandingkan SAW score untuk memilih hotel terbaik</li>
                            <li>Filter berdasarkan harga dan rating sesuai kebutuhan</li>
                            <li>Gunakan fitur perbandingan untuk analisis lebih detail</li>
                        </ul>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-hotel"></i>
                        <span>SPK Hotel Mataram</span>
                    </div>
                    <p>Sistem Pendukung Keputusan untuk rekomendasi hotel terbaik di Kota Mataram menggunakan metode SAW.</p>
                </div>
                <div class="footer-section">
                    <h4>Kontak</h4>
                    <p><i class="fas fa-map-marker-alt"></i> Mataram, Nusa Tenggara Barat</p>
                    <p><i class="fas fa-envelope"></i> info@spkhotel.com</p>
                    <p><i class="fas fa-phone"></i> +62 370 123456</p>
                </div>
                <div class="footer-section">
                    <h4>Link Cepat</h4>
                    <ul>
                        <li><a href="index.php">Beranda</a></li>
                        <li><a href="index.php#hotels">Hotel</a></li>
                        <li><a href="index.php#about">Tentang SAW</a></li>
                        <li><a href="profile.php">Profil</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 SPK Hotel Mataram. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Toggle user dropdown
        function toggleUserDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');
            
            if (userMenu && !userMenu.contains(event.target)) {
                dropdown?.classList.remove('show');
            }
        });

        // Remove from favorites
        function removeFavorite(hotelId, button) {
            if (confirm('Apakah Anda yakin ingin menghapus hotel ini dari favorit?')) {
                const card = button.closest('.favorite-card');
                
                fetch('ajax/remove_favorite.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        hotel_id: hotelId,
                        user_id: <?= $user_id ?>
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Animate card removal
                        card.style.transform = 'scale(0.8)';
                        card.style.opacity = '0';
                        
                        setTimeout(() => {
                            card.remove();
                            checkEmptyFavorites();
                            updateStats();
                        }, 300);
                        
                        showNotification('Hotel berhasil dihapus dari favorit', 'success');
                    } else {
                        showNotification('Gagal menghapus dari favorit: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Terjadi kesalahan saat menghapus favorit', 'error');
                });
            }
        }

        // Filter favorites
        function filterFavorites() {
            const ratingFilter = document.getElementById('filterRating').value;
            const priceFilter = document.getElementById('filterPrice').value;
            const cards = document.querySelectorAll('.favorite-card');

            cards.forEach(card => {
                let show = true;

                // Rating filter
                if (ratingFilter) {
                    const cardRating = parseInt(card.dataset.rating);
                    if (cardRating < parseInt(ratingFilter)) {
                        show = false;
                    }
                }

                // Price filter
                if (priceFilter && show) {
                    const cardPrice = parseInt(card.dataset.price);
                    const [minPrice, maxPrice] = priceFilter.split('-').map(p => parseInt(p));
                    
                    if (maxPrice) {
                        if (cardPrice < minPrice || cardPrice > maxPrice) {
                            show = false;
                        }
                    } else {
                        if (cardPrice < minPrice) {
                            show = false;
                        }
                    }
                }

                card.style.display = show ? 'block' : 'none';
            });
        }

        // Sort favorites
        function sortFavorites() {
            const sortBy = document.getElementById('sortBy').value;
            const grid = document.getElementById('favoritesGrid');
            const cards = Array.from(grid.children);

            cards.sort((a, b) => {
                switch (sortBy) {
                    case 'newest':
                        return parseInt(b.dataset.added) - parseInt(a.dataset.added);
                    case 'oldest':
                        return parseInt(a.dataset.added) - parseInt(b.dataset.added);
                    case 'saw_high':
                        return parseFloat(b.dataset.saw) - parseFloat(a.dataset.saw);
                    case 'saw_low':
                        return parseFloat(a.dataset.saw) - parseFloat(b.dataset.saw);
                    case 'price_low':
                        return parseInt(a.dataset.price) - parseInt(b.dataset.price);
                    case 'price_high':
                        return parseInt(b.dataset.price) - parseInt(a.dataset.price);
                    case 'rating_high':
                        return parseInt(b.dataset.rating) - parseInt(a.dataset.rating);
                    default:
                        return 0;
                }
            });

            cards.forEach(card => grid.appendChild(card));
        }

        // Check if favorites is empty after removal
        function checkEmptyFavorites() {
            const remainingCards = document.querySelectorAll('.favorite-card').length;
            if (remainingCards === 0) {
                location.reload(); // Reload to show empty state
            }
        }

        // Update statistics
        function updateStats() {
            const cards = document.querySelectorAll('.favorite-card');
            const totalCards = cards.length;
            
            if (totalCards > 0) {
                let totalSAW = 0;
                cards.forEach(card => {
                    totalSAW += parseFloat(card.dataset.saw);
                });
                const avgSAW = (totalSAW / totalCards).toFixed(2);
                
                document.querySelector('.stat-number').textContent = totalCards;
                if (document.querySelectorAll('.stat-item')[1]) {
                    document.querySelectorAll('.stat-item')[1].querySelector('.stat-number').textContent = avgSAW;
                }
            }
        }

        // Quick actions
        function clearAllFavorites() {
            if (confirm('Apakah Anda yakin ingin menghapus SEMUA hotel dari favorit? Tindakan ini tidak dapat dibatalkan.')) {
                const hotelIds = Array.from(document.querySelectorAll('.favorite-card')).map(card => {
                    return card.querySelector('.btn-remove-favorite').onclick.toString().match(/removeFavorite\((\d+)/)[1];
                });

                // Remove all favorites via AJAX
                Promise.all(hotelIds.map(id => 
                    fetch('ajax/remove_favorite.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ hotel_id: parseInt(id), user_id: <?= $user_id ?> })
                    })
                )).then(() => {
                    showNotification('Semua favorit berhasil dihapus', 'success');
                    setTimeout(() => location.reload(), 1000);
                }).catch(() => {
                    showNotification('Terjadi kesalahan saat menghapus favorit', 'error');
                });
            }
        }

        function exportFavorites() {
            showNotification('Fitur export PDF akan segera hadir!', 'info');
        }

        function shareFavorites() {
            if (navigator.share) {
                navigator.share({
                    title: 'Hotel Favorit Saya - SPK Hotel Mataram',
                    text: 'Lihat daftar hotel favorit saya di SPK Hotel Mataram',
                    url: window.location.href
                });
            } else {
                // Fallback: copy to clipboard
                navigator.clipboard.writeText(window.location.href).then(() => {
                    showNotification('Link favorit berhasil disalin!', 'success');
                });
            }
        }

        function bookHotel(hotelId) {
            showNotification('Fitur pemesanan akan segera hadir!', 'info');
        }

        function addToCompare(hotelId) {
            showNotification('Fitur perbandingan hotel akan segera hadir!', 'info');
        }

        // Show notification
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => notification.classList.add('show'), 100);
            
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => document.body.removeChild(notification), 300);
            }, 3000);
        }
    </script>
</body>
</html>