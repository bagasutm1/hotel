<?php
// koneksi.php
$host = "localhost";
$username = "root";
$password = "";
$database = "spk_rekomendasi_hotel1_2";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>