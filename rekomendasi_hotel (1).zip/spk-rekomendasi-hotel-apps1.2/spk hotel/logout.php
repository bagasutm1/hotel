<?php
// logout.php
session_start();

// Hapus semua session
session_unset();
session_destroy();

// Hapus cookie jika ada
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-3600, '/');
}

// Redirect ke halaman login atau index
if (isset($_GET['redirect']) && $_GET['redirect'] === 'login') {
    header('Location: login.php');
} else {
    header('Location: index.php');
}
exit();
?>