<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$order_id = $_GET['order_id'] ?? 0;
$user_id = $_SESSION['user_id'];

// Ambil data order
$sql = "SELECT o.*, h.nama_hotel, h.harga_per_malam FROM orders o JOIN hotels h ON o.hotel_id = h.id WHERE o.id = ? AND o.user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($result);

if (!$order) {
    echo "<script>alert('Data pesanan tidak ditemukan.'); window.location.href='my_order.php';</script>";
    exit();
}

// Proses Submit Form Pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $metode_bayar = $_POST['metode_bayar'];
    $bukti = $_FILES['bukti_bayar'];
    $fileName = '';

    if ($bukti && $bukti['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
        $ext = pathinfo($bukti['name'], PATHINFO_EXTENSION);
        if (in_array(strtolower($ext), $allowed)) {
            $fileName = uniqid() . '.' . $ext;
            move_uploaded_file($bukti['tmp_name'], 'uploads/' . $fileName);
        } else {
            $error = "Format bukti harus JPG/PNG/PDF.";
        }
    } else {
        $error = "Wajib unggah bukti pembayaran.";
    }

    if (empty($error)) {
        // Di dalam blok POST, gunakan ini:
        $update = "UPDATE orders SET status = 'diproses', metode_bayar = ?, bukti_bayar = ? WHERE id = ? AND user_id = ?";
        $upstmt = mysqli_prepare($conn, $update);
        mysqli_stmt_bind_param($upstmt, "ssii", $metode_bayar, $fileName, $order_id, $user_id);
        mysqli_stmt_execute($upstmt);

        echo "<script>alert('Pembayaran berhasil!'); window.location.href='my_order.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Pembayaran - SPK Hotel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container py-5">
        <div class="card shadow-lg border-0 mx-auto" style="max-width: 700px;">
            <div class="card-header bg-primary text-white text-center py-3 rounded-top">
                <h4 class="mb-0"><i class="fas fa-money-check-alt me-2"></i>Pembayaran Pesanan</h4>
            </div>
            <div class="card-body px-4 py-5">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <!-- Info Pesanan -->
                <div class="mb-4">
                    <h5 class="fw-bold mb-2"><?= htmlspecialchars($order['nama_hotel']) ?></h5>
                    <p class="mb-1"><strong>Jumlah Kamar:</strong> <?= $order['jumlah_kamar'] ?></p>
                    <p class="mb-1"><strong>Harga per Malam:</strong> Rp <?= number_format($order['harga_per_malam'], 0, ',', '.') ?></p>
                    <p><strong>Total Bayar:</strong>
                        <span class="text-success fw-bold fs-5">
                            Rp <?= number_format($order['jumlah_kamar'] * $order['harga_per_malam'], 0, ',', '.') ?>
                        </span>
                    </p>
                </div>

                <!-- Form Pembayaran -->
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="metode_bayar" class="form-label">Metode Pembayaran (Bank)</label>
                        <select name="metode_bayar" id="metode_bayar" class="form-select" required>
                            <option value="">-- Pilih Bank --</option>
                            <option value="BCA">BCA - 123456789</option>
                            <option value="BNI">BNI - 987654321</option>
                            <option value="BRI">BRI - 456789123</option>
                            <option value="Mandiri">Mandiri - 321456789</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="bukti_bayar" class="form-label">Upload Bukti Pembayaran</label>
                        <input type="file" name="bukti_bayar" id="bukti_bayar" class="form-control" accept=".jpg,.jpeg,.png,.pdf" required>
                    </div>

                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-check-circle"></i> Konfirmasi Pembayaran
                    </button>
                </form>

                <div class="text-center mt-4">
                    <a href="my_order.php" class="btn btn-outline-secondary">← Kembali ke Riwayat</a>
                </div>

            </div>
        </div>
    </div>

</body>

</html>