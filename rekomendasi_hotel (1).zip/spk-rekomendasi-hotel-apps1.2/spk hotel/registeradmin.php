<?php
include 'koneksi.php';

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $nama = $_POST['nama_lengkap'];

    // hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "IINSERT INTO users (nama_lengkap, email, password, role)
VALUES (?, ?, ?, 'admin'";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssss",
        $username,
        $email,
        $password_hash,
        $nama
    );

    if (mysqli_stmt_execute($stmt)) {
        echo "Admin berhasil didaftarkan";
    } else {
        echo "Register admin gagal";
    }
}
