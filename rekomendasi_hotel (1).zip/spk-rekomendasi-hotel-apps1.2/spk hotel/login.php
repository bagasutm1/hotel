<?php
session_start();
include 'koneksi.php';

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error_message = 'Email dan password harus diisi!';
    } else {
       $login_type = $_POST['login_type']; // user / admin

$sql = "SELECT * FROM users WHERE email = ? AND role = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ss", $email, $login_type);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
        if ($user = mysqli_fetch_assoc($result)) {
           if (password_verify($password, $user['password'])) {

    $_SESSION['role'] = $user['role'];
    $_SESSION['nama_lengkap'] = $user['nama_lengkap'];

    if ($user['role'] === 'admin') {
        $_SESSION['admin_id'] = $user['id'];
        header("Location: admin/dashboard.php");
    } else {
        $_SESSION['user_id'] = $user['id'];
        header("Location: index.php");
    }
    exit();





            } else {
                $error_message = 'Password salah!';
            }
        } else {
            $error_message = 'Email tidak ditemukan!';
        }
    }
}
?>



<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0194f3 0%, #0066cc 100%);
            padding: 20px;
        }

        .auth-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 450px;
            padding: 40px;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .auth-logo i {
            font-size: 2.5em;
            color: #0194f3;
        }

        .auth-logo span {
            font-size: 1.8em;
            font-weight: bold;
            color: #2c3e50;
        }

        .auth-title {
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .auth-subtitle {
            color: #6c757d;
            font-size: 1em;
        }

        .login-type-selector {
            display: flex;
            background: #f8f9fa;
            border-radius: 12px;
            padding: 4px;
            margin-bottom: 25px;
        }

        .login-type-btn {
            flex: 1;
            padding: 12px;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
            border: none;
            background: transparent;
            color: #6c757d;
        }

        .login-type-btn.active {
            background: white;
            color: #0194f3;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e50;
            font-weight: 500;
        }

        .form-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-input:focus {
            outline: none;
            border-color: #0194f3;
            box-shadow: 0 0 0 3px rgba(1, 148, 243, 0.1);
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 2;
        }

        .input-group .form-input {
            padding-left: 45px;
        }

        .btn-login {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #0194f3 0%, #0066cc 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(1, 148, 243, 0.3);
        }

        .btn-login:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .auth-links {
            text-align: center;
            margin-top: 20px;
        }

        .auth-links a {
            color: #0194f3;
            text-decoration: none;
            font-weight: 500;
        }

        .auth-links a:hover {
            text-decoration: underline;
        }

        .divider {
            text-align: center;
            margin: 20px 0;
            position: relative;
            color: #6c757d;
        }

        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e1e5e9;
        }

        .divider span {
            background: white;
            padding: 0 15px;
        }

        @media (max-width: 768px) {
            .auth-card {
                padding: 30px 20px;
                margin: 10px;
            }

            .auth-logo span {
                font-size: 1.5em;
            }

            .auth-title {
                font-size: 1.5em;
            }
        }
    </style>
</head>

<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <div class="auth-logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel</span>
                </div>
                <h1 class="auth-title">Selamat Datang</h1>
                <p class="auth-subtitle">Masuk ke akun Anda untuk melanjutkan</p>
            </div>

            <!-- Login Type Selector -->
            <div class="login-type-selector">
                <button type="button" class="login-type-btn active" onclick="switchLoginType('user')">
                    <i class="fas fa-user"></i> User
                </button>
                <button type="button" class="login-type-btn" onclick="switchLoginType('admin')">
                    <i class="fas fa-user-shield"></i> Admin
                </button>
            </div>

            <?php if ($error_message): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="login_type" id="loginType" value="user">

                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <div class="input-group">
                        <input type="email" id="email" name="email" class="form-input"
                            placeholder="Masukkan email Anda" required
                            value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                        <i class="fas fa-envelope"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" id="password" name="password" class="form-input"
                            placeholder="Masukkan password Anda" required>
                        <i class="fas fa-lock"></i>
                    </div>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>
                    Masuk ke <span id="loginTypeText">User</span> Panel
                </button>
            </form>

            <div class="divider">
                <span>atau</span>
            </div>

            <div class="auth-links">
                <p>Belum punya akun? <a href="register.php">Daftar sekarang</a></p>
                <p><a href="index.php">← Kembali ke Beranda</a></p>
            </div>
        </div>
    </div>

    <script>
        function switchLoginType(type) {
            const buttons = document.querySelectorAll('.login-type-btn');
            const loginTypeInput = document.getElementById('loginType');
            const loginTypeText = document.getElementById('loginTypeText');

            // Remove active class from all buttons
            buttons.forEach(btn => btn.classList.remove('active'));

            // Add active class to clicked button
            event.target.classList.add('active');

            // Update hidden input and button text
            loginTypeInput.value = type;
            loginTypeText.textContent = type === 'admin' ? 'Admin' : 'User';

            // Clear form
            document.getElementById('email').value = '';
            document.getElementById('password').value = '';

            // Clear any error messages
            const errorMessage = document.querySelector('.error-message');
            if (errorMessage) {
                errorMessage.remove();
            }
        }

        // Auto-focus email input
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('email').focus();
        });

        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;

            if (!email || !password) {
                e.preventDefault();
                alert('Mohon lengkapi semua field!');
                return;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Format email tidak valid!');
                return;
            }

            // Disable submit button to prevent double submit
            const submitBtn = document.querySelector('.btn-login');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
        });
    </script>
</body>

</html>