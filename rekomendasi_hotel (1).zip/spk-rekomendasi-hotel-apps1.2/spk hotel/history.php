<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include 'koneksi.php';

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['nama_lengkap'];

// Get user's search history
$sql = "SELECT 
    sh.id,
    sh.search_params,
    sh.saw_results,
    sh.total_hotels_found,
    sh.created_at
FROM search_history sh
WHERE sh.user_id = ?
ORDER BY sh.created_at DESC
LIMIT 50";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$search_history = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Count total searches
$total_searches = count($search_history);

// Calculate statistics
$total_hotels_viewed = 0;
$search_trends = [];
$date_groups = [];

foreach ($search_history as $search) {
    $total_hotels_viewed += $search['total_hotels_found'];
    
    // Group by date for timeline
    $date = date('Y-m-d', strtotime($search['created_at']));
    if (!isset($date_groups[$date])) {
        $date_groups[$date] = [];
    }
    $date_groups[$date][] = $search;
    
    // Analyze search parameters for trends
    $params = json_decode($search['search_params'], true);
    if ($params) {
        foreach ($params as $key => $value) {
            if (!empty($value)) {
                if (!isset($search_trends[$key])) {
                    $search_trends[$key] = [];
                }
                if (!isset($search_trends[$key][$value])) {
                    $search_trends[$key][$value] = 0;
                }
                $search_trends[$key][$value]++;
            }
        }
    }
}

$avg_hotels_per_search = $total_searches > 0 ? round($total_hotels_viewed / $total_searches, 1) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pencarian - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/history.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Breadcrumb */
        .breadcrumb {
            background: #f8f9fa;
            padding: 1rem 0;
            margin-top: 70px;
            border-bottom: 1px solid #e9ecef;
        }

        .breadcrumb-nav {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .breadcrumb-nav a {
            color: #0052cc;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-nav a:hover {
            color: #003d99;
            text-decoration: underline;
        }

        .breadcrumb-nav i.fa-chevron-right {
            color: #999;
            font-size: 0.7rem;
        }

        .breadcrumb-nav span {
            color: #666;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Header -->
     <?php include "header.php" ?>

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="container">
            <nav class="breadcrumb-nav">
                <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
                <i class="fas fa-chevron-right"></i>
                <span>Riwayat Pencarian</span>
            </nav>
        </div>
    </section>

    <!-- History Content -->
    <section class="history-content">
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <div class="header-info">
                    <h1><i class="fas fa-history"></i> Riwayat Pencarian Saya</h1>
                    <p>Lihat kembali pencarian hotel yang pernah Anda lakukan beserta hasil SAW</p>
                </div>
                <div class="history-stats">
                    <div class="stat-item">
                        <div class="stat-number"><?= $total_searches ?></div>
                        <div class="stat-label">Total Pencarian</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number"><?= $total_hotels_viewed ?></div>
                        <div class="stat-label">Hotel Dilihat</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number"><?= $avg_hotels_per_search ?></div>
                        <div class="stat-label">Rata-rata per Pencarian</div>
                    </div>
                </div>
            </div>

            <?php if ($total_searches > 0) { ?>
                <!-- Search Trends -->
                <div class="search-trends">
                    <h3><i class="fas fa-chart-line"></i> Tren Pencarian Anda</h3>
                    <div class="trends-grid">
                        <?php if (!empty($search_trends['budget'])) { ?>
                        <div class="trend-card">
                            <h4>Budget Favorit</h4>
                            <div class="trend-list">
                                <?php 
                                arsort($search_trends['budget']);
                                $count = 0;
                                foreach ($search_trends['budget'] as $budget => $frequency) { 
                                    if ($count++ >= 3) break;
                                    $budget_parts = explode('-', $budget);
                                    if (count($budget_parts) == 2) {
                                        $label = "Rp " . number_format($budget_parts[0], 0, ',', '.') . " - Rp " . number_format($budget_parts[1], 0, ',', '.');
                                    } else {
                                        $label = $budget;
                                    }
                                ?>
                                <div class="trend-item">
                                    <span class="trend-label"><?= $label ?></span>
                                    <span class="trend-count"><?= $frequency ?>x</span>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>

                        <?php if (!empty($search_trends['rating'])) { ?>
                        <div class="trend-card">
                            <h4>Rating Pilihan</h4>
                            <div class="trend-list">
                                <?php 
                                arsort($search_trends['rating']);
                                foreach ($search_trends['rating'] as $rating => $frequency) { 
                                ?>
                                <div class="trend-item">
                                    <span class="trend-label"><?= $rating ?> Bintang ke atas</span>
                                    <span class="trend-count"><?= $frequency ?>x</span>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>

                        <?php if (!empty($search_trends['jarak'])) { ?>
                        <div class="trend-card">
                            <h4>Jarak Preferensi</h4>
                            <div class="trend-list">
                                <?php 
                                arsort($search_trends['jarak']);
                                foreach ($search_trends['jarak'] as $jarak => $frequency) { 
                                    $jarak_parts = explode('-', $jarak);
                                    if (count($jarak_parts) == 2) {
                                        $label = $jarak_parts[0] . " - " . $jarak_parts[1] . " km";
                                    } else {
                                        $label = $jarak;
                                    }
                                ?>
                                <div class="trend-item">
                                    <span class="trend-label"><?= $label ?></span>
                                    <span class="trend-count"><?= $frequency ?>x</span>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>

                        <div class="trend-card highlight">
                            <h4>Insight Pencarian</h4>
                            <div class="insight-content">
                                <?php 
                                $insights = [];
                                
                                // Most frequent budget range
                                if (!empty($search_trends['budget'])) {
                                    $most_budget = array_keys($search_trends['budget'])[0];
                                    $insights[] = "Anda sering mencari hotel dengan budget " . $most_budget;
                                }
                                
                                // Search frequency
                                if ($total_searches >= 10) {
                                    $insights[] = "Anda pengguna aktif dengan " . $total_searches . " pencarian";
                                } elseif ($total_searches >= 5) {
                                    $insights[] = "Anda cukup aktif dalam mencari hotel";
                                }
                                
                                // Hotels per search
                                if ($avg_hotels_per_search >= 5) {
                                    $insights[] = "Anda suka mengeksplorasi banyak pilihan hotel";
                                }
                                
                                if (empty($insights)) {
                                    $insights[] = "Lakukan lebih banyak pencarian untuk mendapatkan insight yang lebih baik!";
                                }
                                
                                foreach ($insights as $insight) {
                                ?>
                                <div class="insight-item">
                                    <i class="fas fa-lightbulb"></i>
                                    <span><?= $insight ?></span>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Timeline -->
                <div class="history-timeline">
                    <div class="timeline-header">
                        <h3><i class="fas fa-clock"></i> Timeline Pencarian</h3>
                        <div class="timeline-controls">
                            <button class="timeline-btn active" onclick="showTimelineView('all')">Semua</button>
                            <button class="timeline-btn" onclick="showTimelineView('week')">7 Hari Terakhir</button>
                            <button class="timeline-btn" onclick="showTimelineView('month')">30 Hari Terakhir</button>
                        </div>
                    </div>

                    <div class="timeline-container">
                        <?php 
                        $displayed_dates = 0;
                        foreach ($date_groups as $date => $searches) { 
                            $displayed_dates++;
                            $is_recent = $displayed_dates <= 7;
                        ?>
                        <div class="timeline-date" data-date="<?= $date ?>" data-days-ago="<?= (time() - strtotime($date)) / (60*60*24) ?>">
                            <div class="date-header">
                                <div class="date-info">
                                    <h4><?= date('d M Y', strtotime($date)) ?></h4>
                                    <span class="date-meta"><?= count($searches) ?> pencarian</span>
                                </div>
                                <div class="date-summary">
                                    <?php 
                                    $total_results = array_sum(array_column($searches, 'total_hotels_found'));
                                    ?>
                                    <span class="results-count"><?= $total_results ?> hotel ditemukan</span>
                                </div>
                            </div>

                            <div class="searches-list">
                                <?php foreach ($searches as $search) { 
                                    $params = json_decode($search['search_params'], true);
                                    $results = json_decode($search['saw_results'], true);
                                ?>
                                <div class="search-card" data-search-id="<?= $search['id'] ?>">
                                    <div class="search-header">
                                        <div class="search-time">
                                            <i class="fas fa-clock"></i>
                                            <span><?= date('H:i', strtotime($search['created_at'])) ?></span>
                                        </div>
                                        <div class="search-results">
                                            <span class="result-count"><?= $search['total_hotels_found'] ?> hotel</span>
                                        </div>
                                    </div>

                                    <div class="search-params">
                                        <?php if (!empty($params)) { ?>
                                        <div class="param-tags">
                                            <?php if (!empty($params['budget'])) { 
                                                $budget_parts = explode('-', $params['budget']);
                                                if (count($budget_parts) == 2) {
                                                    $budget_label = "Rp " . number_format($budget_parts[0], 0, ',', '.') . " - Rp " . number_format($budget_parts[1], 0, ',', '.');
                                                } else {
                                                    $budget_label = $params['budget'];
                                                }
                                            ?>
                                            <span class="param-tag budget">
                                                <i class="fas fa-money-bill-wave"></i>
                                                <?= $budget_label ?>
                                            </span>
                                            <?php } ?>

                                            <?php if (!empty($params['rating'])) { ?>
                                            <span class="param-tag rating">
                                                <i class="fas fa-star"></i>
                                                <?= $params['rating'] ?>+ Bintang
                                            </span>
                                            <?php } ?>

                                            <?php if (!empty($params['jarak'])) { 
                                                $jarak_parts = explode('-', $params['jarak']);
                                                if (count($jarak_parts) == 2) {
                                                    $jarak_label = $jarak_parts[0] . " - " . $jarak_parts[1] . " km";
                                                } else {
                                                    $jarak_label = $params['jarak'];
                                                }
                                            ?>
                                            <span class="param-tag distance">
                                                <i class="fas fa-map-marker-alt"></i>
                                                <?= $jarak_label ?>
                                            </span>
                                            <?php } ?>

                                            <?php if (empty($params) || (empty($params['budget']) && empty($params['rating']) && empty($params['jarak']))) { ?>
                                            <span class="param-tag all">
                                                <i class="fas fa-globe"></i>
                                                Semua Hotel
                                            </span>
                                            <?php } ?>
                                        </div>
                                        <?php } ?>
                                    </div>

                                    <?php if (!empty($results) && is_array($results)) { ?>
                                    <div class="search-results-preview">
                                        <div class="results-header">
                                            <span>Top 3 Hasil SAW:</span>
                                            <button class="toggle-results" onclick="toggleResults(this)">
                                                <i class="fas fa-chevron-down"></i>
                                            </button>
                                        </div>
                                        <div class="results-list" style="display: none;">
                                            <?php 
                                            $top_results = array_slice($results, 0, 3);
                                            foreach ($top_results as $index => $result) { 
                                            ?>
                                            <div class="result-item">
                                                <div class="result-rank">#<?= $index + 1 ?></div>
                                                <div class="result-info">
                                                    <div class="result-name"><?= htmlspecialchars($result['nama_hotel'] ?? 'Hotel') ?></div>
                                                    <div class="result-score">SAW: <?= number_format($result['saw_score'] ?? 0, 3) ?></div>
                                                </div>
                                                <div class="result-price">
                                                    Rp <?= number_format($result['harga_per_malam'] ?? 0, 0, ',', '.') ?>
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <?php } ?>

                                    <div class="search-actions">
                                        <button class="btn-repeat" onclick="repeatSearch('<?= htmlspecialchars(json_encode($params)) ?>')">
                                            <i class="fas fa-redo"></i>
                                            Ulangi Pencarian
                                        </button>
                                        <button class="btn-delete" onclick="deleteSearch(<?= $search['id'] ?>, this)">
                                            <i class="fas fa-trash"></i>
                                            Hapus
                                        </button>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <h3>Aksi Cepat</h3>
                    <div class="action-buttons">
                        <button class="action-btn" onclick="showClearOptions()">
                            <i class="fas fa-broom"></i>
                            <span>Hapus Riwayat</span>
                        </button>
                        <button class="action-btn" onclick="window.location.href='index.php#hotels'">
                            <i class="fas fa-search"></i>
                            <span>Pencarian Baru</span>
                        </button>
                        <button class="action-btn" onclick="window.location.href='favorites.php'">
                            <i class="fas fa-heart"></i>
                            <span>Lihat Favorit</span>
                        </button>
                    </div>
                </div>

            <?php } else { ?>
                <!-- Empty State -->
                <div class="empty-history">
                    <div class="empty-icon">
                        <i class="fas fa-search-minus"></i>
                    </div>
                    <h2>Belum Ada Riwayat Pencarian</h2>
                    <p>Anda belum melakukan pencarian hotel apapun. Mulai jelajahi hotel-hotel terbaik di Mataram dan sistem akan menyimpan riwayat pencarian Anda!</p>
                    
                    <div class="empty-actions">
                        <a href="index.php#hotels" class="btn-start-search">
                            <i class="fas fa-search"></i>
                            Mulai Pencarian
                        </a>
                        <a href="index.php#about" class="btn-learn-saw">
                            <i class="fas fa-graduation-cap"></i>
                            Pelajari Metode SAW
                        </a>
                    </div>

                    <div class="search-tips">
                        <h4>💡 Tips Pencarian Hotel:</h4>
                        <ul>
                            <li>Gunakan filter budget untuk menemukan hotel sesuai anggaran</li>
                            <li>Pilih rating minimum untuk kualitas yang diinginkan</li>
                            <li>Atur jarak dari pusat kota sesuai mobilitas Anda</li>
                            <li>Perhatikan SAW Score untuk rekomendasi terbaik</li>
                            <li>Simpan hotel favorit untuk perbandingan mudah</li>
                        </ul>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-hotel"></i>
                        <span>SPK Hotel Mataram</span>
                    </div>
                    <p>Sistem Pendukung Keputusan untuk rekomendasi hotel terbaik di Kota Mataram menggunakan metode SAW.</p>
                </div>
                <div class="footer-section">
                    <h4>Kontak</h4>
                    <p><i class="fas fa-map-marker-alt"></i> Mataram, Nusa Tenggara Barat</p>
                    <p><i class="fas fa-envelope"></i> info@spkhotel.com</p>
                    <p><i class="fas fa-phone"></i> +62 370 123456</p>
                </div>
                <div class="footer-section">
                    <h4>Link Cepat</h4>
                    <ul>
                        <li><a href="index.php">Beranda</a></li>
                        <li><a href="index.php#hotels">Hotel</a></li>
                        <li><a href="index.php#about">Tentang SAW</a></li>
                        <li><a href="profile.php">Profil</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 SPK Hotel Mataram. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Toggle user dropdown
        function toggleUserDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');
            
            if (userMenu && !userMenu.contains(event.target)) {
                dropdown?.classList.remove('show');
            }
        });

        // Timeline view controls
        function showTimelineView(period) {
            const buttons = document.querySelectorAll('.timeline-btn');
            const timelineDates = document.querySelectorAll('.timeline-date');
            
            // Update active button
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Show/hide timeline items based on period
            timelineDates.forEach(dateItem => {
                const daysAgo = parseInt(dateItem.dataset.daysAgo);
                let show = true;
                
                if (period === 'week' && daysAgo > 7) {
                    show = false;
                } else if (period === 'month' && daysAgo > 30) {
                    show = false;
                }
                
                dateItem.style.display = show ? 'block' : 'none';
            });
        }

        // Toggle search results
        function toggleResults(button) {
            const resultsList = button.closest('.search-results-preview').querySelector('.results-list');
            const icon = button.querySelector('i');
            
            if (resultsList.style.display === 'none') {
                resultsList.style.display = 'block';
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            } else {
                resultsList.style.display = 'none';
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        }

        // Repeat search
        function repeatSearch(paramsJson) {
            try {
                const params = JSON.parse(paramsJson);
                let url = 'index.php#hotels';
                
                const urlParams = new URLSearchParams();
                if (params.budget) urlParams.append('budget', params.budget);
                if (params.rating) urlParams.append('rating', params.rating);
                if (params.jarak) urlParams.append('jarak', params.jarak);
                
                if (urlParams.toString()) {
                    url += '?' + urlParams.toString();
                }
                
                window.location.href = url;
            } catch (error) {
                console.error('Error parsing search params:', error);
                showNotification('Terjadi kesalahan saat mengulangi pencarian', 'error');
            }
        }

        // Delete search history item
        function deleteSearch(searchId, button) {
            if (confirm('Apakah Anda yakin ingin menghapus riwayat pencarian ini?')) {
                const searchCard = button.closest('.search-card');
                
                // Show loading state
                button.disabled = true;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghapus...';
                
                fetch('ajax/delete_search_history.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'delete_single',
                        search_id: searchId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Animate card removal
                        searchCard.style.transform = 'scale(0.8)';
                        searchCard.style.opacity = '0';
                        
                        setTimeout(() => {
                            searchCard.remove();
                            checkEmptyHistory();
                            updateHistoryStats();
                        }, 300);
                        
                        showNotification('Riwayat pencarian berhasil dihapus', 'success');
                    } else {
                        showNotification('Gagal menghapus riwayat: ' + data.message, 'error');
                        // Reset button state
                        button.disabled = false;
                        button.innerHTML = '<i class="fas fa-trash"></i> Hapus';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Terjadi kesalahan saat menghapus riwayat', 'error');
                    // Reset button state
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-trash"></i> Hapus';
                });
            }
        }

        // Show clear options modal
        function showClearOptions() {
            const modal = document.createElement('div');
            modal.className = 'clear-modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-broom"></i> Hapus Riwayat Pencarian</h3>
                        <button class="modal-close" onclick="closeClearModal()">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Pilih opsi penghapusan riwayat pencarian:</p>
                        <div class="clear-options">
                            <button class="clear-option" onclick="clearAllHistory()">
                                <i class="fas fa-trash-alt"></i>
                                <span>Hapus Semua Riwayat</span>
                                <small>Menghapus seluruh riwayat pencarian</small>
                            </button>
                            <button class="clear-option" onclick="clearOldHistory(30)">
                                <i class="fas fa-calendar-times"></i>
                                <span>Hapus Riwayat Lama (30+ hari)</span>
                                <small>Menghapus pencarian lebih dari 30 hari</small>
                            </button>
                            <button class="clear-option" onclick="clearOldHistory(7)">
                                <i class="fas fa-calendar-week"></i>
                                <span>Hapus Riwayat Lama (7+ hari)</span>
                                <small>Menghapus pencarian lebih dari 7 hari</small>
                            </button>
                            <button class="clear-option" onclick="showDateRangeClear()">
                                <i class="fas fa-calendar-alt"></i>
                                <span>Hapus Berdasarkan Tanggal</span>
                                <small>Pilih rentang tanggal custom</small>
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            setTimeout(() => modal.classList.add('show'), 100);
        }

        // Close clear modal
        function closeClearModal() {
            const modal = document.querySelector('.clear-modal');
            if (modal) {
                modal.classList.remove('show');
                setTimeout(() => document.body.removeChild(modal), 300);
            }
        }

        // Clear all history
        function clearAllHistory() {
            if (confirm('Apakah Anda yakin ingin menghapus SEMUA riwayat pencarian? Tindakan ini tidak dapat dibatalkan.')) {
                closeClearModal();
                
                fetch('ajax/delete_search_history.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'delete_all'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showNotification(data.message, 'success');
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        showNotification('Gagal menghapus riwayat: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Terjadi kesalahan saat menghapus riwayat', 'error');
                });
            }
        }

        // Clear old history
        function clearOldHistory(daysOld) {
            const daysText = daysOld === 7 ? '7 hari' : '30 hari';
            if (confirm(`Apakah Anda yakin ingin menghapus riwayat pencarian lebih dari ${daysText}?`)) {
                closeClearModal();
                
                fetch('ajax/delete_search_history.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'delete_old',
                        days_old: daysOld
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showNotification(data.message, 'success');
                        if (data.deleted_count > 0) {
                            setTimeout(() => location.reload(), 1500);
                        }
                    } else {
                        showNotification('Gagal menghapus riwayat: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Terjadi kesalahan saat menghapus riwayat', 'error');
                });
            }
        }

        // Show date range clear options
        function showDateRangeClear() {
            const dateModal = document.createElement('div');
            dateModal.className = 'date-range-modal';
            dateModal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3><i class="fas fa-calendar-alt"></i> Hapus Berdasarkan Tanggal</h3>
                        <button class="modal-close" onclick="closeDateModal()">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="date-inputs">
                            <div class="input-group">
                                <label for="startDate">Dari Tanggal:</label>
                                <input type="date" id="startDate" class="date-input">
                            </div>
                            <div class="input-group">
                                <label for="endDate">Sampai Tanggal:</label>
                                <input type="date" id="endDate" class="date-input">
                            </div>
                        </div>
                        <div class="modal-actions">
                            <button class="btn-cancel" onclick="closeDateModal()">Batal</button>
                            <button class="btn-delete-range" onclick="deleteByDateRange()">
                                <i class="fas fa-trash"></i>
                                Hapus Riwayat
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            closeClearModal();
            document.body.appendChild(dateModal);
            setTimeout(() => dateModal.classList.add('show'), 100);
        }

        // Close date modal
        function closeDateModal() {
            const modal = document.querySelector('.date-range-modal');
            if (modal) {
                modal.classList.remove('show');
                setTimeout(() => document.body.removeChild(modal), 300);
            }
        }

        // Delete by date range
        function deleteByDateRange() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate) {
                showNotification('Silakan pilih tanggal mulai dan akhir', 'error');
                return;
            }
            
            if (startDate > endDate) {
                showNotification('Tanggal mulai tidak boleh lebih besar dari tanggal akhir', 'error');
                return;
            }
            
            if (confirm(`Hapus riwayat pencarian dari ${startDate} sampai ${endDate}?`)) {
                closeDateModal();
                
                fetch('ajax/delete_search_history.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'delete_by_date',
                        start_date: startDate,
                        end_date: endDate
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showNotification(data.message, 'success');
                        if (data.deleted_count > 0) {
                            setTimeout(() => location.reload(), 1500);
                        }
                    } else {
                        showNotification('Gagal menghapus riwayat: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showNotification('Terjadi kesalahan saat menghapus riwayat', 'error');
                });
            }
        }

        // Check if history is empty after deletion
        function checkEmptyHistory() {
            const remainingCards = document.querySelectorAll('.search-card').length;
            if (remainingCards === 0) {
                location.reload(); // Reload to show empty state
            }
        }

        // Update history statistics
        function updateHistoryStats() {
            const cards = document.querySelectorAll('.search-card');
            const totalCards = cards.length;
            
            // Update stat numbers (simplified)
            const statNumbers = document.querySelectorAll('.stat-number');
            if (statNumbers.length > 0) {
                statNumbers[0].textContent = totalCards;
            }
        }

        function exportHistory() {
            showNotification('Fitur export riwayat akan segera hadir!', 'info');
        }

        // Show notification
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => notification.classList.add('show'), 100);
            
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => document.body.removeChild(notification), 300);
            }, 3000);
        }

        // Auto-expand recent searches
        document.addEventListener('DOMContentLoaded', function() {
            const recentSearches = document.querySelectorAll('.timeline-date');
            if (recentSearches.length > 0) {
                // Auto-expand the first (most recent) date
                const firstToggle = recentSearches[0].querySelector('.toggle-results');
                if (firstToggle) {
                    firstToggle.click();
                }
            }
        });
    </script>
</body>
</html>