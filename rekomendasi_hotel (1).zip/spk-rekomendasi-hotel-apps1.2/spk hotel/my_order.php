<?php
session_start();
include 'koneksi.php';

// Cek login user
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data pesanan user
$sql = "SELECT o.*, h.nama_hotel, h.foto_utama, h.alamat, h.harga_per_malam
        FROM orders o
        JOIN hotels h ON o.hotel_id = h.id
        WHERE o.user_id = ? ORDER BY o.created_at DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>My Order - SPK Hotel Mataram</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: #f8f9fa;
            padding-top: 80px;
            /* Sesuaikan dengan tinggi header */
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: #fff;
            z-index: 1000;
            border-bottom: 1px solid #ddd;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
    </style>

</head>

<body>
    <header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="index.php">Beranda</a>
                    <a href="index.php#hotels">Hotel</a>
                    <a href="my_order.php">My Order</a>
                    <a href="index.php#about">Tentang SAW</a>

                    <?php
                    if (isset($_SESSION['user_id']) || isset($_SESSION['admin_id'])) {
                        $user_name = $_SESSION['nama_lengkap'] ?? 'User';
                        $user_type = $_SESSION['user_type'] ?? 'user';
                    ?>
                        <div class="user-menu">
                            <div class="user-info" onclick="toggleUserDropdown()">
                                <i class="fas fa-user-circle"></i>
                                <span>Hi, <?= htmlspecialchars($user_name) ?>!</span>
                                <i class="fas fa-chevron-down dropdown-arrow"></i>
                            </div>
                            <div class="user-dropdown" id="userDropdown">
                                <?php if ($user_type === 'admin') { ?>
                                    <a href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard Admin</a>
                                <?php } else { ?>
                                    <!-- <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a> -->
                                    <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                                    <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                                <?php } ?>
                                <div class="dropdown-divider"></div>
                                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    <?php
                    } else {
                    ?>
                        <a href="login.php" class="btn-login">Login</a>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>

    <div class="container py-5">
        <h2 class="mb-4 text-center">Riwayat Pemesanan Anda</h2>

        <?php if (empty($orders)): ?>
            <div class="alert alert-info text-center">Anda belum memiliki pesanan kamar hotel.</div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($orders as $order): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card order-card border-0 shadow-sm position-relative overflow-hidden" style="border-left: 5px solid <?= $order['status'] === 'dibayar' ? '#28a745' : '#ffc107' ?>;">
                            <?php if (!empty($order['foto_utama']) && file_exists('assets/images/' . $order['foto_utama'])): ?>
                                <img src="assets/images/<?= $order['foto_utama'] ?>" class="hotel-img rounded-top" alt="Hotel">
                            <?php else: ?>
                                <div class="bg-secondary text-white d-flex align-items-center justify-content-center hotel-img rounded-top">
                                    <i class="fas fa-hotel fa-2x"></i>
                                </div>
                            <?php endif; ?>

                            <div class="card-body">
                                <h5 class="card-title mb-2"><?= htmlspecialchars($order['nama_hotel']) ?></h5>
                                <p class="mb-1"><i class="fas fa-map-marker-alt text-danger"></i> <?= htmlspecialchars($order['alamat']) ?></p>
                                <p class="mb-1"><strong>Check-in:</strong> <?= $order['tanggal_checkin'] ?> &nbsp; | &nbsp;
                                    <strong>Check-out:</strong> <?= $order['tanggal_checkout'] ?>
                                </p>
                                <p class="mb-1"><strong>Kamar:</strong> <?= $order['jumlah_kamar'] ?></p>

                                <!-- ✅ Perbaikan total harga: -->
                                <p class="mb-2"><strong>Total:</strong> Rp <?= number_format($order['jumlah_kamar'] * $order['harga_per_malam'], 0, ',', '.') ?></p>

                                <p class="text-muted small">Dipesan: <?= date('d M Y H:i', strtotime($order['created_at'])) ?></p>

                                <!-- ✅ Perbaikan pengecekan status: -->
                                <?php if (trim($order['status']) === 'belum_dibayar'): ?>
                                    <span class="badge bg-warning text-dark mb-2"><i class="fas fa-clock"></i> Belum Dibayar</span>
                                    <a href="bayar.php?order_id=<?= $order['id'] ?>" class="btn btn-warning btn-sm w-100">
                                        <i class="fas fa-credit-card"></i> Bayar Sekarang
                                    </a>

                                <?php elseif (trim($order['status']) === 'diproses'): ?>
                                    <span class="badge bg-info text-dark mb-2"><i class="fas fa-hourglass-half"></i> Menunggu Verifikasi</span>
                                    <?php if (!empty($order['bukti_bayar'])): ?>
                                        <a href="uploads/<?= $order['bukti_bayar'] ?>" target="_blank" class="btn btn-outline-info btn-sm w-100 mt-2">
                                            <i class="fas fa-file-image"></i> Lihat Bukti
                                        </a>
                                    <?php endif; ?>

                                <?php elseif (trim($order['status']) === 'dibayar'): ?>
                                    <span class="badge bg-success mb-2"><i class="fas fa-check-circle"></i> Pembayaran Diverifikasi</span>
                                    <?php if (!empty($order['bukti_bayar'])): ?>
                                        <a href="uploads/<?= $order['bukti_bayar'] ?>" target="_blank" class="btn btn-outline-secondary btn-sm w-100 mt-2">
                                            <i class="fas fa-file-image"></i> Bukti Pembayaran
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>

                        </div>


                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://kit.fontawesome.com/a2d02d6a5e.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>