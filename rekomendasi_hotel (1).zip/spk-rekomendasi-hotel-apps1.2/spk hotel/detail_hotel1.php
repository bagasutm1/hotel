<?php
session_start();
include 'koneksi.php';

// Ambil ID hotel dari URL
$hotel_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($hotel_id == 0) {
    header('Location: index.php');
    exit();
}

// Ambil data hotel
$sql = "SELECT * FROM hotels WHERE id = ? AND status = 'aktif'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $hotel_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$hotel = mysqli_fetch_assoc($result);

if (!$hotel) {
    header('Location: index.php');
    exit();
}

// Ambil nilai MIN/MAX dari semua hotel aktif untuk normalisasi
$normal_query = mysqli_query($conn, "
    SELECT 
        MIN(harga_per_malam) AS min_harga,
        MAX(rating_bintang) AS max_rating,
        MIN(jarak_km) AS min_jarak
    FROM hotels
    WHERE status = 'aktif'
      AND harga_per_malam > 0
      AND rating_bintang IS NOT NULL
      AND jarak_km IS NOT NULL
");
$normal = mysqli_fetch_assoc($normal_query);

// Hitung SAW Score dengan normalisasi
$harga_score = ($hotel['harga_per_malam'] > 0 && $normal['min_harga'] > 0)
    ? ($normal['min_harga'] / $hotel['harga_per_malam']) * 0.4
    : 0;

$rating_score = ($normal['max_rating'] > 0)
    ? ($hotel['rating_bintang'] / $normal['max_rating']) * 0.35
    : 0;

$jarak_score = ($hotel['jarak_km'] > 0 && $normal['min_jarak'] > 0)
    ? ($normal['min_jarak'] / $hotel['jarak_km']) * 0.25
    : 0;

$saw_score = $harga_score + $rating_score + $jarak_score;

// Tambahkan ke array hotel
$hotel['harga_score'] = $harga_score;
$hotel['rating_score'] = $rating_score;
$hotel['jarak_score'] = $jarak_score;
$hotel['saw_score'] = $saw_score;

// Ambil foto-foto hotel
$photos_sql = "SELECT foto_path, keterangan, is_primary FROM hotel_photos WHERE hotel_id = ? ORDER BY is_primary DESC, id ASC";
$photos_stmt = mysqli_prepare($conn, $photos_sql);
mysqli_stmt_bind_param($photos_stmt, "i", $hotel_id);
mysqli_stmt_execute($photos_stmt);
$photos_result = mysqli_stmt_get_result($photos_stmt);
$photos = mysqli_fetch_all($photos_result, MYSQLI_ASSOC);

// Cek apakah user favoritkan hotel ini
$is_favorited = false;
if (isset($_SESSION['user_id'])) {
    $fav_sql = "SELECT id FROM user_favorites WHERE user_id = ? AND hotel_id = ?";
    $fav_stmt = mysqli_prepare($conn, $fav_sql);
    mysqli_stmt_bind_param($fav_stmt, "ii", $_SESSION['user_id'], $hotel_id);
    mysqli_stmt_execute($fav_stmt);
    $fav_result = mysqli_stmt_get_result($fav_stmt);
    $is_favorited = mysqli_num_rows($fav_result) > 0;
}

// Ambil hotel serupa berdasarkan rating/harga
$similar_sql = "SELECT 
    h.id, h.nama_hotel, h.harga_per_malam, h.rating_bintang, h.foto_utama, h.jarak_km
FROM hotels h
WHERE h.id != ? AND h.status = 'aktif' 
  AND (h.rating_bintang = ? OR (h.harga_per_malam BETWEEN ? AND ?))
LIMIT 5";

$price_min = $hotel['harga_per_malam'] * 0.7;
$price_max = $hotel['harga_per_malam'] * 1.3;

$similar_stmt = mysqli_prepare($conn, $similar_sql);
mysqli_stmt_bind_param($similar_stmt, "iidd", $hotel_id, $hotel['rating_bintang'], $price_min, $price_max);
mysqli_stmt_execute($similar_stmt);
$similar_result = mysqli_stmt_get_result($similar_stmt);
$similar_hotels = mysqli_fetch_all($similar_result, MYSQLI_ASSOC);

// Hitung SAW Score untuk hotel serupa
foreach ($similar_hotels as &$similar) {
    $harga_score = ($similar['harga_per_malam'] > 0 && $normal['min_harga'] > 0)
        ? ($normal['min_harga'] / $similar['harga_per_malam']) * 0.4
        : 0;

    $rating_score = ($normal['max_rating'] > 0)
        ? ($similar['rating_bintang'] / $normal['max_rating']) * 0.35
        : 0;

    $jarak_score = ($similar['jarak_km'] > 0 && $normal['min_jarak'] > 0)
        ? ($normal['min_jarak'] / $similar['jarak_km']) * 0.25
        : 0;

    $similar['saw_score'] = $harga_score + $rating_score + $jarak_score;
}

// Pisahkan fasilitas jadi array
$fasilitas = explode(',', $hotel['fasilitas']);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($hotel['nama_hotel']) ?> - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/detail.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="index.php">Beranda</a>
                    <a href="index.php#hotels">Hotel</a>
                    <a href="index.php#about">Tentang SAW</a>

                    <?php
                    if (isset($_SESSION['user_id']) || isset($_SESSION['admin_id'])) {
                        $user_name = $_SESSION['nama_lengkap'] ?? 'User';
                        $user_type = $_SESSION['user_type'] ?? 'user';
                    ?>
                        <div class="user-menu">
                            <div class="user-info" onclick="toggleUserDropdown()">
                                <i class="fas fa-user-circle"></i>
                                <span>Hi, <?= htmlspecialchars($user_name) ?>!</span>
                                <i class="fas fa-chevron-down dropdown-arrow"></i>
                            </div>
                            <div class="user-dropdown" id="userDropdown">
                                <?php if ($user_type === 'admin') { ?>
                                    <a href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard Admin</a>
                                <?php } else { ?>
                                    <!-- <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a> -->
                                    <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                                    <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                                <?php } ?>
                                <div class="dropdown-divider"></div>
                                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    <?php
                    } else {
                    ?>
                        <a href="login.php" class="btn-login">Login</a>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Breadcrumb -->
    <section class="breadcrumb">
        <div class="container">
            <nav class="breadcrumb-nav">
                <a href="index.php"><i class="fas fa-home"></i> Beranda</a>
                <i class="fas fa-chevron-right"></i>
                <a href="index.php#hotels">Hotel</a>
                <i class="fas fa-chevron-right"></i>
                <span><?= htmlspecialchars($hotel['nama_hotel']) ?></span>
            </nav>
        </div>
    </section>

    <!-- Hotel Detail -->
    <section class="hotel-detail">
        <div class="container">
            <!-- Hotel Header -->
            <div class="hotel-header">
                <div class="hotel-info">
                    <div class="hotel-title">
                        <h1><?= htmlspecialchars($hotel['nama_hotel']) ?></h1>
                        <div class="rating">
                            <?php for ($i = 1; $i <= 5; $i++) { ?>
                                <i class="fas fa-star <?= $i <= $hotel['rating_bintang'] ? 'active' : '' ?>"></i>
                            <?php } ?>
                            <span><?= $hotel['rating_bintang'] ?> Bintang</span>
                        </div>
                    </div>
                    <div class="location">
                        <i class="fas fa-map-marker-alt"></i>
                        <span><?= htmlspecialchars($hotel['alamat']) ?></span>
                        <span class="distance">(<?= $hotel['jarak_km'] ?> km dari pusat kota)</span>
                    </div>
                </div>
                <div class="hotel-actions">
                    <div class="saw-score-large">
                        <div class="score-label">SAW Score</div>
                        <div class="score-value"><?= number_format($hotel['saw_score'], 3) ?></div>
                        <div class="score-desc">Rekomendasi Terbaik</div>
                    </div>
                    <button class="btn-favorite-large <?= $is_favorited ? 'favorited' : '' ?>" onclick="toggleFavorite(<?= $hotel['id'] ?>, this)">
                        <i class="<?= $is_favorited ? 'fas' : 'far' ?> fa-heart"></i>
                        <span><?= $is_favorited ? 'Hapus dari Favorit' : 'Tambah ke Favorit' ?></span>
                    </button>
                </div>
            </div>

            <!-- Hotel Images -->
            <div class="hotel-images">
                <div class="main-image">
                    <?php
                    $main_photo = !empty($photos) ? $photos[0] : null;
                    $foto_path = '';

                    // Cek beberapa kemungkinan path foto
                    if ($main_photo) {
                        $possible_paths = [
                            'assets/images/' . $main_photo['foto_path'],
                            'assets/images/' . $hotel['foto_utama'],
                            $main_photo['foto_path'],
                            $hotel['foto_utama']
                        ];

                        foreach ($possible_paths as $path) {
                            if (!empty($path) && file_exists($path)) {
                                $foto_path = $path;
                                break;
                            }
                        }
                    }

                    if (!empty($foto_path)) {
                    ?>
                        <img src="<?= $foto_path ?>" alt="<?= htmlspecialchars($hotel['nama_hotel']) ?>" id="mainImage">

                    <?php } else { ?>
                        <div class="default-image-large">
                            <i class="fas fa-hotel"></i>
                            <span><?= htmlspecialchars($hotel['nama_hotel']) ?></span>
                        </div>
                    <?php } ?>
                </div>

                <?php if (count($photos) > 1) { ?>
                    <div class="image-thumbnails">
                        <?php foreach (array_slice($photos, 0, 5) as $index => $photo) {
                            $thumb_paths = [
                                'assets/images/' . $photo['foto_path'],
                                $photo['foto_path']
                            ];
                            $thumb_path = '';

                            foreach ($thumb_paths as $path) {
                                if (!empty($path) && file_exists($path)) {
                                    $thumb_path = $path;
                                    break;
                                }
                            }

                            if (!empty($thumb_path)) {
                        ?>
                                <img src="<?= $thumb_path ?>"
                                    alt="<?= htmlspecialchars($photo['keterangan']) ?>"
                                    onclick="changeMainImage('<?= $thumb_path ?>')"
                                    class="<?= $index === 0 ? 'active' : '' ?>">
                            <?php
                            } else {
                            ?>
                                <div class="thumb-placeholder">
                                    <i class="fas fa-image"></i>
                                </div>
                        <?php
                            }
                        } ?>
                        <?php if (count($photos) > 5) { ?>
                            <div class="more-photos" onclick="showAllPhotos()">
                                <span>+<?= count($photos) - 5 ?> foto lainnya</span>
                            </div>
                        <?php } ?>
                    </div>
                <?php } else { ?>
                    <div class="no-thumbnails">
                        <p><i class="fas fa-info-circle"></i> Foto tambahan tidak tersedia</p>
                    </div>
                <?php } ?>
            </div>

            <!-- Hotel Content -->
            <div class="hotel-content">
                <div class="content-main">
                    <!-- Description -->
                    <div class="content-section">
                        <h3><i class="fas fa-info-circle"></i> Deskripsi Hotel</h3>
                        <div class="description">
                            <?php if (!empty($hotel['deskripsi'])) { ?>
                                <p><?= nl2br(htmlspecialchars($hotel['deskripsi'])) ?></p>
                            <?php } else { ?>
                                <p><?= htmlspecialchars($hotel['nama_hotel']) ?> menawarkan akomodasi yang nyaman dengan lokasi strategis di <?= htmlspecialchars($hotel['alamat']) ?>. Hotel ini dilengkapi dengan berbagai fasilitas modern untuk memenuhi kebutuhan Anda selama menginap.</p>
                            <?php } ?>
                        </div>
                    </div>

                    <!-- Facilities -->
                    <div class="content-section">
                        <h3><i class="fas fa-concierge-bell"></i> Fasilitas Hotel</h3>
                        <div class="facilities-grid">
                            <?php foreach ($fasilitas as $facility) {
                                $facility = trim($facility);
                                $icon = getFacilityIcon($facility);
                            ?>
                                <div class="facility-item">
                                    <i class="<?= $icon ?>"></i>
                                    <span><?= htmlspecialchars($facility) ?></span>
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <!-- SAW Analysis -->
                    <div class="content-section">
                        <h3><i class="fas fa-chart-line"></i> Analisis SAW</h3>
                        <div class="saw-analysis">
                            <div class="criteria-breakdown">
                                <div class="criteria-item">
                                    <div class="criteria-header">
                                        <i class="fas fa-money-bill-wave"></i>
                                        <span>Harga per Malam (40%)</span>
                                    </div>
                                    <div class="criteria-value">
                                        <span class="value">Rp <?= number_format($hotel['harga_per_malam'], 0, ',', '.') ?></span>
                                        <div class="score-bar">
                                            <div class="score-fill" style="width: <?= (150000 / $hotel['harga_kriteria'] * 0.40) * 100 ?>%"></div>
                                        </div>
                                        <span class="score"><?= number_format((150000 / $hotel['harga_kriteria'] * 0.40), 3) ?></span>
                                    </div>
                                </div>
                                <div class="criteria-item">
                                    <div class="criteria-header">
                                        <i class="fas fa-star"></i>
                                        <span>Rating Hotel (35%)</span>
                                    </div>
                                    <div class="criteria-value">
                                        <span class="value"><?= $hotel['rating_bintang'] ?> Bintang</span>
                                        <div class="score-bar">
                                            <div class="score-fill" style="width: <?= ($hotel['rating_kriteria'] / 5 * 0.35) * 100 * 2.857 ?>%"></div>
                                        </div>
                                        <span class="score"><?= number_format(($hotel['rating_kriteria'] / 5 * 0.35), 3) ?></span>
                                    </div>
                                </div>
                                <div class="criteria-item">
                                    <div class="criteria-header">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span>Jarak dari Pusat Kota (25%)</span>
                                    </div>
                                    <div class="criteria-value">
                                        <span class="value"><?= $hotel['jarak_km'] ?> km</span>
                                        <div class="score-bar">
                                            <div class="score-fill" style="width: <?= (0.5 / $hotel['jarak_km'] * 0.25) * 100 * 4 ?>%"></div>
                                        </div>
                                        <span class="score"><?= number_format((0.5 / $hotel['jarak_km'] * 0.25), 3) ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <div class="total-score text-center mt-4">
                                    <a href="order_kamar.php?hotel_id=<?= $hotel['id'] ?>" class="btn btn-primary btn-lg w-100">
                                        <i class="fas fa-bed"></i> Pesan Kamar Hotel
                                    </a>
                                </div>
                            <?php else: ?>
                                <div class="total-score text-center mt-4">
                                    <a href="login.php" class="btn btn-outline-secondary btn-lg w-100">
                                        <i class="fas fa-sign-in-alt"></i> Login untuk Pesan Kamar
                                    </a>
                                </div>
                            <?php endif; ?>



                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="content-sidebar">
                    <!-- Price Card -->
                    <div class="price-card">
                        <div class="price-header">
                            <h4>Harga per Malam</h4>
                        </div>
                        <div class="price-main">
                            <span class="price-amount">Rp <?= number_format($hotel['harga_per_malam'], 0, ',', '.') ?></span>
                            <span class="price-unit">/malam</span>
                        </div>
                        <div class="price-includes">
                            <i class="fas fa-check"></i> Sudah termasuk pajak
                        </div>
                        <!-- <div class="booking-actions">
                            <button class="btn-book" onclick="bookNow()">
                                <i class="fas fa-calendar-check"></i>
                                Pesan Sekarang
                            </button>
                            <button class="btn-contact" onclick="contactHotel()">
                                <i class="fas fa-phone"></i>
                                Hubungi Hotel
                            </button>
                        </div> -->
                    </div>

                    <!-- Quick Info -->
                    <div class="info-card">
                        <h4>Informasi Cepat</h4>
                        <div class="info-list">
                            <div class="info-item">
                                <i class="fas fa-star"></i>
                                <span>Rating: <?= $hotel['rating_bintang'] ?> Bintang</span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-map-marker-alt"></i>
                                <span>Jarak: <?= $hotel['jarak_km'] ?> km dari pusat</span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-chart-line"></i>
                                <span>SAW Score: <?= number_format($hotel['saw_score'], 3) ?></span>
                            </div>
                            <div class="info-item">
                                <i class="fas fa-shield-alt"></i>
                                <span>Hotel Terverifikasi</span>
                            </div>
                        </div>
                    </div>
                    <div class="info-card">
                        <h4>Berikan Ulasan Anda</h4>

                        <?php if (isset($_SESSION['user_id']) && isset($hotel['id'])): ?>
                            <form action="proses_ulasan.php" method="POST">
                                <!-- ID hotel tersembunyi -->
                                <input type="hidden" name="hotel_id" value="<?= htmlspecialchars($hotel['id']) ?>">

                                <!-- Rating -->
                                <div class="mb-3">
                                    <label for="rating" class="form-label">
                                        <i class="fas fa-star me-2 text-warning"></i>Rating Bintang
                                    </label>
                                    <select name="rating_bintang" id="rating" class="form-select" required>
                                        <option value="">Pilih Rating</option>
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <option value="<?= $i ?>"><?= $i ?> Bintang</option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <!-- Ulasan -->
                                <div class="mb-3">
                                    <label for="ulasan" class="form-label">
                                        <i class="fas fa-comment-dots me-2 text-info"></i>Ulasan Anda
                                    </label>
                                    <textarea name="ulasan" id="ulasan" class="form-control" rows="4"
                                        placeholder="Tulis ulasan Anda di sini..." required></textarea>
                                </div>

                                <!-- Verifikasi (opsional) -->
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" name="terverifikasi" value="1" id="terverifikasi">
                                    <label class="form-check-label" for="terverifikasi">
                                        <i class="fas fa-shield-alt text-primary me-2"></i>Hotel Terverifikasi
                                    </label>
                                </div>

                                <!-- Tombol Kirim -->
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-paper-plane me-2"></i>Kirim Ulasan
                                </button>
                            </form>

                        <?php else: ?>
                            <p class="text-muted mt-3">Anda harus <a href="login.php">login</a> terlebih dahulu untuk memberikan ulasan.</p>
                        <?php endif; ?>
                    </div>


                </div>
            </div>

            <!-- Similar Hotels -->
            <?php if (!empty($similar_hotels)) { ?>
                <div class="similar-hotels">
                    <h3>Hotel Serupa yang Mungkin Anda Suka</h3>
                    <div class="similar-grid">
                        <?php foreach ($similar_hotels as $similar) { ?>
                            <div class="similar-card" onclick="window.location.href='detail_hotel.php?id=<?= $similar['id'] ?>'">
                                <div class="similar-image">
                                    <?php
                                    $similar_foto_path = '';
                                    if ($similar['foto_utama']) {
                                        $similar_paths = [
                                            'assets/images/' . $similar['foto_utama'],
                                            $similar['foto_utama']
                                        ];

                                        foreach ($similar_paths as $path) {
                                            if (file_exists($path)) {
                                                $similar_foto_path = $path;
                                                break;
                                            }
                                        }
                                    }

                                    if (!empty($similar_foto_path)) {
                                    ?>
                                        <img src="<?= $similar_foto_path ?>" alt="<?= htmlspecialchars($similar['nama_hotel']) ?>">
                                    <?php } else { ?>
                                        <div class="default-image-small">
                                            <i class="fas fa-hotel"></i>
                                        </div>
                                    <?php } ?>
                                </div>
                                <div class="similar-info">
                                    <h5><?= htmlspecialchars($similar['nama_hotel']) ?></h5>
                                    <div class="similar-rating">
                                        <?php for ($i = 1; $i <= 5; $i++) { ?>
                                            <i class="fas fa-star <?= $i <= $similar['rating_bintang'] ? 'active' : '' ?>"></i>
                                        <?php } ?>
                                    </div>
                                    <div class="similar-price">
                                        <span>Rp <?= number_format($similar['harga_per_malam'], 0, ',', '.') ?></span>
                                        <small>/malam</small>
                                    </div>
                                    <div class="similar-score">
                                        SAW: <?= number_format($similar['saw_score'], 2) ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-hotel"></i>
                        <span>SPK Hotel Mataram</span>
                    </div>
                    <p>Sistem Pendukung Keputusan untuk rekomendasi hotel terbaik di Kota Mataram menggunakan metode SAW.</p>
                </div>
                <div class="footer-section">
                    <h4>Kontak</h4>
                    <p><i class="fas fa-map-marker-alt"></i> Mataram, Nusa Tenggara Barat</p>
                    <p><i class="fas fa-envelope"></i> info@spkhotel.com</p>
                    <p><i class="fas fa-phone"></i> +62 370 123456</p>
                </div>
                <div class="footer-section">
                    <h4>Link Cepat</h4>
                    <ul>
                        <li><a href="index.php">Beranda</a></li>
                        <li><a href="index.php#hotels">Hotel</a></li>
                        <li><a href="index.php#about">Tentang SAW</a></li>
                        <li><a href="login.php">Login</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 SPK Hotel Mataram. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Toggle user dropdown
        function toggleUserDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');

            if (userMenu && !userMenu.contains(event.target)) {
                dropdown?.classList.remove('show');
            }
        });

        // Change main image
        function changeMainImage(src) {
            document.getElementById('mainImage').src = src;

            // Update active thumbnail
            document.querySelectorAll('.image-thumbnails img').forEach(img => {
                img.classList.remove('active');
            });
            event.target.classList.add('active');
        }

        // Toggle favorite
        function toggleFavorite(hotelId, button) {
            const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;

            if (!isLoggedIn) {
                alert('Silakan login terlebih dahulu untuk menambahkan favorit!');
                window.location.href = 'login.php';
                return;
            }

            const icon = button.querySelector('i');
            const span = button.querySelector('span');
            const isFavorited = icon.classList.contains('fas');

            if (isFavorited) {
                icon.classList.remove('fas');
                icon.classList.add('far');
                button.classList.remove('favorited');
                span.textContent = 'Tambah ke Favorit';
                showNotification('Hotel dihapus dari favorit', 'info');
                removeFavorite(hotelId);
            } else {
                icon.classList.remove('far');
                icon.classList.add('fas');
                button.classList.add('favorited');
                span.textContent = 'Hapus dari Favorit';
                showNotification('Hotel ditambahkan ke favorit!', 'success');
                addFavorite(hotelId);
            }
        }

        // Add to favorite
        function addFavorite(hotelId) {
            fetch('ajax/add_favorite.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        hotel_id: hotelId,
                        user_id: <?= $_SESSION['user_id'] ?? 'null' ?>
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) {
                        console.error('Error adding favorite:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        // Remove from favorite
        function removeFavorite(hotelId) {
            fetch('ajax/remove_favorite.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        hotel_id: hotelId,
                        user_id: <?= $_SESSION['user_id'] ?? 'null' ?>
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) {
                        console.error('Error removing favorite:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        // Show notification
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            `;

            document.body.appendChild(notification);

            setTimeout(() => notification.classList.add('show'), 100);

            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => document.body.removeChild(notification), 300);
            }, 3000);
        }

        // Book now
        function bookNow() {
            alert('Fitur pemesanan akan segera hadir!\n\nSilakan hubungi hotel langsung untuk reservasi.');
        }

        // Contact hotel
        function contactHotel() {
            alert('Hubungi hotel:\n\nTelepon: +62 370 123456\nEmail: info@<?= strtolower(str_replace(' ', '', $hotel['nama_hotel'])) ?>.com');
        }

        // Show all photos
        function showAllPhotos() {
            alert('Galeri foto lengkap akan segera hadir!');
        }
    </script>
</body>

</html>

<?php
// Function to get facility icon
function getFacilityIcon($facility)
{
    $facility = strtolower(trim($facility));
    $icons = [
        'wifi' => 'fas fa-wifi',
        'ac' => 'fas fa-snowflake',
        'tv' => 'fas fa-tv',
        'restaurant' => 'fas fa-utensils',
        'pool' => 'fas fa-swimming-pool',
        'gym' => 'fas fa-dumbbell',
        'spa' => 'fas fa-spa',
        'bar' => 'fas fa-cocktail',
        'parking' => 'fas fa-parking',
        'meeting room' => 'fas fa-users',
        'garden' => 'fas fa-tree'
    ];

    return $icons[$facility] ?? 'fas fa-check-circle';
}
?>