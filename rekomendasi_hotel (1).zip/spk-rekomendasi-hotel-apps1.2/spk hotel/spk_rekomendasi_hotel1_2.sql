-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Jun 2025 pada 13.17
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_rekomendasi_hotel1_2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `nama_lengkap`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@spkhotel.com', '$2y$10$qmdlSUHF01bSsmbuxE1HYeoK/YwfScUXXyiU2zWWEBV6n0YpJ5Ba2', 'Administrator SPK Hotel', '2025-06-20 12:04:28', '2025-06-22 11:16:11'),
(2, 'admin1', 'admin1@gmail.com', '$2y$10$xhcAYnrhvW7H/9q1Lbo5GeYGgQyUvs7IM9FRlX2NO2PhVwsIPCSVO', 'admin spk hotel', '2025-06-22 09:59:24', '2025-06-22 10:54:38');

-- --------------------------------------------------------

--
-- Struktur dari tabel `criteria`
--

CREATE TABLE `criteria` (
  `id` int(11) NOT NULL,
  `nama_kriteria` varchar(50) NOT NULL,
  `kode_kriteria` varchar(10) NOT NULL COMMENT 'C1, C2, C3, dst',
  `bobot` decimal(3,2) NOT NULL COMMENT 'Total semua bobot = 1.00',
  `jenis_kriteria` enum('benefit','cost') NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `satuan` varchar(20) DEFAULT NULL COMMENT 'Rupiah, Meter, Poin, dll',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data untuk tabel `criteria`
--

INSERT INTO `criteria` (`id`, `nama_kriteria`, `kode_kriteria`, `bobot`, `jenis_kriteria`, `deskripsi`, `satuan`, `created_at`, `updated_at`) VALUES
(1, 'Harga per Malam', 'C1', 0.40, 'cost', 'Harga kamar per malam dalam rupiah', 'Rupiah', '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(2, 'Rating Hotel', 'C2', 0.35, 'benefit', 'Rating bintang hotel (1-5)', 'Bintang', '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(3, 'Jarak dari Pusat Kota', 'C3', 0.25, 'cost', 'Jarak hotel dari pusat kota Mataram', 'Kilometer', '2025-06-20 12:04:28', '2025-06-21 01:37:16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotels`
--

CREATE TABLE `hotels` (
  `id` int(11) NOT NULL,
  `nama_hotel` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `foto_utama` varchar(255) DEFAULT NULL,
  `harga_per_malam` decimal(10,2) NOT NULL,
  `rating_bintang` int(11) DEFAULT NULL COMMENT '1-5 bintang',
  `fasilitas` text DEFAULT NULL COMMENT 'JSON array atau comma separated',
  `koordinat_lat` decimal(10,8) DEFAULT NULL,
  `koordinat_lng` decimal(11,8) DEFAULT NULL,
  `status` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data untuk tabel `hotels`
--

INSERT INTO `hotels` (`id`, `nama_hotel`, `alamat`, `deskripsi`, `foto_utama`, `harga_per_malam`, `rating_bintang`, `fasilitas`, `koordinat_lat`, `koordinat_lng`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Hotel Lombok Rayaa', 'Jl. Panca Usaha No. 11, Mataram', 'Hotel bintang 4 dengan fasilitas lengkap di pusat kota Mataram', 'hotel_1750467743_2097.jpg', 450000.00, 4, 'AC,TV,Gym,Restaurant', -8.58330000, 116.11670000, 'aktif', '2025-06-20 12:04:28', '2025-06-21 01:02:23'),
(2, 'Golden Palace Hotel', 'Jl. Sriwijaya No. 15, Mataram', 'Hotel mewah dengan pelayanan premium dan lokasi strategis', 'golden_palace.jpg', 750000.00, 5, 'WiFi,AC,TV,Restaurant,Pool,Spa,Gym,Bar', -8.58400000, 116.11500000, 'aktif', '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(3, 'Mataram Hotel', 'Jl. Pejanggik No. 32, Mataram', 'Hotel budget dengan fasilitas standar namun nyaman', 'hotel_1750467831_9556.jpg', 250000.00, 3, 'AC,TV,Restaurant', -8.58500000, 116.11800000, 'aktif', '2025-06-20 12:04:28', '2025-06-21 01:03:51'),
(4, 'Hotel Santika Mataram', 'Jl. Selaparang No. 140, Mataram', 'Hotel chain ternama dengan standar pelayanan tinggi', 'hotel_1750467808_3538.jpg', 580000.00, 4, 'AC,TV,Restaurant,Meeting Room', -8.58200000, 116.12000000, 'aktif', '2025-06-20 12:04:28', '2025-06-21 01:03:28'),
(5, 'Lombok Plaza Hotel', 'Jl. Salam No. 1, Mataram', 'Hotel bisnis dengan lokasi dekat pusat perbelanjaan', 'hotel_1750467863_6299.jpg', 380000.00, 3, 'AC,TV,Restaurant,Meeting Room', -8.58600000, 116.11400000, 'aktif', '2025-06-20 12:04:28', '2025-06-21 01:04:23'),
(7, 'Hotel Zahir', 'Jl. Pariwisata No. 8, Mataram', 'Hotel baru dengan desain modern dan fasilitas lengkap', 'hotel_1750467904_5629.jpg', 480000.00, 4, 'AC,TV,Restaurant', -8.58300000, 116.11700000, 'aktif', '2025-06-20 12:04:28', '2025-06-21 01:05:04'),
(8, 'Budget Inn Mataram', 'Jl. Airlangga No. 20, Mataram', 'Hotel budget untuk backpacker dan wisatawan hemat', 'hotel_1750467932_8176.jpg', 150000.00, 2, 'AC,TV', -8.58700000, 116.11900000, 'aktif', '2025-06-20 12:04:28', '2025-06-21 01:05:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotel_criteria_values`
--

CREATE TABLE `hotel_criteria_values` (
  `id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `criteria_id` int(11) NOT NULL,
  `nilai` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `hotel_criteria_values`
--

INSERT INTO `hotel_criteria_values` (`id`, `hotel_id`, `criteria_id`, `nilai`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 450000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(2, 1, 2, 4.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(3, 1, 3, 0.50, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(4, 2, 1, 750000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(5, 2, 2, 5.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(6, 2, 3, 1.20, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(7, 3, 1, 250000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(8, 3, 2, 3.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(9, 3, 3, 0.80, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(10, 4, 1, 580000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(11, 4, 2, 4.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(12, 4, 3, 2.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(13, 5, 1, 380000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(14, 5, 2, 3.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(15, 5, 3, 1.50, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(19, 7, 1, 480000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(20, 7, 2, 4.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(21, 7, 3, 0.70, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(22, 8, 1, 150000.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(23, 8, 2, 2.00, '2025-06-20 12:04:28', '2025-06-20 12:04:28'),
(24, 8, 3, 1.80, '2025-06-20 12:04:28', '2025-06-20 12:04:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotel_photos`
--

CREATE TABLE `hotel_photos` (
  `id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `foto_path` varchar(255) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `hotel_photos`
--

INSERT INTO `hotel_photos` (`id`, `hotel_id`, `foto_path`, `keterangan`, `is_primary`, `created_at`) VALUES
(4, 2, 'photos/golden_palace_1.jpg', 'Lobby Hotel', 1, '2025-06-20 12:04:28'),
(5, 2, 'photos/golden_palace_2.jpg', 'Suite Room', 0, '2025-06-20 12:04:28'),
(16, 1, 'hotel_1750466474_2424.jpg', NULL, 0, '2025-06-21 00:41:14'),
(21, 1, 'hotel_1750467743_7076.jpg', 'kamar', 0, '2025-06-21 01:02:23'),
(22, 3, 'hotel_1750467778_1648.jpg', 'kolam', 0, '2025-06-21 01:02:58'),
(23, 4, 'hotel_1750467808_4616.jpg', 'parkir', 0, '2025-06-21 01:03:28'),
(24, 3, 'hotel_1750467831_1912.jpg', 'cuhh', 0, '2025-06-21 01:03:51'),
(25, 5, 'hotel_1750467863_2323.jpg', 'ssssssss', 0, '2025-06-21 01:04:23'),
(26, 7, 'hotel_1750467891_5841.jpg', 'raullllllll', 0, '2025-06-21 01:04:51'),
(27, 8, 'hotel_1750467932_9917.jpg', 'hmmmmmmm', 0, '2025-06-21 01:05:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `search_history`
--

CREATE TABLE `search_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `search_params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Parameter pencarian: budget, lokasi, fasilitas, dll' CHECK (json_valid(`search_params`)),
  `saw_results` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Hasil perhitungan SAW dan ranking hotel' CHECK (json_valid(`saw_results`)),
  `total_hotels_found` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `search_history`
--

INSERT INTO `search_history` (`id`, `user_id`, `search_params`, `saw_results`, `total_hotels_found`, `created_at`) VALUES
(11, 7, '{\"budget\":\"0-300000\",\"rating\":\"\",\"jarak\":\"\"}', '[{\"ranking\":1,\"nama_hotel\":\"Budget Inn Mataram\",\"harga_per_malam\":150000,\"saw_score\":0.609},{\"ranking\":2,\"nama_hotel\":\"Mataram Hotel\",\"harga_per_malam\":250000,\"saw_score\":0.606}]', 2, '2025-06-22 11:10:55'),
(12, 7, '{\"budget\":\"0-300000\",\"rating\":\"\",\"jarak\":\"\"}', '[{\"ranking\":1,\"nama_hotel\":\"Budget Inn Mataram\",\"harga_per_malam\":150000,\"saw_score\":0.609},{\"ranking\":2,\"nama_hotel\":\"Mataram Hotel\",\"harga_per_malam\":250000,\"saw_score\":0.606}]', 2, '2025-06-22 11:11:37');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `foto_profil` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `nama_lengkap`, `no_telepon`, `alamat`, `foto_profil`, `created_at`, `updated_at`) VALUES
(7, 'user', 'user@gmail.com', '$2y$10$2ngI7gNcsvt.oyOCu8hs9uEYnYrjzwrj1cfg4cy3JhnUXGi5Mj3si', 'tes user', '098765348789', 'jakarta', NULL, '2025-06-22 11:10:16', '2025-06-22 11:10:16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_favorites`
--

CREATE TABLE `user_favorites` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user_favorites`
--

INSERT INTO `user_favorites` (`id`, `user_id`, `hotel_id`, `created_at`) VALUES
(10, 7, 1, '2025-06-22 11:12:25');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `criteria`
--
ALTER TABLE `criteria`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_kriteria` (`kode_kriteria`);

--
-- Indeks untuk tabel `hotels`
--
ALTER TABLE `hotels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_hotels_status` (`status`);

--
-- Indeks untuk tabel `hotel_criteria_values`
--
ALTER TABLE `hotel_criteria_values`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_hotel_criteria` (`hotel_id`,`criteria_id`),
  ADD KEY `idx_hotel_criteria_hotel_id` (`hotel_id`),
  ADD KEY `idx_hotel_criteria_criteria_id` (`criteria_id`);

--
-- Indeks untuk tabel `hotel_photos`
--
ALTER TABLE `hotel_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_hotel_photos_hotel_id` (`hotel_id`);

--
-- Indeks untuk tabel `search_history`
--
ALTER TABLE `search_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_search_history_user_id` (`user_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_hotel` (`user_id`,`hotel_id`),
  ADD KEY `hotel_id` (`hotel_id`),
  ADD KEY `idx_user_favorites_user_id` (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `criteria`
--
ALTER TABLE `criteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `hotels`
--
ALTER TABLE `hotels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `hotel_criteria_values`
--
ALTER TABLE `hotel_criteria_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `hotel_photos`
--
ALTER TABLE `hotel_photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT untuk tabel `search_history`
--
ALTER TABLE `search_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `user_favorites`
--
ALTER TABLE `user_favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `hotel_criteria_values`
--
ALTER TABLE `hotel_criteria_values`
  ADD CONSTRAINT `hotel_criteria_values_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `hotel_criteria_values_ibfk_2` FOREIGN KEY (`criteria_id`) REFERENCES `criteria` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `hotel_photos`
--
ALTER TABLE `hotel_photos`
  ADD CONSTRAINT `hotel_photos_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `search_history`
--
ALTER TABLE `search_history`
  ADD CONSTRAINT `search_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD CONSTRAINT `user_favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_favorites_ibfk_2` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
