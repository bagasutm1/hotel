
    <header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="index.php">Beranda</a>
                    <a href="index.php#hotels">Hotel</a>
                    <a href="index.php#about">Tentang SAW</a>
                    
                    <div class="user-menu">
                        <div class="user-info" onclick="toggleUserDropdown()">
                            <i class="fas fa-user-circle"></i>
                            <span>Hi, <?= htmlspecialchars($user_name) ?>!</span>
                            <i class="fas fa-chevron-down dropdown-arrow"></i>
                        </div>
                        <div class="user-dropdown" id="userDropdown">
                            <!-- <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a> -->
                            <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                            <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>