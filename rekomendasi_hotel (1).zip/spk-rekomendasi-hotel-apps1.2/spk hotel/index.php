<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPK Hotel Mataram - Rekomendasi Hotel Terbaik</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="#home">Beranda</a>
                    <a href="#hotels">Hotel</a>
                    <a href="my_order.php">My Order</a>
                    <a href="#about">Tentang SAW</a>


                    <?php
                    if (isset($_SESSION['user_id']) || isset($_SESSION['admin_id'])) {
                        $user_name = $_SESSION['nama_lengkap'] ?? 'User';
                        $user_type = $_SESSION['user_type'] ?? 'user';
                    ?>
                        <div class="user-menu">
                            <div class="user-info" onclick="toggleUserDropdown()">
                                <i class="fas fa-user-circle"></i>
                                <span>Hi, <?= htmlspecialchars($user_name) ?>!</span>
                                <i class="fas fa-chevron-down dropdown-arrow"></i>
                            </div>
                            <div class="user-dropdown" id="userDropdown">
                                <?php if ($user_type === 'admin') { ?>
                                    <a href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard Admin</a>
                                <?php } else { ?>
                                    <!-- <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a> -->
                                    <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                                    <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                                <?php } ?>
                                <div class="dropdown-divider"></div>
                                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    <?php
                    } else {
                    ?>
                        <a href="login.php" class="btn-login">Login/Register</a>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Temukan Hotel Terbaik di Mataram</h1>
                <p>Sistem rekomendasi hotel menggunakan metode SAW (Simple Additive Weighting) untuk memberikan rekomendasi terbaik berdasarkan harga, rating, dan lokasi</p>

                <!-- Search Box -->
                <div class="search-box">
                    <form method="GET" action="#hotels">
                        <div class="search-inputs">
                            <div class="input-group">
                                <i class="fas fa-money-bill-wave"></i>
                                <select name="budget" id="budget">
                                    <option value="">Pilih Budget</option>
                                    <option value="0-300000">Di bawah Rp 300.000</option>
                                    <option value="300000-500000">Rp 300.000 - Rp 500.000</option>
                                    <option value="500000-1000000">Di atas Rp 500.000</option>
                                </select>
                            </div>
                            <div class="input-group">
                                <i class="fas fa-star"></i>
                                <select name="rating" id="rating">
                                    <option value="">Pilih Rating</option>
                                    <option value="2">2 Bintang ke atas</option>
                                    <option value="3">3 Bintang ke atas</option>
                                    <option value="4">4 Bintang ke atas</option>
                                    <option value="5">5 Bintang</option>
                                </select>
                            </div>
                            <div class="input-group">
                                <i class="fas fa-map-marker-alt"></i>
                                <select name="jarak" id="jarak">
                                    <option value="">Jarak dari Pusat Kota</option>
                                    <option value="0-1">Kurang dari 1 km</option>
                                    <option value="1-2">1 - 2 km</option>
                                    <option value="2-5">2 - 5 km</option>
                                </select>
                            </div>
                            <button type="submit" class="btn-search">
                                <i class="fas fa-search"></i>
                                Cari Hotel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Hotels Section -->
    <section id="hotels" class="hotels">
        <div class="container">
            <h2>Rekomendasi Hotel Terbaik</h2>
            <p class="section-subtitle">Berdasarkan perhitungan metode SAW dengan kriteria harga, rating, dan lokasi</p>

            <div class="hotels-grid">
                <?php
                include 'koneksi.php';

                // Filter berdasarkan pencarian
                $where_conditions = ["h.status = 'aktif'"];

                if (!empty($_GET['budget'])) {
                    $budget = $_GET['budget'];
                    $budget_parts = explode('-', $budget);
                    if (count($budget_parts) == 2) {
                        $min_budget = $budget_parts[0];
                        $max_budget = $budget_parts[1];
                        $where_conditions[] = "h.harga_per_malam BETWEEN $min_budget AND $max_budget";
                    }
                }

                if (!empty($_GET['rating'])) {
                    $min_rating = $_GET['rating'];
                    $where_conditions[] = "h.rating_bintang >= $min_rating";
                }

                if (!empty($_GET['jarak'])) {
                    $jarak = $_GET['jarak'];
                    $jarak_parts = explode('-', $jarak);
                    if (count($jarak_parts) == 2) {
                        $min_jarak = $jarak_parts[0];
                        $max_jarak = $jarak_parts[1];
                        $where_conditions[] = "h.jarak_km BETWEEN $min_jarak AND $max_jarak";
                    }
                }

                $where_clause = implode(' AND ', $where_conditions);

                // Query dengan perhitungan SAW langsung
                $sql = "
SELECT 
    h.id,
    h.nama_hotel,
    h.alamat,
    h.harga_per_malam,
    h.rating_bintang,
    h.jarak_km,
    h.fasilitas,
    h.foto_utama,

    ROUND(
        (normal.MIN_harga / NULLIF(h.harga_per_malam, 0)) * 0.4 +
        (h.rating_bintang / NULLIF(normal.MAX_rating, 0)) * 0.35 +
        (normal.MIN_jarak / NULLIF(h.jarak_km, 0)) * 0.25
    , 3) AS saw_score

FROM hotels h
JOIN (
    SELECT 
        MIN(harga_per_malam) AS MIN_harga,
        MAX(rating_bintang) AS MAX_rating,
        MIN(jarak_km) AS MIN_jarak
    FROM hotels
    WHERE status = 'aktif'
    AND harga_per_malam > 0
    AND rating_bintang IS NOT NULL
    AND jarak_km IS NOT NULL
) AS normal ON 1=1

WHERE h.status = 'aktif'
  AND h.harga_per_malam > 0
  AND h.rating_bintang IS NOT NULL
  AND h.jarak_km IS NOT NULL
ORDER BY saw_score DESC
LIMIT 8
";

                $result = mysqli_query($conn, $sql);
                $rank = 1;

                while ($row = mysqli_fetch_assoc($result)) {
                    $fasilitas = explode(',', $row['fasilitas']);
                    $foto = $row['foto_utama'] ? 'assets/images/' . $row['foto_utama'] : 'assets/images/default-hotel.jpg';
                ?>
                    <div class="hotel-card">
                        <div class="hotel-image">
                            <?php if ($row['foto_utama'] && file_exists('assets/images/' . $row['foto_utama'])) { ?>
                                <img src="<?= $foto ?>" alt="<?= $row['nama_hotel'] ?>">
                            <?php } else { ?>
                                <div class="default-image">
                                    <i class="fas fa-hotel"></i>
                                    <span><?= $row['nama_hotel'] ?></span>
                                </div>
                            <?php } ?>
                            <div class="rank-badge">#<?= $rank ?></div>
                            <div class="saw-score">
                                <span>SAW Score</span>
                              <?= number_format($nilai_akhir ?? 0, 3) ?>

                            </div>
                            <button class="btn-favorite" onclick="toggleFavorite(<?= $row['id'] ?>, this)">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                        <div class="hotel-info">
                            <div class="hotel-header">
                                <h3><?= $row['nama_hotel'] ?></h3>
                                <div class="rating">
                                    <?php for ($i = 1; $i <= 5; $i++) { ?>
                                        <i class="fas fa-star <?= $i <= $row['rating_bintang'] ? 'active' : '' ?>"></i>
                                    <?php } ?>
                                    <span><?= $row['rating_bintang'] ?> Bintang</span>
                                </div>
                            </div>
                            <p class="location">
                                <i class="fas fa-map-marker-alt"></i>
                                <?= $row['alamat'] ?>
                                <span class="distance">(<?= $row['jarak_km'] ?> km dari pusat kota)</span>
                            </p>
                            <div class="facilities">
                                <?php foreach (array_slice($fasilitas, 0, 4) as $fasilitas_item) { ?>
                                    <span class="facility-tag"><?= trim($fasilitas_item) ?></span>
                                <?php } ?>
                                <?php if (count($fasilitas) > 4) { ?>
                                    <span class="facility-more">+<?= count($fasilitas) - 4 ?> lainnya</span>
                                <?php } ?>
                            </div>
                            <div class="hotel-footer">
                                <div class="price">
                                    <span class="price-label">Mulai dari</span>
                                    <span class="price-amount">Rp <?= number_format($row['harga_per_malam'], 0, ',', '.') ?></span>
                                    <span class="price-unit">/malam</span>
                                </div>
                                <button class="btn-select" onclick="window.location.href='detail_hotel.php?id=<?= $row['id'] ?>'">
                                    <i class="fas fa-eye"></i>
                                    Lihat Detail
                                </button>
                            </div>
                        </div>
                    </div>
                <?php
                    $rank++;
                }
                ?>

            </div>
        </div>
    </section>

    <!-- About SAW Section -->
    <section id="about" class="about-saw">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>Tentang Metode SAW</h2>
                    <p><strong>Simple Additive Weighting (SAW)</strong> adalah metode yang digunakan untuk menentukan alternatif terbaik dari sejumlah alternatif berdasarkan kriteria tertentu.</p>

                    <h3>Kriteria Penilaian Hotel:</h3>
                    <div class="criteria-list">
                        <div class="criteria-item">
                            <div class="criteria-icon">
                                <i class="fas fa-money-bill-wave"></i>
                            </div>
                            <div class="criteria-info">
                                <h4>Harga (40%)</h4>
                                <p>Harga kamar per malam - semakin murah semakin baik</p>
                            </div>
                        </div>
                        <div class="criteria-item">
                            <div class="criteria-icon">
                                <i class="fas fa-star"></i>
                            </div>
                            <div class="criteria-info">
                                <h4>Rating (35%)</h4>
                                <p>Rating bintang hotel - semakin tinggi semakin baik</p>
                            </div>
                        </div>
                        <div class="criteria-item">
                            <div class="criteria-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="criteria-info">
                                <h4>Jarak (25%)</h4>
                                <p>Jarak dari pusat kota - semakin dekat semakin baik</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="about-image">
                    <div class="saw-formula">
                        <h4>Rumus SAW:</h4>
                        <div class="formula">
                            <p>Vi = Σ (wj × rij)</p>
                            <small>Vi = Nilai alternatif<br>
                                wj = Bobot kriteria<br>
                                rij = Rating kinerja ternormalisasi</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-hotel"></i>
                        <span>SPK Hotel Mataram</span>
                    </div>
                    <p>Sistem Pendukung Keputusan untuk rekomendasi hotel terbaik di Kota Mataram menggunakan metode SAW.</p>
                </div>
                <div class="footer-section">
                    <h4>Kontak</h4>
                    <p><i class="fas fa-map-marker-alt"></i> Mataram, Nusa Tenggara Barat</p>
                    <p><i class="fas fa-envelope"></i> info@spkhotel.com</p>
                    <p><i class="fas fa-phone"></i> +62 370 123456</p>
                </div>
                <div class="footer-section">
                    <h4>Link Cepat</h4>
                    <ul>
                        <li><a href="#home">Beranda</a></li>
                        <li><a href="#hotels">Hotel</a></li>
                        <li><a href="#about">Tentang SAW</a></li>
                        <li><a href="login.php">Login</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 SPK Hotel Mataram. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('.header');
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Toggle Favorite
        function toggleFavorite(hotelId, button) {
            // Cek apakah user sudah login (dari session PHP atau localStorage)
            const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
            const userId = <?= $_SESSION['user_id'] ?? 'null' ?>;

            if (!isLoggedIn) {
                alert('Silakan login terlebih dahulu untuk menambahkan favorit!');
                window.location.href = 'login.php';
                return;
            }

            const icon = button.querySelector('i');
            const isFavorited = icon.classList.contains('fas');

            if (isFavorited) {
                // Remove from favorite
                icon.classList.remove('fas');
                icon.classList.add('far');
                button.classList.remove('favorited');
                showNotification('Hotel dihapus dari favorit', 'info');

                // Ajax call to remove from database
                removeFavorite(hotelId);
            } else {
                // Add to favorite
                icon.classList.remove('far');
                icon.classList.add('fas');
                button.classList.add('favorited');
                showNotification('Hotel ditambahkan ke favorit!', 'success');

                // Ajax call to add to database
                addFavorite(hotelId);
            }
        }

        // Add to favorite (Ajax)
        function addFavorite(hotelId) {
            fetch('ajax/add_favorite.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        hotel_id: hotelId,
                        user_id: <?= $_SESSION['user_id'] ?? 'null' ?>
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) {
                        console.error('Error adding favorite:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        // Remove from favorite (Ajax)
        function removeFavorite(hotelId) {
            fetch('ajax/remove_favorite.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        hotel_id: hotelId,
                        user_id: <?= $_SESSION['user_id'] ?? 'null' ?>
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) {
                        console.error('Error removing favorite:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        // Show notification
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            `;

            document.body.appendChild(notification);

            // Show notification
            setTimeout(() => notification.classList.add('show'), 100);

            // Hide notification after 3 seconds
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => document.body.removeChild(notification), 300);
            }, 3000);
        }

        // Show hotel detail - redirect to detail page
        function showHotelDetail(hotelId) {
            window.location.href = `detail_hotel.php?id=${hotelId}`;
        }

        // Toggle user dropdown
        function toggleUserDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');

            if (userMenu && !userMenu.contains(event.target)) {
                dropdown?.classList.remove('show');
            }
        });

        // Load user favorites on page load
        document.addEventListener('DOMContentLoaded', function() {
            const isLoggedIn = <?= isset($_SESSION['user_id']) ? 'true' : 'false' ?>;
            const userId = <?= $_SESSION['user_id'] ?? 'null' ?>;

            if (isLoggedIn && userId) {
                loadUserFavorites(userId);

                // Auto-save search history if there are search parameters
                const urlParams = new URLSearchParams(window.location.search);
                const hasSearchParams = urlParams.has('budget') || urlParams.has('rating') || urlParams.has('jarak');

                if (hasSearchParams) {
                    // Collect search parameters
                    const searchParams = {
                        budget: urlParams.get('budget') || '',
                        rating: urlParams.get('rating') || '',
                        jarak: urlParams.get('jarak') || ''
                    };

                    // Collect hotel results for SAW data
                    const hotelCards = document.querySelectorAll('.hotel-card');
                    const sawResults = [];

                    hotelCards.forEach((card, index) => {
                        const nameElement = card.querySelector('h3');
                        const priceElement = card.querySelector('.price-amount');
                        const sawScoreElement = card.querySelector('.saw-score strong');

                        if (nameElement && priceElement && sawScoreElement) {
                            const priceText = priceElement.textContent.replace(/[^\d]/g, '');
                            const sawScore = parseFloat(sawScoreElement.textContent);

                            sawResults.push({
                                ranking: index + 1,
                                nama_hotel: nameElement.textContent.trim(),
                                harga_per_malam: parseInt(priceText),
                                saw_score: sawScore
                            });
                        }
                    });

                    // Save search history
                    if (sawResults.length > 0) {
                        saveSearchHistory(searchParams, sawResults, sawResults.length);
                    }
                }
            }
        });

        // Save search history function
        function saveSearchHistory(searchParams, sawResults, totalHotels) {
            fetch('ajax/save_search_history.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        search_params: searchParams,
                        saw_results: sawResults,
                        total_hotels_found: totalHotels
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        console.log('Search history saved successfully');
                    } else {
                        console.error('Failed to save search history:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error saving search history:', error);
                });
        }

        // Load user favorites
        function loadUserFavorites(userId) {
            fetch(`ajax/get_favorites.php?user_id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.favorites) {
                        data.favorites.forEach(hotelId => {
                            const favoriteBtn = document.querySelector(`[onclick*="toggleFavorite(${hotelId}"]`);
                            if (favoriteBtn) {
                                const icon = favoriteBtn.querySelector('i');
                                icon.classList.remove('far');
                                icon.classList.add('fas');
                                favoriteBtn.classList.add('favorited');
                            }
                        });
                    }
                })
                .catch(error => {
                    console.error('Error loading favorites:', error);
                });
        }
    </script>
</body>

</html>