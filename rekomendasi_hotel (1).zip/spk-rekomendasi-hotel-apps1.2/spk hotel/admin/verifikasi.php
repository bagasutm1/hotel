<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

$order_id = $_GET['order_id'] ?? 0;

$sql = "UPDATE orders SET status = 'dibayar' WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);

echo "<script>alert('Order berhasil diverifikasi!'); window.location.href='orders.php';</script>";
exit();
