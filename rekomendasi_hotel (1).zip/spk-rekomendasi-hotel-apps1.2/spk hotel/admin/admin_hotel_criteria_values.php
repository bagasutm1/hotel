<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
  header('Location: ../login.php');
  exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'] ?? 'Admin';

// Handle Tambah
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tambah') {
  $hotel_id = intval($_POST['hotel_id']);
  $criteria_id = intval($_POST['criteria_id']);
  $nilai = floatval($_POST['nilai']);

  if ($hotel_id && $criteria_id && $nilai >= 0) {
    mysqli_query($conn, "INSERT INTO hotel_criteria_values (hotel_id, criteria_id, nilai) VALUES ($hotel_id, $criteria_id, $nilai)");
  }
  header("Location: admin_hotel_criteria_values.php");
  exit();
}

// Handle Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
  $id = intval($_POST['id']);
  $nilai = floatval($_POST['nilai']);
  mysqli_query($conn, "UPDATE hotel_criteria_values SET nilai = $nilai WHERE id = $id");
  header("Location: admin_hotel_criteria_values.php");
  exit();
}

// Handle Hapus
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'hapus') {
  $id = intval($_POST['id']);
  mysqli_query($conn, "DELETE FROM hotel_criteria_values WHERE id = $id");
  header("Location: admin_hotel_criteria_values.php");
  exit();
}

$hotels = mysqli_query($conn, "SELECT id, nama_hotel FROM hotels WHERE status = 'aktif'");
$criteria = mysqli_query($conn, "SELECT id, nama_kriteria FROM criteria");
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Kelola Nilai Hotel - SPK Hotel Mataram</title>
  <link rel="stylesheet" href="../assets/css/admin.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
  <?php include 'sidebar.php'; ?>
  <main class="main-content">
    <?php include "topbar.php" ?>
    <br><br>

    <div class="container-fluid">
      <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#modalTambah">
        <i class="fas fa-plus-circle"></i> Tambah Nilai
      </button>

      <!-- Modal Tambah -->
      <div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="modalTambahLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content bg-white">
            <form method="POST">
              <input type="hidden" name="action" value="tambah">
              <div class="modal-header">
                <h5 class="modal-title" id="modalTambahLabel">Tambah Nilai Hotel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <div class="mb-3">
                  <label class="form-label">Hotel</label>
                  <select name="hotel_id" class="form-select" required>
                    <option value="">-- Pilih Hotel --</option>
                    <?php while ($h = mysqli_fetch_assoc($hotels)): ?>
                      <option value="<?= $h['id'] ?>"><?= htmlspecialchars($h['nama_hotel']) ?></option>
                    <?php endwhile; ?>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label">Kriteria</label>
                  <select name="criteria_id" class="form-select" required>
                    <option value="">-- Pilih Kriteria --</option>
                    <?php mysqli_data_seek($criteria, 0); while ($c = mysqli_fetch_assoc($criteria)): ?>
                      <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nama_kriteria']) ?></option>
                    <?php endwhile; ?>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label">Nilai</label>
                  <input type="number" name="nilai" class="form-control" step="0.01" required>
                </div>
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <?php
      $criteria_all = mysqli_query($conn, "SELECT id, nama_kriteria FROM criteria ORDER BY nama_kriteria ASC");
      while ($k = mysqli_fetch_assoc($criteria_all)):
        $kriteria_id = $k['id'];
        $kriteria_nama = $k['nama_kriteria'];

        $nilai_sql = "SELECT hcv.*, h.nama_hotel FROM hotel_criteria_values hcv
                      JOIN hotels h ON hcv.hotel_id = h.id
                      WHERE hcv.criteria_id = $kriteria_id
                      ORDER BY hcv.created_at DESC";
        $nilai_result = mysqli_query($conn, $nilai_sql);
      ?>

      <h5 class="mt-5">Kriteria: <?= htmlspecialchars($kriteria_nama) ?></h5>
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead class="table-primary text-center">
            <tr>
              <th>ID</th>
              <th>Hotel</th>
              <th>Nilai</th>
              <th>Waktu</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if (mysqli_num_rows($nilai_result) > 0): ?>
              <?php while ($row = mysqli_fetch_assoc($nilai_result)): ?>
                <tr>
                  <td class="text-center"><?= $row['id'] ?></td>
                  <td><?= htmlspecialchars($row['nama_hotel']) ?></td>
                  <td class="text-center"><?= number_format($row['nilai'], 2) ?></td>
                  <td><?= date('d M Y H:i', strtotime($row['created_at'])) ?></td>
                  <td class="text-center">
                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $row['id'] ?>">
                      <i class="fas fa-edit"></i>
                    </button>
                    <form method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                      <input type="hidden" name="action" value="hapus">
                      <input type="hidden" name="id" value="<?= $row['id'] ?>">
                      <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                  </td>
                </tr>

                <div class="modal fade" id="modalEdit<?= $row['id'] ?>" tabindex="-1" aria-labelledby="modalEditLabel<?= $row['id'] ?>" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content bg-white">
                      <form method="POST">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <div class="modal-header">
                          <h5 class="modal-title" id="modalEditLabel<?= $row['id'] ?>">Edit Nilai</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <div class="mb-3">
                            <label class="form-label">Nilai</label>
                            <input type="number" name="nilai" class="form-control" value="<?= $row['nilai'] ?>" step="0.01" required>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Simpan</button>
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5" class="text-center">Belum ada data.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php endwhile; ?>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
