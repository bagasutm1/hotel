<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'] ?? 'Admin';


// Handle CRUD operations
$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $result = addCriteria($_POST);
                break;
            case 'edit':
                $result = editCriteria($_POST);
                break;
            case 'delete':
                $result = deleteCriteria($_POST['criteria_id']);
                break;
            case 'update_weights':
                $result = updateWeights($_POST);
                break;
        }
        
        if ($result) {
            $message = $result['message'];
            $message_type = $result['type'];
        }
    }
}

// Handle AJAX requests
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    
    switch ($_GET['ajax']) {
        case 'get_criteria':
            $criteria_id = intval($_GET['id']);
            $criteria = getCriteriaById($criteria_id);
            echo json_encode($criteria);
            exit();
            
        case 'check_kode':
            $kode = mysqli_real_escape_string($conn, $_GET['kode']);
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            $exists = checkKodeExists($kode, $id);
            echo json_encode(['exists' => $exists]);
            exit();
    }
}

// Function to add criteria
function addCriteria($data) {
    global $conn;
    
    $nama_kriteria = mysqli_real_escape_string($conn, $data['nama_kriteria']);
    $kode_kriteria = mysqli_real_escape_string($conn, strtoupper($data['kode_kriteria']));
    $bobot = floatval($data['bobot']);
    $jenis_kriteria = mysqli_real_escape_string($conn, $data['jenis_kriteria']);
    $deskripsi = mysqli_real_escape_string($conn, $data['deskripsi']);
    $satuan = mysqli_real_escape_string($conn, $data['satuan']);
    
    // Validasi bobot
    if ($bobot <= 0 || $bobot > 1) {
        return array('message' => 'Bobot harus antara 0.01 - 1.00', 'type' => 'error');
    }
    
    // Check if kode already exists
    if (checkKodeExists($kode_kriteria)) {
        return array('message' => 'Kode kriteria sudah digunakan', 'type' => 'error');
    }
    
    // Check total weight
    $current_total = getTotalWeight();
    if (($current_total + $bobot) > 1) {
        $remaining = 1 - $current_total;
        return array('message' => "Bobot melebihi batas. Sisa bobot tersedia: " . number_format($remaining, 2), 'type' => 'error');
    }
    
    $sql = "INSERT INTO criteria (nama_kriteria, kode_kriteria, bobot, jenis_kriteria, deskripsi, satuan) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssdsss", $nama_kriteria, $kode_kriteria, $bobot, $jenis_kriteria, $deskripsi, $satuan);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Kriteria berhasil ditambahkan!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal menambahkan kriteria: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to edit criteria
function editCriteria($data) {
    global $conn;
    
    $criteria_id = intval($data['criteria_id']);
    $nama_kriteria = mysqli_real_escape_string($conn, $data['nama_kriteria']);
    $kode_kriteria = mysqli_real_escape_string($conn, strtoupper($data['kode_kriteria']));
    $bobot = floatval($data['bobot']);
    $jenis_kriteria = mysqli_real_escape_string($conn, $data['jenis_kriteria']);
    $deskripsi = mysqli_real_escape_string($conn, $data['deskripsi']);
    $satuan = mysqli_real_escape_string($conn, $data['satuan']);
    
    // Validasi bobot
    if ($bobot <= 0 || $bobot > 1) {
        return array('message' => 'Bobot harus antara 0.01 - 1.00', 'type' => 'error');
    }
    
    // Check if kode already exists (exclude current record)
    if (checkKodeExists($kode_kriteria, $criteria_id)) {
        return array('message' => 'Kode kriteria sudah digunakan', 'type' => 'error');
    }
    
    // Check total weight (exclude current record)
    $current_total = getTotalWeight($criteria_id);
    if (($current_total + $bobot) > 1) {
        $remaining = 1 - $current_total;
        return array('message' => "Bobot melebihi batas. Sisa bobot tersedia: " . number_format($remaining, 2), 'type' => 'error');
    }
    
    $sql = "UPDATE criteria SET 
            nama_kriteria = ?, kode_kriteria = ?, bobot = ?, jenis_kriteria = ?, 
            deskripsi = ?, satuan = ?, updated_at = NOW()
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssdsssi", $nama_kriteria, $kode_kriteria, $bobot, $jenis_kriteria, $deskripsi, $satuan, $criteria_id);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Kriteria berhasil diperbarui!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal memperbarui kriteria: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to delete criteria
function deleteCriteria($criteria_id) {
    global $conn;
    
    // Check if criteria is used in hotel_criteria_values
    $check_sql = "SELECT COUNT(*) as count FROM hotel_criteria_values WHERE criteria_id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "i", $criteria_id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    $check_data = mysqli_fetch_assoc($check_result);
    
    if ($check_data['count'] > 0) {
        return array('message' => 'Kriteria tidak dapat dihapus karena sedang digunakan oleh hotel', 'type' => 'error');
    }
    
    $sql = "DELETE FROM criteria WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $criteria_id);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Kriteria berhasil dihapus!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal menghapus kriteria: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to update weights
function updateWeights($data) {
    global $conn;
    
    $weights = $data['weights'];
    $total_weight = 0;
    
    // Calculate total weight
    foreach ($weights as $weight) {
        $total_weight += floatval($weight);
    }
    
    // Validate total weight
    if (abs($total_weight - 1.0) > 0.001) {
        return array('message' => 'Total bobot harus sama dengan 1.00. Total saat ini: ' . number_format($total_weight, 3), 'type' => 'error');
    }
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        foreach ($weights as $criteria_id => $weight) {
            $sql = "UPDATE criteria SET bobot = ?, updated_at = NOW() WHERE id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "di", $weight, $criteria_id);
            
            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Gagal update bobot kriteria ID: ' . $criteria_id);
            }
        }
        
        mysqli_commit($conn);
        return array('message' => 'Bobot kriteria berhasil diperbarui!', 'type' => 'success');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return array('message' => 'Gagal memperbarui bobot: ' . $e->getMessage(), 'type' => 'error');
    }
}

// Helper functions
function getCriteriaById($criteria_id) {
    global $conn;
    
    $sql = "SELECT * FROM criteria WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $criteria_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    return mysqli_fetch_assoc($result);
}

function checkKodeExists($kode, $exclude_id = 0) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM criteria WHERE kode_kriteria = ?";
    if ($exclude_id > 0) {
        $sql .= " AND id != ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($exclude_id > 0) {
        mysqli_stmt_bind_param($stmt, "si", $kode, $exclude_id);
    } else {
        mysqli_stmt_bind_param($stmt, "s", $kode);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    
    return $data['count'] > 0;
}

function getTotalWeight($exclude_id = 0) {
    global $conn;
    
    $sql = "SELECT SUM(bobot) as total FROM criteria";
    if ($exclude_id > 0) {
        $sql .= " WHERE id != ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($exclude_id > 0) {
        mysqli_stmt_bind_param($stmt, "i", $exclude_id);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    
    return floatval($data['total']);
}

// Get all criteria
$criteria_sql = "SELECT c.*, 
                 (SELECT COUNT(*) FROM hotel_criteria_values hcv WHERE hcv.criteria_id = c.id) as usage_count
                 FROM criteria c 
                 ORDER BY c.kode_kriteria";
$criteria_result = mysqli_query($conn, $criteria_sql);
$criteria_list = mysqli_fetch_all($criteria_result, MYSQLI_ASSOC);

// Calculate total weight
$total_weight = getTotalWeight();
$remaining_weight = 1 - $total_weight;

// Get statistics
$total_hotels_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'")->fetch_assoc()['total'];
$total_users_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$total_criteria_count = count($criteria_list);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kriteria SAW - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Additional styles for criteria management */
        .criteria-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
            border: 1px solid #e9ecef;
            margin-bottom: 1.5rem;
        }
        
        .criteria-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .criteria-header {
            background: linear-gradient(135deg, #0052cc, #0066ff);
            color: white;
            padding: 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .criteria-code {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .criteria-type {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            text-transform: uppercase;
            font-weight: 500;
        }
        
        .criteria-content {
            padding: 1.5rem;
        }
        
        .criteria-name {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .criteria-description {
            color: #666;
            margin-bottom: 1rem;
            line-height: 1.5;
        }
        
        .criteria-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .criteria-detail {
            text-align: center;
            padding: 0.75rem;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .criteria-detail-value {
            font-size: 1.1rem;
            font-weight: 600;
            color: #0052cc;
            margin-bottom: 0.25rem;
        }
        
        .criteria-detail-label {
            font-size: 0.8rem;
            color: #666;
            text-transform: uppercase;
        }
        
        .criteria-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
            border-top: 1px solid #e9ecef;
            padding-top: 1rem;
        }
        
        .weight-summary {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            border: 1px solid #e9ecef;
            margin-bottom: 2rem;
        }
        
        .weight-summary-header {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 1.5rem;
            border-radius: 12px 12px 0 0;
        }
        
        .weight-summary-content {
            padding: 1.5rem;
        }
        
        .weight-progress {
            background: #e9ecef;
            border-radius: 10px;
            height: 20px;
            margin: 1rem 0;
            overflow: hidden;
            position: relative;
        }
        
        .weight-progress-bar {
            background: linear-gradient(90deg, #28a745, #20c997);
            height: 100%;
            transition: width 0.3s ease;
            border-radius: 10px;
        }
        
        .weight-progress-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 0.8rem;
            font-weight: 600;
            color: white;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }
        
        .weight-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .weight-item {
            text-align: center;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .weight-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: #0052cc;
        }
        
        .weight-label {
            font-size: 0.9rem;
            color: #666;
            margin-top: 0.25rem;
        }
        
        .criteria-empty {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            border: 1px solid #e9ecef;
        }
        
        .criteria-empty i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 1rem;
        }
        
        .bulk-weight-editor {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            border: 1px solid #e9ecef;
            margin-bottom: 2rem;
        }
        
        .bulk-weight-header {
            background: linear-gradient(135deg, #6f42c1, #7952b3);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .bulk-weight-content {
            padding: 1.5rem;
        }
        
        .weight-input-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .weight-input-item {
            padding: 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .weight-input-label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: #333;
        }
        
        .weight-input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            text-align: center;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: #0052cc;
            color: white;
        }
        
        .btn-primary:hover {
            background: #003d99;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background: #e0a800;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .btn-purple {
            background: #6f42c1;
            color: white;
        }
        
        .btn-purple:hover {
            background: #5a2d91;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            padding: 1.5rem;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #0052cc;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        
        .criteria-header-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        @media (max-width: 768px) {
            .criteria-details {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .weight-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .weight-input-grid {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .criteria-header {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            
            .criteria-header-actions {
                flex-direction: column;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
         <?php include "sidebar.php" ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
             <?php include "topbar.php" ?>

            <!-- Criteria Content -->
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?>">
                        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Weight Summary -->
                <div class="weight-summary">
                    <div class="weight-summary-header">
                        <h3><i class="fas fa-balance-scale"></i> Ringkasan Bobot Kriteria</h3>
                        <div class="criteria-header-actions" style="margin-top: 10px;">
                            <!-- <button class="btn btn-success" onclick="openAddModal()">
                                <i class="fas fa-plus"></i> Tambah Kriteria
                            </button> -->
                            <?php if (!empty($criteria_list)): ?>
                                <button class="btn btn-purple" onclick="openWeightEditor()">
                                    <i class="fas fa-edit"></i> Edit Bobot
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="weight-summary-content">
                        <div class="weight-progress">
                            <div class="weight-progress-bar" style="width: <?= $total_weight * 100 ?>%"></div>
                            <div class="weight-progress-text">
                                <?= number_format($total_weight * 100, 1) ?>% dari 100%
                            </div>
                        </div>
                        
                        <div class="weight-grid">
                            <div class="weight-item">
                                <div class="weight-value"><?= number_format($total_weight, 3) ?></div>
                                <div class="weight-label">Total Bobot</div>
                            </div>
                            <div class="weight-item">
                                <div class="weight-value"><?= number_format($remaining_weight, 3) ?></div>
                                <div class="weight-label">Sisa Bobot</div>
                            </div>
                            <div class="weight-item">
                                <div class="weight-value"><?= $total_criteria_count ?></div>
                                <div class="weight-label">Total Kriteria</div>
                            </div>
                            <div class="weight-item">
                                <div class="weight-value" style="color: <?= abs($total_weight - 1.0) < 0.001 ? '#28a745' : '#dc3545' ?>">
                                    <?= abs($total_weight - 1.0) < 0.001 ? 'Valid' : 'Invalid' ?>
                                </div>
                                <div class="weight-label">Status Bobot</div>
                            </div>
                        </div>
                        
                        <?php if (abs($total_weight - 1.0) > 0.001): ?>
                            <div style="margin-top: 1rem; padding: 1rem; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 6px; color: #856404;">
                                <i class="fas fa-exclamation-triangle"></i>
                                <strong>Peringatan:</strong> Total bobot kriteria harus sama dengan 1.00 untuk perhitungan SAW yang valid.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Bulk Weight Editor -->
                <?php if (!empty($criteria_list)): ?>
                    <div class="bulk-weight-editor" id="bulkWeightEditor" style="display: none;">
                        <div class="bulk-weight-header">
                            <h3><i class="fas fa-edit"></i> Editor Bobot Kriteria</h3>
                            <button class="btn" style="background: rgba(255,255,255,0.2);" onclick="closeWeightEditor()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <form id="weightForm" method="POST">
                            <div class="bulk-weight-content">
                                <input type="hidden" name="action" value="update_weights">
                                
                                <div class="weight-input-grid">
                                    <?php foreach ($criteria_list as $criteria): ?>
                                        <div class="weight-input-item">
                                            <div class="weight-input-label">
                                                <?= htmlspecialchars($criteria['kode_kriteria']) ?> - <?= htmlspecialchars($criteria['nama_kriteria']) ?>
                                            </div>
                                            <input type="number" name="weights[<?= $criteria['id'] ?>]" 
                                                   class="weight-input" value="<?= $criteria['bobot'] ?>" 
                                                   step="0.001" min="0" max="1" required
                                                   onchange="updateWeightTotal()">
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                
                                <div style="padding: 1rem; background: #f8f9fa; border-radius: 8px; margin-bottom: 1rem;">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span><strong>Total Bobot:</strong></span>
                                        <span id="weightTotal" style="font-size: 1.2rem; font-weight: bold;">0.000</span>
                                    </div>
                                </div>
                                
                                <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                                    <button type="button" class="btn" style="background: #6c757d; color: white;" onclick="closeWeightEditor()">
                                        Batal
                                    </button>
                                    <button type="submit" class="btn btn-purple">
                                        <i class="fas fa-save"></i> Simpan Bobot
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>

                <!-- Criteria List -->
                <?php if (!empty($criteria_list)): ?>
                    <div class="criteria-list">
                        <?php foreach ($criteria_list as $criteria): ?>
                            <div class="criteria-card">
                                <div class="criteria-header">
                                    <div>
                                        <div class="criteria-code"><?= htmlspecialchars($criteria['kode_kriteria']) ?></div>
                                    </div>
                                    <div class="criteria-type <?= $criteria['jenis_kriteria'] ?>">
                                        <?= $criteria['jenis_kriteria'] === 'benefit' ? 'Benefit' : 'Cost' ?>
                                    </div>
                                </div>
                                
                                <div class="criteria-content">
                                    <div class="criteria-name"><?= htmlspecialchars($criteria['nama_kriteria']) ?></div>
                                    <div class="criteria-description">
                                        <?= htmlspecialchars($criteria['deskripsi'] ?: 'Tidak ada deskripsi') ?>
                                    </div>
                                    
                                    <div class="criteria-details">
                                        <div class="criteria-detail">
                                            <div class="criteria-detail-value"><?= number_format($criteria['bobot'], 3) ?></div>
                                            <div class="criteria-detail-label">Bobot</div>
                                        </div>
                                        <div class="criteria-detail">
                                            <div class="criteria-detail-value"><?= number_format($criteria['bobot'] * 100, 1) ?>%</div>
                                            <div class="criteria-detail-label">Persentase</div>
                                        </div>
                                        <div class="criteria-detail">
                                            <div class="criteria-detail-value"><?= htmlspecialchars($criteria['satuan'] ?: '-') ?></div>
                                            <div class="criteria-detail-label">Satuan</div>
                                        </div>
                                        <div class="criteria-detail">
                                            <div class="criteria-detail-value"><?= $criteria['usage_count'] ?></div>
                                            <div class="criteria-detail-label">Digunakan</div>
                                        </div>
                                    </div>
                                    
                                    <div class="criteria-actions">
                                        <button class="btn btn-warning" onclick="editCriteria(<?= $criteria['id'] ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <?php if ($criteria['usage_count'] == 0): ?>
                                            <button class="btn btn-danger" onclick="deleteCriteria(<?= $criteria['id'] ?>, '<?= htmlspecialchars($criteria['nama_kriteria']) ?>')">
                                                <i class="fas fa-trash"></i> Hapus
                                            </button>
                                        <?php else: ?>
                                            <button class="btn" style="background: #6c757d; color: white;" disabled title="Kriteria sedang digunakan">
                                                <i class="fas fa-lock"></i> Terkunci
                                            </button>
                                        <?php endif; ?>
                                        <!-- <button class="btn btn-primary" onclick="viewCriteriaDetails(<?= $criteria['id'] ?>)">
                                            <i class="fas fa-eye"></i> Detail
                                        </button> -->
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="criteria-empty">
                        <i class="fas fa-sliders-h"></i>
                        <h3 style="color: #666; margin-bottom: 0.5rem;">Belum ada kriteria yang terdaftar</h3>
                        <p style="color: #999;">Mulai dengan menambahkan kriteria pertama untuk sistem SAW</p>
                        <button class="btn btn-success" onclick="openAddModal()" style="margin-top: 1rem;">
                            <i class="fas fa-plus"></i> Tambah Kriteria Pertama
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay" onclick="closeMobileSidebar()"></div>

    <!-- Add/Edit Criteria Modal -->
    <div class="modal" id="criteriaModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Tambah Kriteria</h3>
                <button type="button" onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="criteriaForm" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="criteria_id" id="criteriaId">
                    
                    <div class="form-group">
                        <label class="form-label">Nama Kriteria *</label>
                        <input type="text" name="nama_kriteria" id="namaKriteria" class="form-control" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Kode Kriteria *</label>
                            <input type="text" name="kode_kriteria" id="kodeKriteria" class="form-control" 
                                   placeholder="C1, C2, C3..." required style="text-transform: uppercase;"
                                   onblur="checkKodeExists()">
                            <small id="kodeMessage" style="display: none;"></small>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Jenis Kriteria *</label>
                            <select name="jenis_kriteria" id="jenisKriteria" class="form-control" required>
                                <option value="">Pilih Jenis</option>
                                <option value="benefit">Benefit (Semakin besar semakin baik)</option>
                                <option value="cost">Cost (Semakin kecil semakin baik)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Bobot *</label>
                            <input type="number" name="bobot" id="bobot" class="form-control" 
                                   step="0.001" min="0.001" max="1" required>
                            <small style="color: #666;">Sisa bobot tersedia: <span id="remainingWeight"><?= number_format($remaining_weight, 3) ?></span></small>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Satuan</label>
                            <input type="text" name="satuan" id="satuan" class="form-control" placeholder="Rupiah, Meter, Poin...">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3" 
                                  placeholder="Jelaskan kriteria ini..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closeModal()" class="btn" style="background: #6c757d; color: white;">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Sidebar functionality
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');

        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });

        mobileSidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('mobile-open');
            mobileOverlay.classList.add('active');
        });

        function closeMobileSidebar() {
            sidebar.classList.remove('mobile-open');
            mobileOverlay.classList.remove('active');
        }

        // Load sidebar state
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        // Admin dropdown
        function toggleAdminDropdown() {
            const dropdown = document.getElementById('adminDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('adminDropdown');
            const toggle = document.querySelector('.admin-dropdown-toggle');
            
            if (toggle && !toggle.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Modal functions
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Tambah Kriteria';
            document.getElementById('formAction').value = 'add';
            document.getElementById('criteriaForm').reset();
            document.getElementById('criteriaId').value = '';
            document.getElementById('kodeMessage').style.display = 'none';
            
            // Update remaining weight
            updateRemainingWeight();
            
            document.getElementById('criteriaModal').classList.add('show');
        }

        function editCriteria(criteriaId) {
            document.getElementById('modalTitle').textContent = 'Edit Kriteria';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('criteriaId').value = criteriaId;
            
            // Fetch criteria data
            fetch(`criteria.php?ajax=get_criteria&id=${criteriaId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('namaKriteria').value = data.nama_kriteria || '';
                        document.getElementById('kodeKriteria').value = data.kode_kriteria || '';
                        document.getElementById('jenisKriteria').value = data.jenis_kriteria || '';
                        document.getElementById('bobot').value = data.bobot || '';
                        document.getElementById('satuan').value = data.satuan || '';
                        document.getElementById('deskripsi').value = data.deskripsi || '';
                        
                        // Update remaining weight for edit
                        updateRemainingWeight(data.bobot);
                        
                        document.getElementById('criteriaModal').classList.add('show');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Gagal mengambil data kriteria');
                });
        }

        function closeModal() {
            document.getElementById('criteriaModal').classList.remove('show');
        }

        function deleteCriteria(criteriaId, criteriaName) {
            if (confirm(`Apakah Anda yakin ingin menghapus kriteria "${criteriaName}"?\n\nTindakan ini tidak dapat dibatalkan.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="criteria_id" value="${criteriaId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function viewCriteriaDetails(criteriaId) {
            // This can be implemented to show detailed view
            alert('Fitur detail kriteria akan segera hadir!');
        }

        // Weight editor functions
        function openWeightEditor() {
            document.getElementById('bulkWeightEditor').style.display = 'block';
            updateWeightTotal();
        }

        function closeWeightEditor() {
            document.getElementById('bulkWeightEditor').style.display = 'none';
        }

        function updateWeightTotal() {
            const inputs = document.querySelectorAll('.weight-input');
            let total = 0;
            
            inputs.forEach(input => {
                total += parseFloat(input.value) || 0;
            });
            
            const totalElement = document.getElementById('weightTotal');
            totalElement.textContent = total.toFixed(3);
            
            // Color coding
            if (Math.abs(total - 1.0) < 0.001) {
                totalElement.style.color = '#28a745'; // Green
            } else {
                totalElement.style.color = '#dc3545'; // Red
            }
        }

        // Check kode exists
        function checkKodeExists() {
            const kode = document.getElementById('kodeKriteria').value.toUpperCase();
            const criteriaId = document.getElementById('criteriaId').value || 0;
            const messageElement = document.getElementById('kodeMessage');
            
            if (kode) {
                fetch(`criteria.php?ajax=check_kode&kode=${encodeURIComponent(kode)}&id=${criteriaId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            messageElement.textContent = 'Kode kriteria sudah digunakan';
                            messageElement.style.color = '#dc3545';
                            messageElement.style.display = 'block';
                        } else {
                            messageElement.style.display = 'none';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            } else {
                messageElement.style.display = 'none';
            }
        }

        function updateRemainingWeight(excludeWeight = 0) {
            const currentTotal = <?= $total_weight ?>;
            const remaining = 1 - (currentTotal - excludeWeight);
            document.getElementById('remainingWeight').textContent = remaining.toFixed(3);
        }

        // Auto uppercase kode input
        document.getElementById('kodeKriteria').addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });

        // Close modals when clicking outside
        document.addEventListener('click', function(event) {
            const criteriaModal = document.getElementById('criteriaModal');
            
            if (event.target === criteriaModal) {
                closeModal();
            }
        });

        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);

        // Initialize weight total on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (document.getElementById('weightTotal')) {
                updateWeightTotal();
            }
        });
    </script>
</body>
</html>