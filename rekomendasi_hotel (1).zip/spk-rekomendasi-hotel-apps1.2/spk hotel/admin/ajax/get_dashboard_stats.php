<?php
// admin/ajax/get_dashboard_stats.php
session_start();
header('Content-Type: application/json');
include '../../koneksi.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

try {
    // Get current statistics
    $stats = [];
    
    // Total hotels
    $total_hotels_sql = "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'";
    $total_hotels_result = mysqli_query($conn, $total_hotels_sql);
    $stats['total_hotels'] = mysqli_fetch_assoc($total_hotels_result)['total'];
    
    // Total users
    $total_users_sql = "SELECT COUNT(*) as total FROM users";
    $total_users_result = mysqli_query($conn, $total_users_sql);
    $stats['total_users'] = mysqli_fetch_assoc($total_users_result)['total'];
    
    // Searches today
    $searches_today_sql = "SELECT COUNT(*) as total FROM search_history WHERE DATE(created_at) = CURDATE()";
    $searches_today_result = mysqli_query($conn, $searches_today_sql);
    $stats['searches_today'] = mysqli_fetch_assoc($searches_today_result)['total'];
    
    // Total favorites
    $total_favorites_sql = "SELECT COUNT(*) as total FROM user_favorites";
    $total_favorites_result = mysqli_query($conn, $total_favorites_sql);
    $stats['total_favorites'] = mysqli_fetch_assoc($total_favorites_result)['total'];
    
    // Recent searches (last hour)
    $recent_searches_sql = "SELECT COUNT(*) as total FROM search_history WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    $recent_searches_result = mysqli_query($conn, $recent_searches_sql);
    $stats['recent_searches'] = mysqli_fetch_assoc($recent_searches_result)['total'];
    
    // New users today
    $new_users_today_sql = "SELECT COUNT(*) as total FROM users WHERE DATE(created_at) = CURDATE()";
    $new_users_today_result = mysqli_query($conn, $new_users_today_sql);
    $stats['new_users_today'] = mysqli_fetch_assoc($new_users_today_result)['total'];
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching statistics: ' . $e->getMessage()
    ]);
}

mysqli_close($conn);
?>