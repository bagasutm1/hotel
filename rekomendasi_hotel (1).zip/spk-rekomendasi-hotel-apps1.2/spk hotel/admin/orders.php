<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'] ?? 'Admin';




// Handle CRUD operations
$message = '';
$message_type = '';

// Get orders with pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 12;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$where_clause = '';
if (!empty($search)) {
    $where_clause = "WHERE id LIKE '%$search%' OR user_id LIKE '%$search%' OR hotel_id LIKE '%$search%'";
}

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM orders $where_clause";
$count_result = mysqli_query($conn, $count_sql);
$total_orders = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_orders / $limit);

// Get orders
$orders_sql = "
    SELECT o.*, u.nama_lengkap AS nama_user, h.nama_hotel 
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN hotels h ON o.hotel_id = h.id
    $where_clause
    ORDER BY o.created_at DESC
    LIMIT $limit OFFSET $offset
";

$orders_result = mysqli_query($conn, $orders_sql);
$orders = mysqli_fetch_all($orders_result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Order - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .analytics-container {
            padding: 20px;
        }

        .analytics-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .date-filter {
            display: flex;
            gap: 10px;
        }

        .filter-btn {
            padding: 8px 16px;
            background: white;
            border: 2px solid #e1e5e9;
            border-radius: 6px;
            text-decoration: none;
            color: #495057;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .filter-btn.active {
            background: #0052cc;
            color: white;
            border-color: #0052cc;
        }

        .filter-btn:hover {
            border-color: #0052cc;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #0052cc;
        }

        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #0052cc;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 16px;
            color: #6c757d;
            margin-bottom: 10px;
        }

        .stat-change {
            font-size: 14px;
            color: #28a745;
        }

        .analytics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .analytics-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card-title i {
            color: #0052cc;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th,
        .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e1e5e9;
        }

        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }

        .data-table tr:hover {
            background: #f8f9fa;
        }

        .rating-stars {
            color: #ffc107;
        }

        .trend-chart {
            display: flex;
            align-items: end;
            gap: 5px;
            height: 150px;
            padding: 10px 0;
        }

        .trend-bar {
            background: linear-gradient(180deg, #0052cc, #667eea);
            min-width: 20px;
            border-radius: 3px 3px 0 0;
            position: relative;
            transition: all 0.3s ease;
        }

        .trend-bar:hover {
            opacity: 0.8;
        }

        .trend-label {
            position: absolute;
            bottom: -25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 11px;
            color: #6c757d;
            white-space: nowrap;
        }

        .trend-value {
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 11px;
            color: #495057;
            font-weight: 500;
        }

        .activity-timeline {
            max-height: 400px;
            overflow-y: auto;
        }

        .activity-item {
            display: flex;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #e9ecef;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .activity-icon.user {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .activity-icon.search {
            background: rgba(0, 82, 204, 0.1);
            color: #0052cc;
        }

        .activity-content {
            flex: 1;
        }

        .activity-title {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 3px;
        }

        .activity-description {
            color: #6c757d;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .activity-time {
            color: #adb5bd;
            font-size: 12px;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 3em;
            margin-bottom: 15px;
            opacity: 0.3;
        }

        @media (max-width: 768px) {
            .analytics-header {
                flex-direction: column;
                align-items: stretch;
            }

            .date-filter {
                justify-content: center;
                flex-wrap: wrap;
            }

            .analytics-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>


   
</head>

<body>
    <?php
    $active_page = 'orders';
    ?>
    <div class="admin-container">

        <!-- Sidebar -->
        <?php include "sidebar.php" ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <?php include "topbar.php" ?>

            <!-- Orders Content -->
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?>">
                        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Search Box -->
                <div class="search-box">
                    <form method="GET" class="search-form" style="display: flex; gap: 1rem;">
                        <input type="text" name="search" class="search-input" placeholder="Cari order..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i>
                        </button>
                        <?php if ($search): ?>
                            <a href="orders.php" class="btn btn-warning">
                                <i class="fas fa-times"></i> Clear
                            </a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Orders Table -->
                <div class="table-responsive mt-4">
                    <table class="table table-striped table-hover table-bordered align-middle">
                        <thead class="table-primary text-center">
                            <tr>
                                <th>ID</th>
                                <th>User ID</th>
                                <th>Hotel ID</th>
                                <th>Check-in</th>
                                <th>Check-out</th>
                                <th>Kamar</th>
                                <th>Dipesan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($orders)): ?>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td class="text-center"><?= htmlspecialchars($order['id']) ?></td>
                                        <td><?= htmlspecialchars($order['nama_user']) ?></td>
                                        <td><?= htmlspecialchars($order['nama_hotel']) ?></td>
                                        <td><?= date('d M Y', strtotime($order['tanggal_checkin'])) ?></td>
                                        <td><?= date('d M Y', strtotime($order['tanggal_checkout'])) ?></td>
                                        <td class="text-center"><?= htmlspecialchars($order['jumlah_kamar']) ?></td>
                                        <td><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                                        <td class="text-center">
                                            <?php
                                            $status = strtolower($order['status']);
                                            ?>
                                            <span class="status-badge status-<?= $status ?>">
                                                <?= ucfirst(str_replace('_', ' ', $status)) ?>
                                            </span>

                                        </td>
                                        <td class="text-center">
                                            <?php if ($order['status'] === 'belum_dibayar'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="approve_payment">
                                                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-success" title="Setujui Pembayaran">
                                                        <i class="fas fa-check-circle"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            <a href="detail_order.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-info" title="Lihat Detail">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center text-muted">Tidak ada data order</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>



                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?= $page - 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                <i class="fas fa-chevron-left"></i>
                            </a>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?= $i ?></span>
                            <?php else: ?>
                                <a href="?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?= $page + 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <style>
                .dashboard-content {
                    padding: 20px;
                    background-color: #f8f9fa;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }

                .search-box {
                    margin-bottom: 20px;
                }

                .search-input {
                    padding: 10px;
                    border: 1px solid #ced4da;
                    border-radius: 4px;
                    width: 300px;
                }

                .order-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 1rem;
                }

                .order-table th,
                .order-table td {
                    border: 1px solid #e9ecef;
                    padding: 0.75rem;
                    text-align: left;
                }

                .order-table th {
                    background-color: #007bff;
                    color: white;
                }

                .status-badge {
                    display: inline-block;
                    padding: 0.35em 0.75em;
                    font-size: 0.75rem;
                    font-weight: 600;
                    line-height: 1;
                    color: #fff;
                    text-align: center;
                    white-space: nowrap;
                    vertical-align: baseline;
                    border-radius: 999px;
                    text-transform: capitalize;
                }

                .status-belum_dibayar {
                    background-color: #ffc107;
                    color: #212529;
                }

                .status-diproses {
                    background-color: #17a2b8;
                    color: white;
                }

                .status-dibayar {
                    background-color: #28a745;
                    color: white;
                }


                .pagination {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    gap: 0.5rem;
                    margin-top: 20px;
                }

                .pagination a,
                .pagination span {
                    padding: 0.5rem 1rem;
                    border: 1px solid #e9ecef;
                    border-radius: 6px;
                    text-decoration: none;
                    color: #333;
                    transition: all 0.3s ease;
                }

                .pagination a:hover {
                    background: #e9ecef;
                }

                .pagination .current {
                    background: #007bff;
                    color: white;
                    border-color: #007bff;
                }

                .btn {
                    padding: 0.5rem 1rem;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    text-decoration: none;
                    font-size: 0.9rem;
                    transition: all 0.3s ease;
                    display: inline-flex;
                    align-items: center;
                    gap: 0.5rem;
                }

                .btn-primary {
                    background: #007bff;
                    color: white;
                }

                .btn-primary:hover {
                    background: #0056b3;
                }

                .btn-warning {
                    background: #ffc107;
                    color: #212529;
                }

                .btn-warning:hover {
                    background: #e0a800;
                }

                .btn-info {
                    background: #17a2b8;
                    color: white;
                }

                .btn-info:hover {
                    background: #138496;
                }

                .btn-danger {
                    background: #dc3545;
                    color: white;
                }

                .btn-danger:hover {
                    background: #c82333;
                }
            </style>

        </main>
    </div>

    <script>
        function viewOrder(orderId) {
            // Implement view order functionality
            alert('View order ID: ' + orderId);
        }

        function deleteOrder(orderId, orderName) {
            if (confirm('Apakah Anda yakin ingin menghapus ' + orderName + '?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete_order">
                    <input type="hidden" name="order_id" value="${orderId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</body>

</html>