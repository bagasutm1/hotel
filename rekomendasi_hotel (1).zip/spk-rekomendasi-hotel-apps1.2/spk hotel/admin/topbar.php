
<header class="topbar">
    <div class="topbar-left">
        <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
            <i class="fas fa-bars"></i>
        </button>
        <h1 class="page-title">Dashboard</h1>
    </div>
    <div class="topbar-right">
        <div class="topbar-item">
            <a href="../index.php" class="view-site-btn" target="_blank">
                <i class="fas fa-external-link-alt"></i>
                <span>Lihat Website</span>
            </a>
        </div>
    </div>
</header>