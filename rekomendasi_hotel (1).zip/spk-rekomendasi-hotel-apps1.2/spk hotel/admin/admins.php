<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'] ?? 'Admin';


// Handle CRUD operations
$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $result = addAdmin($_POST);
                break;
            case 'edit':
                $result = editAdmin($_POST);
                break;
            case 'delete':
                $result = deleteAdmin($_POST['admin_id']);
                break;
            case 'reset_password':
                $result = resetAdminPassword($_POST['admin_id']);
                break;
        }
        
        if ($result) {
            $message = $result['message'];
            $message_type = $result['type'];
        }
    }
}

// Handle AJAX requests
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    
    switch ($_GET['ajax']) {
        case 'get_admin':
            $admin_id_param = intval($_GET['id']);
            $admin_data = getAdminById($admin_id_param);
            echo json_encode($admin_data);
            exit();
            
        case 'check_email':
            $email = mysqli_real_escape_string($conn, $_GET['email']);
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            $exists = checkAdminEmailExists($email, $id);
            echo json_encode(['exists' => $exists]);
            exit();
            
        case 'check_username':
            $username = mysqli_real_escape_string($conn, $_GET['username']);
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            $exists = checkAdminUsernameExists($username, $id);
            echo json_encode(['exists' => $exists]);
            exit();
    }
}

// Function to add admin
function addAdmin($data) {
    global $conn, $admin_id;
    
    $username = mysqli_real_escape_string($conn, $data['username']);
    $email = mysqli_real_escape_string($conn, $data['email']);
    $password = password_hash($data['password'], PASSWORD_DEFAULT);
    $nama_lengkap = mysqli_real_escape_string($conn, $data['nama_lengkap']);
    
    // Check if email already exists
    if (checkAdminEmailExists($email)) {
        return array('message' => 'Email sudah digunakan', 'type' => 'error');
    }
    
    // Check if username already exists
    if (checkAdminUsernameExists($username)) {
        return array('message' => 'Username sudah digunakan', 'type' => 'error');
    }
    
    $sql = "INSERT INTO admin (username, email, password, nama_lengkap) 
            VALUES (?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $password, $nama_lengkap);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Admin berhasil ditambahkan!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal menambahkan admin: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to edit admin
function editAdmin($data) {
    global $conn, $admin_id;
    
    $admin_id_param = intval($data['admin_id']);
    $username = mysqli_real_escape_string($conn, $data['username']);
    $email = mysqli_real_escape_string($conn, $data['email']);
    $nama_lengkap = mysqli_real_escape_string($conn, $data['nama_lengkap']);
    
    // Prevent self-editing of critical data
    if ($admin_id_param == $admin_id) {
        // Allow editing own profile but with restrictions
        // You might want to implement additional checks here
    }
    
    // Check if email already exists (exclude current record)
    if (checkAdminEmailExists($email, $admin_id_param)) {
        return array('message' => 'Email sudah digunakan', 'type' => 'error');
    }
    
    // Check if username already exists (exclude current record)
    if (checkAdminUsernameExists($username, $admin_id_param)) {
        return array('message' => 'Username sudah digunakan', 'type' => 'error');
    }
    
    $sql = "UPDATE admin SET 
            username = ?, email = ?, nama_lengkap = ?, updated_at = NOW()
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssi", $username, $email, $nama_lengkap, $admin_id_param);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Admin berhasil diperbarui!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal memperbarui admin: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to delete admin
function deleteAdmin($admin_id_param) {
    global $conn, $admin_id;
    
    // Prevent self-deletion
    if ($admin_id_param == $admin_id) {
        return array('message' => 'Tidak dapat menghapus akun sendiri', 'type' => 'error');
    }
    
    // Check if this is the last admin
    $count_result = mysqli_query($conn, "SELECT COUNT(*) as count FROM admin");
    $admin_count = mysqli_fetch_assoc($count_result)['count'];
    
    if ($admin_count <= 1) {
        return array('message' => 'Tidak dapat menghapus admin terakhir', 'type' => 'error');
    }
    
    $sql = "DELETE FROM admin WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $admin_id_param);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Admin berhasil dihapus!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal menghapus admin: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to reset admin password
function resetAdminPassword($admin_id_param) {
    global $conn, $admin_id;
    
    // Prevent resetting own password through this method
    if ($admin_id_param == $admin_id) {
        return array('message' => 'Gunakan fitur ubah password untuk mengubah password sendiri', 'type' => 'error');
    }
    
    // Generate new random password
    $new_password = generateRandomPassword(10);
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    
    $sql = "UPDATE admin SET password = ?, updated_at = NOW() WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $hashed_password, $admin_id_param);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => "Password berhasil direset! Password baru: $new_password", 'type' => 'success');
    } else {
        return array('message' => 'Gagal reset password: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Helper functions
function getAdminById($admin_id_param) {
    global $conn;
    
    $sql = "SELECT * FROM admin WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $admin_id_param);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    return mysqli_fetch_assoc($result);
}

function checkAdminEmailExists($email, $exclude_id = 0) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM admin WHERE email = ?";
    if ($exclude_id > 0) {
        $sql .= " AND id != ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($exclude_id > 0) {
        mysqli_stmt_bind_param($stmt, "si", $email, $exclude_id);
    } else {
        mysqli_stmt_bind_param($stmt, "s", $email);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    
    return $data['count'] > 0;
}

function checkAdminUsernameExists($username, $exclude_id = 0) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM admin WHERE username = ?";
    if ($exclude_id > 0) {
        $sql .= " AND id != ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($exclude_id > 0) {
        mysqli_stmt_bind_param($stmt, "si", $username, $exclude_id);
    } else {
        mysqli_stmt_bind_param($stmt, "s", $username);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    
    return $data['count'] > 0;
}

function generateRandomPassword($length = 10) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Get admins with pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 12;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$where_clause = '';
if (!empty($search)) {
    $where_clause = "WHERE nama_lengkap LIKE '%$search%' OR email LIKE '%$search%' OR username LIKE '%$search%'";
}

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM admin $where_clause";
$count_result = mysqli_query($conn, $count_sql);
$total_admins = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_admins / $limit);

// Get admins
$admins_sql = "SELECT * FROM admin 
               $where_clause 
               ORDER BY created_at DESC 
               LIMIT $limit OFFSET $offset";
$admins_result = mysqli_query($conn, $admins_sql);
$admins = mysqli_fetch_all($admins_result, MYSQLI_ASSOC);

// Get statistics
$total_users_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$total_hotels_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'")->fetch_assoc()['total'];
$total_criteria_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM criteria")->fetch_assoc()['total'];
$total_admins_count = $total_admins;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Admin - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Additional styles for admin management */
        .admin-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
            border: 1px solid #e9ecef;
            position: relative;
        }
        
        .admin-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .admin-card.current-admin {
            border: 2px solid #28a745;
        }
        
        .admin-card.current-admin::before {
            content: "Anda";
            position: absolute;
            top: 10px;
            right: 10px;
            background: #28a745;
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 12px;
            font-size: 0.7rem;
            font-weight: 600;
            z-index: 1;
        }
        
        .admin-header {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            padding: 1.5rem;
            text-align: center;
        }
        
        .admin-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2rem;
        }
        
        .admin-name {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .admin-username {
            opacity: 0.8;
            font-size: 0.9rem;
        }
        
        .admin-content {
            padding: 1.5rem;
        }
        
        .admin-info {
            margin-bottom: 1.5rem;
        }
        
        .admin-info-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.75rem;
            color: #666;
            font-size: 0.9rem;
        }
        
        .admin-info-item i {
            width: 16px;
            color: #dc3545;
        }
        
        .admin-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .admins-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 2rem;
            margin-top: 1.5rem;
        }
        
        .admins-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .search-box {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .search-input {
            padding: 0.75rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            width: 300px;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #dc3545;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: #0052cc;
            color: white;
        }
        
        .btn-primary:hover {
            background: #003d99;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background: #e0a800;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            padding: 1.5rem;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #dc3545;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        
        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border-color: #bee5eb;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .pagination a, .pagination span {
            padding: 0.5rem 1rem;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #dc3545;
            color: white;
            border-color: #dc3545;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            border: 1px solid #e9ecef;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 1rem;
        }
        
        .admin-registration-date {
            font-size: 0.8rem;
            color: #999;
            margin-top: 1rem;
        }
        
        .validation-message {
            font-size: 0.8rem;
            margin-top: 0.25rem;
            display: none;
        }
        
        .validation-message.error {
            color: #dc3545;
        }
        
        .validation-message.success {
            color: #28a745;
        }
        
        .security-note {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }
        
        .security-note i {
            color: #856404;
            margin-right: 0.5rem;
        }
        
        /* Custom Sidebar Footer Styling */
        .sidebar-footer {
            padding: 1rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: auto;
        }
        
        .admin-info {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 0.75rem;
            transition: all 0.3s ease;
        }
        
        .admin-info:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-1px);
        }
        
        .admin-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .admin-avatar {
            width: 40px;
            height: 40px;
            background: #ffd700;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
            font-size: 1.2rem;
            flex-shrink: 0;
            box-shadow: 0 2px 8px rgba(255, 215, 0, 0.3);
        }
        
        .admin-details {
            flex: 1;
            min-width: 0;
        }
        
        .admin-name {
            display: block;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .admin-role {
            display: block;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .logout-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            width: 100%;
            padding: 0.75rem;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            transform: translateX(2px);
        }
        
        .logout-btn i {
            font-size: 1rem;
        }
        
        /* Responsive sidebar footer */
        @media (max-width: 768px) {
            .sidebar-footer .admin-name,
            .sidebar-footer .admin-role,
            .sidebar-footer .nav-text {
                display: none;
            }
            
            .sidebar-footer .admin-info {
                justify-content: center;
            }
            
            .sidebar-footer .logout-btn {
                justify-content: center;
            }
        }
        
        /* When sidebar is collapsed */
        .sidebar.collapsed .admin-name,
        .sidebar.collapsed .admin-role,
        .sidebar.collapsed .nav-text {
            display: none;
        }
        
        .sidebar.collapsed .admin-info {
            justify-content: center;
            padding: 0.75rem;
        }
        
        .sidebar.collapsed .logout-btn {
            justify-content: center;
            padding: 0.75rem;
        }
        
        .sidebar.collapsed .admin-details {
            display: none;
        }
        
        @media (max-width: 768px) {
            .admins-grid {
                grid-template-columns: 1fr;
            }
            
            .admins-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-input {
                width: 100%;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .admin-actions {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
         <?php include "sidebar.php" ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
             <?php include "topbar.php" ?>

            <!-- Admins Content -->
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?>">
                        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : ($message_type === 'info' ? 'info-circle' : 'exclamation-circle') ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Security Notice -->
                <div class="security-note">
                    <i class="fas fa-shield-alt"></i>
                    <strong>Keamanan Sistem:</strong> Halaman ini untuk mengelola administrator sistem. Hanya berikan akses admin kepada orang yang terpercaya. Admin memiliki akses penuh ke semua fitur sistem.
                </div>

                <!-- Statistics Cards -->
                <div class="stats-grid" style="margin-bottom: 2rem;">
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #dc3545, #c82333);">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_admins_count ?></div>
                            <div class="stat-label">Total Admin</div>
                            <div class="stat-change neutral">
                                <i class="fas fa-search"></i>
                                <span><?= empty($search) ? 'Semua Admin' : 'Hasil Pencarian' ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon users">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_users_count ?></div>
                            <div class="stat-label">Total User</div>
                            <div class="stat-change neutral">
                                <i class="fas fa-users"></i>
                                <span>Yang Dikelola</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon hotels">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_hotels_count ?></div>
                            <div class="stat-label">Hotel Aktif</div>
                            <div class="stat-change positive">
                                <i class="fas fa-check-circle"></i>
                                <span>Status Aktif</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- <div class="stat-card">
                        <div class="stat-icon criteria">
                            <i class="fas fa-sliders-h"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_criteria_count ?></div>
                            <div class="stat-label">Kriteria SAW</div>
                            <div class="stat-change neutral">
                                <i class="fas fa-cog"></i>
                                <span>Tersedia</span>
                            </div>
                        </div>
                    </div> -->
                </div>

                <!-- Admins Header -->
                <div class="admins-header">
                    <div class="search-box">
                        <form method="GET" class="search-form" style="display: flex; gap: 1rem;">
                            <input type="text" name="search" class="search-input" placeholder="Cari admin..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                            <?php if ($search): ?>
                                <a href="admins.php" class="btn btn-warning">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </form>
                    </div>
                    <div>
                        <button class="btn btn-success" onclick="openAddModal()">
                            <i class="fas fa-plus"></i> Tambah Admin
                        </button>
                    </div>
                </div>

                <!-- Admins Grid -->
                <?php if (!empty($admins)): ?>
                    <div class="admins-grid">
                        <?php foreach ($admins as $admin_data): ?>
                            <div class="admin-card <?= $admin_data['id'] == $admin_id ? 'current-admin' : '' ?>">
                                <div class="admin-header">
                                    <div class="admin-avatar">
                                        <i class="fas fa-user-shield"></i>
                                    </div>
                                    <div class="admin-name"><?= htmlspecialchars($admin_data['nama_lengkap']) ?></div>
                                    <div class="admin-username">@<?= htmlspecialchars($admin_data['username']) ?></div>
                                </div>
                                
                                <div class="admin-content">
                                    <div class="admin-info">
                                        <div class="admin-info-item">
                                            <i class="fas fa-envelope"></i>
                                            <span><?= htmlspecialchars($admin_data['email']) ?></span>
                                        </div>
                                        <div class="admin-info-item">
                                            <i class="fas fa-calendar"></i>
                                            <span>Bergabung: <?= date('d M Y', strtotime($admin_data['created_at'])) ?></span>
                                        </div>
                                        <?php if ($admin_data['updated_at'] != $admin_data['created_at']): ?>
                                            <div class="admin-info-item">
                                                <i class="fas fa-edit"></i>
                                                <span>Diperbarui: <?= date('d M Y', strtotime($admin_data['updated_at'])) ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="admin-actions">
                                        <button class="btn btn-primary" onclick="viewAdmin(<?= $admin_data['id'] ?>)">
                                            <i class="fas fa-eye"></i> Detail
                                        </button>
                                        
                                        <button class="btn btn-warning" onclick="editAdmin(<?= $admin_data['id'] ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        
                                        <?php if ($admin_data['id'] != $admin_id): ?>
                                            <button class="btn btn-info" onclick="resetPassword(<?= $admin_data['id'] ?>, '<?= htmlspecialchars($admin_data['nama_lengkap']) ?>')">
                                                <i class="fas fa-key"></i> Reset
                                            </button>
                                            
                                            <?php if ($total_admins > 1): ?>
                                                <button class="btn btn-danger" onclick="deleteAdmin(<?= $admin_data['id'] ?>, '<?= htmlspecialchars($admin_data['nama_lengkap']) ?>')">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </button>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="btn" style="background: #6c757d; color: white; cursor: not-allowed;">
                                                <i class="fas fa-user"></i> Akun Anda
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?= $page - 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == $page): ?>
                                    <span class="current"><?= $i ?></span>
                                <?php else: ?>
                                    <a href="?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?= $page + 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-user-shield"></i>
                        <h3 style="color: #666; margin-bottom: 0.5rem;">
                            <?= empty($search) ? 'Belum ada admin yang terdaftar' : 'Admin tidak ditemukan' ?>
                        </h3>
                        <p style="color: #999;">
                            <?= empty($search) ? 'Admin akan muncul di sini setelah ditambahkan' : 'Coba kata kunci pencarian yang berbeda' ?>
                        </p>
                        <?php if (empty($search)): ?>
                            <button class="btn btn-success" onclick="openAddModal()" style="margin-top: 1rem;">
                                <i class="fas fa-plus"></i> Tambah Admin Pertama
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay" onclick="closeMobileSidebar()"></div>

    <!-- Add/Edit Admin Modal -->
    <div class="modal" id="adminModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Tambah Admin</h3>
                <button type="button" onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="adminForm" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="admin_id" id="adminId">
                    
                    <div class="security-note" style="margin-bottom: 1.5rem;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>Perhatian:</strong> Admin memiliki akses penuh ke sistem. Pastikan hanya memberikan akses kepada orang yang terpercaya.
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Username *</label>
                            <input type="text" name="username" id="username" class="form-control" required onblur="checkUsername()">
                            <div id="usernameMessage" class="validation-message"></div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" id="email" class="form-control" required onblur="checkEmail()">
                            <div id="emailMessage" class="validation-message"></div>
                        </div>
                    </div>
                    
                    <div class="form-group" id="passwordGroup">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" id="password" class="form-control" required minlength="8">
                        <small style="color: #666;">Minimal 8 karakter, disarankan menggunakan kombinasi huruf, angka, dan simbol</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Nama Lengkap *</label>
                        <input type="text" name="nama_lengkap" id="namaLengkap" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closeModal()" class="btn" style="background: #6c757d; color: white;">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Admin Modal -->
    <div class="modal" id="viewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Detail Admin</h3>
                <button type="button" onclick="closeViewModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <script>
        // Sidebar functionality
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('collapsed');
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            });
        }

        mobileSidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('mobile-open');
            mobileOverlay.classList.add('active');
        });

        function closeMobileSidebar() {
            sidebar.classList.remove('mobile-open');
            mobileOverlay.classList.remove('active');
        }

        // Load sidebar state
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        // Admin dropdown
        function toggleAdminDropdown() {
            const dropdown = document.getElementById('adminDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('adminDropdown');
            const toggle = document.querySelector('.admin-dropdown-toggle');
            
            if (toggle && !toggle.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Modal functions
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Tambah Admin';
            document.getElementById('formAction').value = 'add';
            document.getElementById('adminForm').reset();
            document.getElementById('adminId').value = '';
            
            // Show password field for add
            document.getElementById('passwordGroup').style.display = 'block';
            document.getElementById('password').required = true;
            
            // Clear validation messages
            clearValidationMessages();
            
            document.getElementById('adminModal').classList.add('show');
        }

        function editAdmin(adminId) {
            document.getElementById('modalTitle').textContent = 'Edit Admin';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('adminId').value = adminId;
            
            // Hide password field for edit
            document.getElementById('passwordGroup').style.display = 'none';
            document.getElementById('password').required = false;
            
            // Clear validation messages
            clearValidationMessages();
            
            // Fetch admin data
            fetch(`admins.php?ajax=get_admin&id=${adminId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('username').value = data.username || '';
                        document.getElementById('email').value = data.email || '';
                        document.getElementById('namaLengkap').value = data.nama_lengkap || '';
                        
                        document.getElementById('adminModal').classList.add('show');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Gagal mengambil data admin');
                });
        }

        function viewAdmin(adminId) {
            // Fetch admin data
            fetch(`admins.php?ajax=get_admin&id=${adminId}`)
                .then(response => response.json())
                .then(adminData => {
                    const modalBody = document.getElementById('viewModalBody');
                    const isCurrentAdmin = adminId == <?= $admin_id ?>;
                    
                    modalBody.innerHTML = `
                        <div style="display: grid; gap: 1.5rem;">
                            <div style="text-align: center;">
                                <div style="width: 100px; height: 100px; background: linear-gradient(135deg, #dc3545, #c82333); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; color: white; font-size: 2.5rem;">
                                    <i class="fas fa-user-shield"></i>
                                </div>
                                <h4 style="margin-bottom: 0.5rem; color: #333;">${adminData.nama_lengkap}</h4>
                                <p style="color: #666; margin-bottom: 0.5rem;">@${adminData.username}</p>
                                ${isCurrentAdmin ? '<span style="background: #28a745; color: white; padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.8rem; font-weight: 600;">Akun Anda</span>' : '<span style="background: #dc3545; color: white; padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.8rem; font-weight: 600;">Administrator</span>'}
                            </div>
                            
                            <div>
                                <h5 style="margin-bottom: 1rem; color: #333;">Informasi Kontak</h5>
                                <div style="display: grid; gap: 0.75rem;">
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <i class="fas fa-envelope" style="width: 20px; color: #dc3545;"></i>
                                        <span>${adminData.email}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <h5 style="margin-bottom: 1rem; color: #333;">Informasi Akun</h5>
                                <div style="display: grid; gap: 0.75rem;">
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <i class="fas fa-calendar" style="width: 20px; color: #dc3545;"></i>
                                        <span>Bergabung: ${new Date(adminData.created_at).toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric'})}</span>
                                    </div>
                                    ${adminData.updated_at !== adminData.created_at ? `
                                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                                            <i class="fas fa-edit" style="width: 20px; color: #dc3545;"></i>
                                            <span>Terakhir diperbarui: ${new Date(adminData.updated_at).toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric'})}</span>
                                        </div>
                                    ` : ''}
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <i class="fas fa-shield-alt" style="width: 20px; color: #dc3545;"></i>
                                        <span>Hak Akses: Administrator Penuh</span>
                                    </div>
                                </div>
                            </div>
                            
                            ${isCurrentAdmin ? `
                                <div style="background: #e7f3ff; padding: 1rem; border-radius: 8px; border-left: 4px solid #0052cc;">
                                    <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                        <i class="fas fa-info-circle" style="color: #0052cc;"></i>
                                        <strong style="color: #0052cc;">Informasi Akun</strong>
                                    </div>
                                    <p style="margin: 0; color: #666; font-size: 0.9rem;">
                                        Ini adalah akun Anda saat ini. Untuk mengubah password atau informasi profil, gunakan menu pengaturan di sidebar.
                                    </p>
                                </div>
                            ` : ''}
                        </div>
                    `;
                    
                    document.getElementById('viewModal').classList.add('show');
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Gagal mengambil data admin');
                });
        }

        function closeModal() {
            document.getElementById('adminModal').classList.remove('show');
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.remove('show');
        }

        function deleteAdmin(adminId, adminName) {
            if (confirm(`Apakah Anda yakin ingin menghapus admin "${adminName}"?\n\nTindakan ini tidak dapat dibatalkan dan akan menghilangkan akses admin tersebut ke sistem.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="admin_id" value="${adminId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function resetPassword(adminId, adminName) {
            if (confirm(`Apakah Anda yakin ingin mereset password untuk admin "${adminName}"?\n\nPassword baru akan ditampilkan setelah reset dan harus segera dicatat.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="admin_id" value="${adminId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Validation functions
        function checkEmail() {
            const email = document.getElementById('email').value;
            const adminId = document.getElementById('adminId').value || 0;
            const messageElement = document.getElementById('emailMessage');
            
            if (email) {
                fetch(`admins.php?ajax=check_email&email=${encodeURIComponent(email)}&id=${adminId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            messageElement.textContent = 'Email sudah digunakan';
                            messageElement.className = 'validation-message error';
                            messageElement.style.display = 'block';
                        } else {
                            messageElement.textContent = 'Email tersedia';
                            messageElement.className = 'validation-message success';
                            messageElement.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            } else {
                messageElement.style.display = 'none';
            }
        }

        function checkUsername() {
            const username = document.getElementById('username').value;
            const adminId = document.getElementById('adminId').value || 0;
            const messageElement = document.getElementById('usernameMessage');
            
            if (username) {
                fetch(`admins.php?ajax=check_username&username=${encodeURIComponent(username)}&id=${adminId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            messageElement.textContent = 'Username sudah digunakan';
                            messageElement.className = 'validation-message error';
                            messageElement.style.display = 'block';
                        } else {
                            messageElement.textContent = 'Username tersedia';
                            messageElement.className = 'validation-message success';
                            messageElement.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            } else {
                messageElement.style.display = 'none';
            }
        }

        function clearValidationMessages() {
            document.getElementById('emailMessage').style.display = 'none';
            document.getElementById('usernameMessage').style.display = 'none';
        }

        // Close modals when clicking outside
        document.addEventListener('click', function(event) {
            const adminModal = document.getElementById('adminModal');
            const viewModal = document.getElementById('viewModal');
            
            if (event.target === adminModal) {
                closeModal();
            }
            
            if (event.target === viewModal) {
                closeViewModal();
            }
        });

        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);

        // Form validation
        document.getElementById('adminForm').addEventListener('submit', function(e) {
            const emailMessage = document.getElementById('emailMessage');
            const usernameMessage = document.getElementById('usernameMessage');
            
            // Check if there are validation errors
            if (emailMessage.classList.contains('error') && emailMessage.style.display !== 'none') {
                e.preventDefault();
                alert('Email sudah digunakan. Silakan gunakan email lain.');
                return false;
            }
            
            if (usernameMessage.classList.contains('error') && usernameMessage.style.display !== 'none') {
                e.preventDefault();
                alert('Username sudah digunakan. Silakan gunakan username lain.');
                return false;
            }
        });
    </script>
</body>
</html>