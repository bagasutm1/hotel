<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil data order
$sql = "SELECT o.*, h.nama_hotel, h.harga_per_malam, u.nama_lengkap 
        FROM orders o 
        JOIN hotels h ON o.hotel_id = h.id 
        JOIN users u ON o.user_id = u.id 
        WHERE o.id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($result);

if (!$order) {
    echo "<script>alert('Order tidak ditemukan'); window.location.href='orders.php';</script>";
    exit;
}

// Proses konfirmasi pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'approve_payment') {
        $update = "UPDATE orders SET status = 'diproses' WHERE id = ?";
    } elseif ($_POST['action'] === 'verify_payment') {
        $update = "UPDATE orders SET status = 'dibayar' WHERE id = ?";
    }

    $stmt = mysqli_prepare($conn, $update);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Status pesanan berhasil diperbarui'); window.location.href='orders.php';</script>";
        exit;
    } else {
        $error = "Gagal memperbarui status";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Detail Order - Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .label-status {
            font-size: 0.9rem;
            padding: 0.4em 0.8em;
            border-radius: 20px;
        }
    </style>
</head>

<body>
    <div class="container my-5">
        <a href="orders.php" class="btn btn-secondary mb-4"><i class="fas fa-arrow-left"></i> Kembali ke Data Order</a>

        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i> Detail Pesanan #<?= htmlspecialchars($order['id']) ?></h5>
            </div>
            <div class="card-body">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <dl class="row">
                    <dt class="col-sm-4">Nama Pemesan</dt>
                    <dd class="col-sm-8"><?= htmlspecialchars($order['nama_lengkap']) ?></dd>

                    <dt class="col-sm-4">Hotel</dt>
                    <dd class="col-sm-8"><?= htmlspecialchars($order['nama_hotel']) ?></dd>

                    <dt class="col-sm-4">Tanggal Check-in</dt>
                    <dd class="col-sm-8"><?= date('d M Y', strtotime($order['tanggal_checkin'])) ?></dd>

                    <dt class="col-sm-4">Tanggal Check-out</dt>
                    <dd class="col-sm-8"><?= date('d M Y', strtotime($order['tanggal_checkout'])) ?></dd>

                    <dt class="col-sm-4">Jumlah Kamar</dt>
                    <dd class="col-sm-8"><?= $order['jumlah_kamar'] ?></dd>

                    <dt class="col-sm-4">Total Harga</dt>
                    <dd class="col-sm-8">Rp <?= number_format($order['jumlah_kamar'] * $order['harga_per_malam'], 0, ',', '.') ?></dd>

                    <dt class="col-sm-4">Status</dt>
                    <dd class="col-sm-8">
                        <span class="label-status bg-<?=
                                                        $order['status'] === 'dibayar' ? 'success' : ($order['status'] === 'diproses' ? 'info' : 'warning text-dark') ?>">
                            <?= strtoupper($order['status']) ?>
                        </span>
                    </dd>
                </dl>

                <?php if (!empty($order['bukti_bayar']) && file_exists('../uploads/' . $order['bukti_bayar'])): ?>
                    <div class="mb-4">
                        <strong>Bukti Pembayaran:</strong><br>
                        <a href="../uploads/<?= $order['bukti_bayar'] ?>" target="_blank">
                            <img src="../uploads/<?= $order['bukti_bayar'] ?>" alt="Bukti Bayar" class="img-thumbnail mt-2" style="max-width: 350px;">
                        </a>
                    </div>
                <?php endif; ?>

                <?php if ($order['status'] === 'belum_dibayar'): ?>
                    <form method="POST" onsubmit="return confirm('Setujui pembayaran ini?')">
                        <input type="hidden" name="action" value="approve_payment">
                        <button type="submit" class="btn btn-warning">
                            <i class="fas fa-check-circle"></i> Setujui Pembayaran (Ubah ke Diproses)
                        </button>
                    </form>
                <?php elseif ($order['status'] === 'diproses'): ?>
                    <form method="POST" onsubmit="return confirm('Verifikasi bahwa pembayaran ini sah?')">
                        <input type="hidden" name="action" value="verify_payment">
                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-check-circle"></i> Verifikasi Pembayaran (Ubah ke Dibayar)
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- FontAwesome -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>

</html>