<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'] ?? 'Admin';


// Handle CRUD operations
$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $result = addHotel($_POST, $_FILES);
                break;
            case 'edit':
                $result = editHotel($_POST, $_FILES);
                break;
            case 'delete':
                $result = deleteHotel($_POST['hotel_id']);
                break;
            case 'toggle_status':
                $result = toggleHotelStatus($_POST['hotel_id']);
                break;
        }
        
        if ($result) {
            $message = $result['message'];
            $message_type = $result['type'];
        }
    }
}

// Handle AJAX requests
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    
    switch ($_GET['ajax']) {
        case 'get_hotel':
            $hotel_id = intval($_GET['id']);
            $hotel = getHotelById($hotel_id);
            echo json_encode($hotel);
            exit();
            
        case 'get_hotel_photos':
            $hotel_id = intval($_GET['id']);
            $photos = getHotelPhotos($hotel_id);
            echo json_encode($photos);
            exit();
            
        case 'search':
            $search = mysqli_real_escape_string($conn, $_GET['q']);
            $hotels = searchHotels($search);
            echo json_encode($hotels);
            exit();
    }
}

// Handle POST AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    
    switch ($_POST['ajax_action']) {
        case 'delete_photo':
            $photo_id = intval($_POST['photo_id']);
            $result = deleteHotelPhoto($photo_id);
            echo json_encode([
                'success' => $result,
                'message' => $result ? 'Foto berhasil dihapus' : 'Gagal menghapus foto'
            ]);
            exit();
    }
}

// Function to add hotel
function addHotel($data, $files) {
    global $conn;

    // 🔥 PENTING: pastikan ID tidak ikut saat INSERT
    if (isset($data['hotel_id'])) {
        unset($data['hotel_id']);
    }

    
    $nama_hotel = mysqli_real_escape_string($conn, $data['nama_hotel']);
    $alamat = mysqli_real_escape_string($conn, $data['alamat']);
    $deskripsi = mysqli_real_escape_string($conn, $data['deskripsi']);
    $harga_per_malam = floatval($data['harga_per_malam']);
    $rating_bintang = intval($data['rating_bintang']);
    $fasilitas = isset($data['fasilitas']) ? implode(',', $data['fasilitas']) : '';
    $koordinat_lat = !empty($data['koordinat_lat']) ? floatval($data['koordinat_lat']) : null;
    $koordinat_lng = !empty($data['koordinat_lng']) ? floatval($data['koordinat_lng']) : null;
    $status = $data['status'];
    
    // Handle file upload
    $foto_utama = '';
    if (isset($files['foto_utama']) && $files['foto_utama']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadPhoto($files['foto_utama']);
        if ($upload_result['success']) {
            $foto_utama = $upload_result['filename'];
        } else {
            return array('message' => $upload_result['message'], 'type' => 'error');
        }
    }
    
   $sql = "INSERT INTO hotels 
(nama_hotel, alamat, deskripsi, foto_utama, harga_per_malam, rating_bintang, fasilitas, koordinat_lat, koordinat_lng, status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssissds", $nama_hotel, $alamat, $deskripsi, $foto_utama, $harga_per_malam, $rating_bintang, $fasilitas, $koordinat_lat, $koordinat_lng, $status);
    
    if (mysqli_stmt_execute($stmt)) {
        $hotel_id = mysqli_insert_id($conn);
        
        // Handle additional photos
        if (isset($files['foto_tambahan'])) {
            $captions = isset($_POST['foto_captions']) ? $_POST['foto_captions'] : null;
            handleAdditionalPhotos($hotel_id, $files['foto_tambahan'], $captions);
        }
        
        return array('message' => 'Hotel berhasil ditambahkan!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal menambahkan hotel: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to edit hotel
function editHotel($data, $files) {
    global $conn;
    
    $hotel_id = intval($data['hotel_id']);
    $nama_hotel = mysqli_real_escape_string($conn, $data['nama_hotel']);
    $alamat = mysqli_real_escape_string($conn, $data['alamat']);
    $deskripsi = mysqli_real_escape_string($conn, $data['deskripsi']);
    $harga_per_malam = floatval($data['harga_per_malam']);
    $rating_bintang = intval($data['rating_bintang']);
    $fasilitas = isset($data['fasilitas']) ? implode(',', $data['fasilitas']) : '';
    $koordinat_lat = !empty($data['koordinat_lat']) ? floatval($data['koordinat_lat']) : null;
    $koordinat_lng = !empty($data['koordinat_lng']) ? floatval($data['koordinat_lng']) : null;
    $status = $data['status'];
    
    // Handle file upload for main photo
    $foto_utama_update = '';
    if (isset($files['foto_utama']) && $files['foto_utama']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadPhoto($files['foto_utama']);
        if ($upload_result['success']) {
            // Delete old photo
            $old_photo = getHotelById($hotel_id)['foto_utama'];
            if ($old_photo && file_exists('../assets/images/' . $old_photo)) {
                unlink('../assets/images/' . $old_photo);
            }
            $foto_utama_update = ", foto_utama = '" . $upload_result['filename'] . "'";
        }
    }
    
    $sql = "UPDATE hotels SET 
            nama_hotel = ?, alamat = ?, deskripsi = ?, harga_per_malam = ?, 
            rating_bintang = ?, fasilitas = ?, koordinat_lat = ?, koordinat_lng = ?, 
            status = ?, updated_at = NOW() $foto_utama_update
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssissdssi", $nama_hotel, $alamat, $deskripsi, $harga_per_malam, $rating_bintang, $fasilitas, $koordinat_lat, $koordinat_lng, $status, $hotel_id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Handle additional photos
        if (isset($files['foto_tambahan'])) {
            $captions = isset($_POST['foto_captions']) ? $_POST['foto_captions'] : null;
            handleAdditionalPhotos($hotel_id, $files['foto_tambahan'], $captions);
        }
        
        // Handle photo deletions
        if (isset($_POST['delete_photos']) && !empty($_POST['delete_photos'])) {
            foreach ($_POST['delete_photos'] as $photo_id) {
                deleteHotelPhoto(intval($photo_id));
            }
        }
        
        return array('message' => 'Hotel berhasil diperbarui!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal memperbarui hotel: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to delete hotel
function deleteHotel($hotel_id) {
    global $conn;
    
    // Get hotel data for photo deletion
    $hotel = getHotelById($hotel_id);
    
    // Delete hotel photos
    if ($hotel['foto_utama'] && file_exists('../assets/images/' . $hotel['foto_utama'])) {
        unlink('../assets/images/' . $hotel['foto_utama']);
    }
    
    // Delete additional photos
    $photos_sql = "SELECT foto_path FROM hotel_photos WHERE hotel_id = ?";
    $photos_stmt = mysqli_prepare($conn, $photos_sql);
    mysqli_stmt_bind_param($photos_stmt, "i", $hotel_id);
    mysqli_stmt_execute($photos_stmt);
    $photos_result = mysqli_stmt_get_result($photos_stmt);
    
    while ($photo = mysqli_fetch_assoc($photos_result)) {
        if (file_exists('../assets/images/' . $photo['foto_path'])) {
            unlink('../assets/images/' . $photo['foto_path']);
        }
    }
    
    // Delete from database
    mysqli_begin_transaction($conn);
    
    try {
        // Delete additional photos records
        mysqli_query($conn, "DELETE FROM hotel_photos WHERE hotel_id = $hotel_id");
        
        // Delete hotel criteria values
        mysqli_query($conn, "DELETE FROM hotel_criteria_values WHERE hotel_id = $hotel_id");
        
        // Delete user favorites
        mysqli_query($conn, "DELETE FROM user_favorites WHERE hotel_id = $hotel_id");
        
        // Delete hotel
        mysqli_query($conn, "DELETE FROM hotels WHERE id = $hotel_id");
        
        mysqli_commit($conn);
        return array('message' => 'Hotel berhasil dihapus!', 'type' => 'success');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return array('message' => 'Gagal menghapus hotel: ' . $e->getMessage(), 'type' => 'error');
    }
}

// Function to toggle hotel status
function toggleHotelStatus($hotel_id) {
    global $conn;
    
    $sql = "UPDATE hotels SET status = CASE WHEN status = 'aktif' THEN 'nonaktif' ELSE 'aktif' END WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $hotel_id);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'Status hotel berhasil diubah!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal mengubah status hotel!', 'type' => 'error');
    }
}

// Function to upload photo
function uploadPhoto($file) {
    $target_dir = "../assets/images/";
    $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
    $max_size = 5 * 1024 * 1024; // 5MB
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // Validate file type
    if (!in_array($file_extension, $allowed_types)) {
        return array('success' => false, 'message' => 'Tipe file tidak diizinkan. Gunakan JPG, JPEG, PNG, atau GIF.');
    }
    
    // Validate file size
    if ($file['size'] > $max_size) {
        return array('success' => false, 'message' => 'Ukuran file terlalu besar. Maksimal 5MB.');
    }
    
    // Generate unique filename
    $filename = 'hotel_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
    $target_file = $target_dir . $filename;
    
    // Create directory if not exists
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return array('success' => true, 'filename' => $filename);
    } else {
        return array('success' => false, 'message' => 'Gagal mengupload file.');
    }
}

// Function to handle additional photos
function handleAdditionalPhotos($hotel_id, $files, $captions = null) {
    global $conn;
    
    if (is_array($files['name'])) {
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = array(
                    'name' => $files['name'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'size' => $files['size'][$i]
                );
                
                $upload_result = uploadPhoto($file);
                if ($upload_result['success']) {
                    $caption = isset($captions[$i]) ? mysqli_real_escape_string($conn, $captions[$i]) : '';
                    $sql = "INSERT INTO hotel_photos (hotel_id, foto_path, keterangan) VALUES (?, ?, ?)";
                    $stmt = mysqli_prepare($conn, $sql);
                    mysqli_stmt_bind_param($stmt, "iss", $hotel_id, $upload_result['filename'], $caption);
                    mysqli_stmt_execute($stmt);
                }
            }
        }
    }
}

// Function to delete hotel photo
function deleteHotelPhoto($photo_id) {
    global $conn;
    
    // Get photo info first
    $sql = "SELECT foto_path FROM hotel_photos WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $photo_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $photo = mysqli_fetch_assoc($result);
    
    if ($photo) {
        // Delete file
        if (file_exists('../assets/images/' . $photo['foto_path'])) {
            unlink('../assets/images/' . $photo['foto_path']);
        }
        
        // Delete from database
        $delete_sql = "DELETE FROM hotel_photos WHERE id = ?";
        $delete_stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($delete_stmt, "i", $photo_id);
        return mysqli_stmt_execute($delete_stmt);
    }
    
    return false;
}

// Function to get hotel photos
function getHotelPhotos($hotel_id) {
    global $conn;
    
    $sql = "SELECT id, foto_path, keterangan FROM hotel_photos WHERE hotel_id = ? ORDER BY is_primary DESC, id ASC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $hotel_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Function to get hotel by ID
function getHotelById($hotel_id) {
    global $conn;
    
    $sql = "SELECT * FROM hotels WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $hotel_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    return mysqli_fetch_assoc($result);
}

// Function to search hotels
function searchHotels($search) {
    global $conn;
    
    $sql = "SELECT * FROM hotels WHERE nama_hotel LIKE '%$search%' OR alamat LIKE '%$search%' ORDER BY nama_hotel";
    $result = mysqli_query($conn, $sql);
    
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

// Get all hotels with pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$where_clause = '';
if (!empty($search)) {
    $where_clause = "WHERE nama_hotel LIKE '%$search%' OR alamat LIKE '%$search%'";
}

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM hotels $where_clause";
$count_result = mysqli_query($conn, $count_sql);
$total_hotels = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_hotels / $limit);

// Get hotels
$hotels_sql = "SELECT h.*, 
               (SELECT COUNT(*) FROM user_favorites uf WHERE uf.hotel_id = h.id) as favorite_count,
               (SELECT COUNT(*) FROM hotel_photos hp WHERE hp.hotel_id = h.id) as photo_count
               FROM hotels h 
               $where_clause 
               ORDER BY h.created_at DESC 
               LIMIT $limit OFFSET $offset";
$hotels_result = mysqli_query($conn, $hotels_sql);
$hotels = mysqli_fetch_all($hotels_result, MYSQLI_ASSOC);

// Get total statistics
$total_hotels_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'")->fetch_assoc()['total'];
$total_users_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];

// Predefined facilities
$fasilitas_options = [
    'WiFi Gratis', 'AC', 'TV', 'Kamar Mandi Dalam', 'Breakfast', 'Parkir Gratis', 
    'Kolam Renang', 'Gym', 'Spa', 'Restaurant', 'Room Service', 'Laundry',
    'Business Center', 'Meeting Room', 'Airport Shuttle', 'Pet Friendly'
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Hotel - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Additional styles for hotels management */
        .hotel-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
            border: 1px solid #e9ecef;
        }
        
        .hotel-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .hotel-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f8f9fa;
        }
        
        .hotel-content {
            padding: 1.5rem;
        }
        
        .hotel-name {
            font-size: 1.2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .hotel-rating {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.75rem;
        }
        
        .stars {
            display: flex;
            gap: 0.1rem;
        }
        
        .stars i {
            color: #ddd;
            font-size: 0.9rem;
        }
        
        .stars i.active {
            color: #ffd700;
        }
        
        .hotel-price {
            font-size: 1.1rem;
            font-weight: 600;
            color: #0052cc;
            margin-bottom: 0.75rem;
        }
        
        .hotel-status {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            margin-bottom: 1rem;
        }
        
        .hotel-status.aktif {
            background: #d4edda;
            color: #155724;
        }
        
        .hotel-status.nonaktif {
            background: #f8d7da;
            color: #721c24;
        }
        
        .hotel-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: #0052cc;
            color: white;
        }
        
        .btn-primary:hover {
            background: #003d99;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background: #e0a800;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .hotels-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 2rem;
            margin-top: 1.5rem;
        }
        
        .hotels-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .search-box {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .search-input {
            padding: 0.75rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            width: 300px;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #0052cc;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            padding: 1.5rem;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #0052cc;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .facilities-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .facility-checkbox {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .pagination a, .pagination span {
            padding: 0.5rem 1rem;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #0052cc;
            color: white;
            border-color: #0052cc;
        }
        
        .additional-photo-item {
            margin-bottom: 1rem;
            padding: 1rem;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            background: #f8f9fa;
        }
        
        .existing-photo-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            background: #f8f9fa;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        
        .existing-photo-thumb {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .existing-photo-info {
            flex: 1;
        }
        
        .existing-photo-caption {
            font-size: 0.9rem;
            color: #666;
            margin-top: 0.25rem;
        }
        
        .photo-delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.5rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .photo-delete-btn:hover {
            background: #c82333;
        }
        
        .photo-delete-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        
        .remove-photo-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            margin-top: 0.5rem;
        }
        
        .remove-photo-btn:hover {
            background: #c82333;
        }
        
        /* Photo Gallery Styles */
        .photo-gallery {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 0.5rem;
        }
        
        .photo-item {
            position: relative;
            border-radius: 8px;
            overflow: hidden;
            background: #f8f9fa;
            aspect-ratio: 4/3;
        }
        
        .photo-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .photo-item img:hover {
            transform: scale(1.05);
        }
        
        .photo-item.main-photo {
            grid-column: 1 / -1;
            aspect-ratio: 16/9;
            border: 2px solid #0052cc;
        }
        
        .photo-label {
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
            background: rgba(0, 82, 204, 0.9);
            color: white;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.7rem;
            font-weight: 500;
        }
        
        .photo-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0,0,0,0.8));
            color: white;
            padding: 1rem 0.5rem 0.5rem;
            font-size: 0.8rem;
        }
        
        .no-photo-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6c757d, #495057);
            color: white;
            text-align: center;
        }
        
        .no-photo-placeholder i {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            opacity: 0.7;
        }
        
        .no-photo-placeholder span {
            font-size: 0.8rem;
            opacity: 0.8;
        }
        
        .no-photos-message {
            grid-column: 1 / -1;
            text-align: center;
            padding: 2rem;
            color: #666;
        }
        
        /* Photo Modal */
        .photo-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 20000;
            align-items: center;
            justify-content: center;
        }
        
        .photo-modal.show {
            display: flex;
        }
        
        .photo-modal img {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
        }
        
        .photo-modal-close {
            position: absolute;
            top: 20px;
            right: 30px;
            color: white;
            font-size: 2rem;
            cursor: pointer;
            background: none;
            border: none;
        }
        
        @media (max-width: 768px) {
            .hotels-grid {
                grid-template-columns: 1fr;
            }
            
            .hotels-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-input {
                width: 100%;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .facilities-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
         <?php include "sidebar.php" ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
             <?php include "topbar.php" ?>

            <!-- Hotels Content -->
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?>">
                        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Hotels Header -->
                <div class="hotels-header">
                    <div class="search-box">
                        <form method="GET" class="search-form" style="display: flex; gap: 1rem;">
                            <input type="text" name="search" class="search-input" placeholder="Cari hotel..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                            <?php if ($search): ?>
                                <a href="hotels.php" class="btn btn-warning">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </form>
                    </div>
                    <button class="btn btn-success" onclick="openAddModal()">
                        <i class="fas fa-plus"></i>
                        Tambah Hotel
                    </button>
                </div>

                <!-- Statistics Cards -->
                <div class="stats-grid" style="margin-bottom: 2rem;">
                    <div class="stat-card">
                        <div class="stat-icon hotels">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_hotels ?></div>
                            <div class="stat-label">Total Hotel</div>
                            <div class="stat-change neutral">
                                <i class="fas fa-search"></i>
                                <span><?= empty($search) ? 'Semua Hotel' : 'Hasil Pencarian' ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Hotels Grid -->
                <?php if (!empty($hotels)): ?>
                    <div class="hotels-grid">
                        <?php foreach ($hotels as $hotel): ?>
                            <div class="hotel-card">
                                <?php if ($hotel['foto_utama']): ?>
                                    <img src="../assets/images/<?= htmlspecialchars($hotel['foto_utama']) ?>" alt="<?= htmlspecialchars($hotel['nama_hotel']) ?>" class="hotel-image">
                                <?php else: ?>
                                    <div class="hotel-image" style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                                        <i class="fas fa-hotel" style="font-size: 3rem; margin-bottom: 0.5rem; opacity: 0.8;"></i>
                                        <span style="font-size: 0.9rem; opacity: 0.8;">No Image</span>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="hotel-content">
                                    <h3 class="hotel-name"><?= htmlspecialchars($hotel['nama_hotel']) ?></h3>
                                    
                                    <div class="hotel-rating">
                                        <div class="stars">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <i class="fas fa-star <?= $i <= $hotel['rating_bintang'] ? 'active' : '' ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <span>(<?= $hotel['rating_bintang'] ?> Bintang)</span>
                                    </div>
                                    
                                    <div class="hotel-price">
                                        Rp <?= number_format($hotel['harga_per_malam'], 0, ',', '.') ?> / malam
                                    </div>
                                    
                                    <div class="hotel-status <?= $hotel['status'] ?>">
                                        <?= ucfirst($hotel['status']) ?>
                                    </div>
                                    
                                    <div style="margin-bottom: 1rem;">
                                        <small style="color: #666;">
                                            <i class="fas fa-map-marker-alt"></i>
                                            <?= htmlspecialchars(substr($hotel['alamat'], 0, 50)) ?><?= strlen($hotel['alamat']) > 50 ? '...' : '' ?>
                                        </small>
                                    </div>
                                    
                                    <div style="margin-bottom: 1rem;">
                                        <small style="color: #666;">
                                            <i class="fas fa-heart"></i> <?= $hotel['favorite_count'] ?> favorit
                                            <i class="fas fa-images" style="margin-left: 1rem;"></i> <?= $hotel['photo_count'] ?> foto
                                        </small>
                                    </div>
                                    
                                    <div class="hotel-actions">
                                        <button class="btn btn-primary" onclick="viewHotel(<?= $hotel['id'] ?>)">
                                            <i class="fas fa-eye"></i> Detail
                                        </button>
                                        <button class="btn btn-warning" onclick="editHotel(<?= $hotel['id'] ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button class="btn btn-<?= $hotel['status'] === 'aktif' ? 'warning' : 'success' ?>" 
                                                onclick="toggleStatus(<?= $hotel['id'] ?>, '<?= $hotel['status'] ?>')">
                                            <i class="fas fa-<?= $hotel['status'] === 'aktif' ? 'pause' : 'play' ?>"></i>
                                            <?= $hotel['status'] === 'aktif' ? 'Nonaktifkan' : 'Aktifkan' ?>
                                        </button>
                                        <button class="btn btn-danger" onclick="deleteHotel(<?= $hotel['id'] ?>, '<?= htmlspecialchars($hotel['nama_hotel']) ?>')">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?= $page - 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == $page): ?>
                                    <span class="current"><?= $i ?></span>
                                <?php else: ?>
                                    <a href="?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?= $page + 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="empty-state" style="text-align: center; padding: 3rem; background: white; border-radius: 12px; box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);">
                        <i class="fas fa-building" style="font-size: 4rem; color: #ddd; margin-bottom: 1rem;"></i>
                        <h3 style="color: #666; margin-bottom: 0.5rem;">
                            <?= empty($search) ? 'Belum ada hotel yang terdaftar' : 'Hotel tidak ditemukan' ?>
                        </h3>
                        <p style="color: #999;">
                            <?= empty($search) ? 'Klik tombol "Tambah Hotel" untuk menambahkan hotel pertama' : 'Coba kata kunci pencarian yang berbeda' ?>
                        </p>
                        <?php if (empty($search)): ?>
                            <button class="btn btn-success" onclick="openAddModal()" style="margin-top: 1rem;">
                                <i class="fas fa-plus"></i> Tambah Hotel
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay" onclick="closeMobileSidebar()"></div>

    <!-- Add/Edit Hotel Modal -->
    <div class="modal" id="hotelModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Tambah Hotel</h3>
                <button type="button" onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="hotelForm" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="hotel_id" id="hotelId">
                    
                    <div class="form-group">
                        <label class="form-label">Nama Hotel *</label>
                        <input type="text" name="nama_hotel" id="namaHotel" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Alamat *</label>
                        <textarea name="alamat" id="alamat" class="form-control" rows="3" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" id="deskripsi" class="form-control" rows="4"></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Harga per Malam (Rp) *</label>
                            <input type="number" name="harga_per_malam" id="hargaPerMalam" class="form-control" required min="0" step="1000">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Rating Bintang *</label>
                            <select name="rating_bintang" id="ratingBintang" class="form-control" required>
                                <option value="">Pilih Rating</option>
                                <option value="1">1 Bintang</option>
                                <option value="2">2 Bintang</option>
                                <option value="3">3 Bintang</option>
                                <option value="4">4 Bintang</option>
                                <option value="5">5 Bintang</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Latitude</label>
                            <input type="number" name="koordinat_lat" id="koordinatLat" class="form-control" step="0.000001" placeholder="-8.583333">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Longitude</label>
                            <input type="number" name="koordinat_lng" id="koordinatLng" class="form-control" step="0.000001" placeholder="116.116667">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" id="status" class="form-control" required>
                            <option value="aktif">Aktif</option>
                            <option value="nonaktif">Nonaktif</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Foto Utama</label>
                        <input type="file" name="foto_utama" id="fotoUtama" class="form-control" accept="image/*">
                        <small style="color: #666;">Format: JPG, JPEG, PNG, GIF. Maksimal 5MB</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Foto Tambahan</label>
                        <div id="additionalPhotosContainer">
                            <div class="additional-photo-item">
                                <div class="form-row">
                                    <div class="form-group">
                                        <input type="file" name="foto_tambahan[]" class="form-control" accept="image/*">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="foto_captions[]" class="form-control" placeholder="Keterangan foto (opsional)">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-primary" onclick="addMorePhoto()" style="margin-top: 0.5rem;">
                            <i class="fas fa-plus"></i> Tambah Foto Lain
                        </button>
                        <small style="color: #666; display: block; margin-top: 0.5rem;">
                            Format: JPG, JPEG, PNG, GIF. Maksimal 5MB per foto
                        </small>
                        
                        <!-- Existing photos for edit -->
                        <div id="existingPhotos" style="margin-top: 1rem; display: none;">
                            <label class="form-label">Foto Yang Ada</label>
                            <div id="existingPhotosContainer"></div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Fasilitas</label>
                        <div class="facilities-grid">
                            <?php foreach ($fasilitas_options as $fasilitas): ?>
                                <div class="facility-checkbox">
                                    <input type="checkbox" name="fasilitas[]" value="<?= $fasilitas ?>" id="fasilitas_<?= str_replace(' ', '_', $fasilitas) ?>">
                                    <label for="fasilitas_<?= str_replace(' ', '_', $fasilitas) ?>"><?= $fasilitas ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closeModal()" class="btn" style="background: #6c757d; color: white;">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Hotel Modal -->
    <div class="modal" id="viewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Detail Hotel</h3>
                <button type="button" onclick="closeViewModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <!-- Photo Modal -->
    <div class="photo-modal" id="photoModal">
        <button class="photo-modal-close" onclick="closePhotoModal()">
            <i class="fas fa-times"></i>
        </button>
        <img id="photoModalImg" src="" alt="Hotel Photo">
    </div>

    <script>
        // Sidebar functionality
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');

        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });

        mobileSidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('mobile-open');
            mobileOverlay.classList.add('active');
        });

        function closeMobileSidebar() {
            sidebar.classList.remove('mobile-open');
            mobileOverlay.classList.remove('active');
        }

        // Load sidebar state
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        // Admin dropdown
        function toggleAdminDropdown() {
            const dropdown = document.getElementById('adminDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('adminDropdown');
            const toggle = document.querySelector('.admin-dropdown-toggle');
            
            if (toggle && !toggle.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Modal functions
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Tambah Hotel';
            document.getElementById('formAction').value = 'add';
            document.getElementById('hotelForm').reset();
            document.getElementById('hotelId').value = '';
            
            // Reset additional photos
            resetAdditionalPhotos();
            
            // Hide existing photos section
            document.getElementById('existingPhotos').style.display = 'none';
            
            // Uncheck all facilities
            const facilities = document.querySelectorAll('input[name="fasilitas[]"]');
            facilities.forEach(cb => cb.checked = false);
            
            document.getElementById('hotelModal').classList.add('show');
        }

        function addMorePhoto() {
            const container = document.getElementById('additionalPhotosContainer');
            const photoItem = document.createElement('div');
            photoItem.className = 'additional-photo-item';
            photoItem.innerHTML = `
                <div class="form-row">
                    <div class="form-group">
                        <input type="file" name="foto_tambahan[]" class="form-control" accept="image/*">
                    </div>
                    <div class="form-group">
                        <input type="text" name="foto_captions[]" class="form-control" placeholder="Keterangan foto (opsional)">
                    </div>
                </div>
                <button type="button" class="remove-photo-btn" onclick="removePhotoItem(this)">
                    <i class="fas fa-trash"></i> Hapus
                </button>
            `;
            container.appendChild(photoItem);
        }

        function removePhotoItem(button) {
            button.parentElement.remove();
        }

        function resetAdditionalPhotos() {
            const container = document.getElementById('additionalPhotosContainer');
            container.innerHTML = `
                <div class="additional-photo-item">
                    <div class="form-row">
                        <div class="form-group">
                            <input type="file" name="foto_tambahan[]" class="form-control" accept="image/*">
                        </div>
                        <div class="form-group">
                            <input type="text" name="foto_captions[]" class="form-control" placeholder="Keterangan foto (opsional)">
                        </div>
                    </div>
                </div>
            `;
        }

        function loadExistingPhotos(hotelId) {
            fetch(`hotels.php?ajax=get_hotel_photos&id=${hotelId}`)
                .then(response => response.json())
                .then(photos => {
                    const container = document.getElementById('existingPhotosContainer');
                    const existingSection = document.getElementById('existingPhotos');
                    
                    if (photos && photos.length > 0) {
                        container.innerHTML = '';
                        photos.forEach(photo => {
                            const photoDiv = document.createElement('div');
                            photoDiv.className = 'existing-photo-item';
                            photoDiv.innerHTML = `
                                <img src="../assets/images/${photo.foto_path}" alt="Hotel Photo" class="existing-photo-thumb">
                                <div class="existing-photo-info">
                                    <div style="font-weight: 500;">${photo.foto_path}</div>
                                    <div class="existing-photo-caption">${photo.keterangan || 'Tidak ada keterangan'}</div>
                                </div>
                                <button type="button" class="photo-delete-btn" onclick="deleteExistingPhoto(${photo.id}, this)">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            `;
                            container.appendChild(photoDiv);
                        });
                        existingSection.style.display = 'block';
                    } else {
                        existingSection.style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Error loading photos:', error);
                });
        }

        function deleteExistingPhoto(photoId, button) {
            if (confirm('Apakah Anda yakin ingin menghapus foto ini?')) {
                // Show loading state
                const originalText = button.innerHTML;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghapus...';
                button.disabled = true;
                
                const formData = new FormData();
                formData.append('ajax_action', 'delete_photo');
                formData.append('photo_id', photoId);
                
                fetch('hotels.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        // Remove the photo item with animation
                        const photoItem = button.parentElement;
                        photoItem.style.opacity = '0';
                        photoItem.style.transform = 'translateX(-100%)';
                        
                        setTimeout(() => {
                            photoItem.remove();
                            
                            // Check if any photos left
                            const container = document.getElementById('existingPhotosContainer');
                            if (container.children.length === 0) {
                                document.getElementById('existingPhotos').style.display = 'none';
                            }
                        }, 300);
                        
                        // Show success message
                        showNotification('Foto berhasil dihapus', 'success');
                    } else {
                        // Restore button state
                        button.innerHTML = originalText;
                        button.disabled = false;
                        showNotification('Gagal menghapus foto: ' + (data.message || 'Unknown error'), 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    // Restore button state
                    button.innerHTML = originalText;
                    button.disabled = false;
                    showNotification('Terjadi kesalahan saat menghapus foto. Silakan coba lagi.', 'error');
                });
            }
        }

        function showNotification(message, type) {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `alert alert-${type}`;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 10001;
                min-width: 300px;
                opacity: 0;
                transform: translateY(-20px);
                transition: all 0.3s ease;
            `;
            notification.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
                ${message}
            `;
            
            document.body.appendChild(notification);
            
            // Show notification
            setTimeout(() => {
                notification.style.opacity = '1';
                notification.style.transform = 'translateY(0)';
            }, 100);
            
            // Hide notification after 3 seconds
            setTimeout(() => {
                notification.style.opacity = '0';
                notification.style.transform = 'translateY(-20px)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 3000);
        }

        function editHotel(hotelId) {
            document.getElementById('modalTitle').textContent = 'Edit Hotel';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('hotelId').value = hotelId;
            
            // Reset additional photos container
            resetAdditionalPhotos();
            
            // Fetch hotel data
            fetch(`hotels.php?ajax=get_hotel&id=${hotelId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('namaHotel').value = data.nama_hotel || '';
                        document.getElementById('alamat').value = data.alamat || '';
                        document.getElementById('deskripsi').value = data.deskripsi || '';
                        document.getElementById('hargaPerMalam').value = data.harga_per_malam || '';
                        document.getElementById('ratingBintang').value = data.rating_bintang || '';
                        document.getElementById('koordinatLat').value = data.koordinat_lat || '';
                        document.getElementById('koordinatLng').value = data.koordinat_lng || '';
                        document.getElementById('status').value = data.status || 'aktif';
                        
                        // Set facilities
                        const facilities = document.querySelectorAll('input[name="fasilitas[]"]');
                        facilities.forEach(cb => cb.checked = false);
                        
                        if (data.fasilitas) {
                            const selectedFacilities = data.fasilitas.split(',');
                            selectedFacilities.forEach(facility => {
                                const checkbox = document.querySelector(`input[value="${facility.trim()}"]`);
                                if (checkbox) checkbox.checked = true;
                            });
                        }
                        
                        // Load existing photos
                        loadExistingPhotos(hotelId);
                        
                        document.getElementById('hotelModal').classList.add('show');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Gagal mengambil data hotel');
                });
        }

        function viewHotel(hotelId) {
            // Fetch hotel data
            fetch(`hotels.php?ajax=get_hotel&id=${hotelId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        const modalBody = document.getElementById('viewModalBody');
                        const facilities = data.fasilitas ? data.fasilitas.split(',').map(f => f.trim()).filter(f => f) : [];
                        
                        // Fetch additional photos
                        fetch(`hotels.php?ajax=get_hotel_photos&id=${hotelId}`)
                            .then(response => response.json())
                            .then(photos => {
                                modalBody.innerHTML = `
                                    <div style="display: grid; gap: 1.5rem;">
                                        <div>
                                            <h4 style="margin-bottom: 1rem; color: #333; display: flex; align-items: center; gap: 0.5rem;">
                                                <i class="fas fa-images" style="color: #0052cc;"></i>
                                                Foto Hotel
                                            </h4>
                                            <div class="photo-gallery">
                                                ${data.foto_utama ? `
                                                    <div class="photo-item main-photo">
                                                        <img src="../assets/images/${data.foto_utama}" alt="${data.nama_hotel}" onclick="openPhotoModal('../assets/images/${data.foto_utama}')">
                                                        <div class="photo-label">Foto Utama</div>
                                                    </div>
                                                ` : `
                                                    <div class="photo-item no-photo">
                                                        <div class="no-photo-placeholder">
                                                            <i class="fas fa-hotel"></i>
                                                            <span>Foto Utama Tidak Tersedia</span>
                                                        </div>
                                                    </div>
                                                `}
                                                
                                                ${photos && photos.length > 0 ? photos.map(photo => `
                                                    <div class="photo-item">
                                                        <img src="../assets/images/${photo.foto_path}" alt="${data.nama_hotel}" onclick="openPhotoModal('../assets/images/${photo.foto_path}')">
                                                        ${photo.keterangan ? `<div class="photo-caption">${photo.keterangan}</div>` : ''}
                                                    </div>
                                                `).join('') : ''}
                                                
                                                ${(!data.foto_utama && (!photos || photos.length === 0)) ? `
                                                    <div class="no-photos-message">
                                                        <i class="fas fa-camera" style="font-size: 2rem; margin-bottom: 0.5rem; opacity: 0.5;"></i>
                                                        <p>Belum ada foto untuk hotel ini</p>
                                                    </div>
                                                ` : ''}
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <h4 style="margin-bottom: 0.5rem; color: #333;">${data.nama_hotel}</h4>
                                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                                <div class="stars">
                                                    ${[1,2,3,4,5].map(i => `<i class="fas fa-star ${i <= data.rating_bintang ? 'active' : ''}" style="color: ${i <= data.rating_bintang ? '#ffd700' : '#ddd'}; font-size: 0.9rem;"></i>`).join('')}
                                                </div>
                                                <span>(${data.rating_bintang} Bintang)</span>
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <strong>Harga:</strong> Rp ${new Intl.NumberFormat('id-ID').format(data.harga_per_malam)} / malam
                                        </div>
                                        
                                        <div>
                                            <strong>Status:</strong> 
                                            <span style="background: ${data.status === 'aktif' ? '#d4edda' : '#f8d7da'}; 
                                                         color: ${data.status === 'aktif' ? '#155724' : '#721c24'};
                                                         padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem;">
                                                ${data.status.charAt(0).toUpperCase() + data.status.slice(1)}
                                            </span>
                                        </div>
                                        
                                        <div>
                                            <strong>Alamat:</strong><br>
                                            ${data.alamat}
                                        </div>
                                        
                                        ${data.deskripsi ? `
                                            <div>
                                                <strong>Deskripsi:</strong><br>
                                                ${data.deskripsi}
                                            </div>
                                        ` : ''}
                                        
                                        ${data.koordinat_lat && data.koordinat_lng ? `
                                            <div>
                                                <strong>Koordinat:</strong><br>
                                                Latitude: ${data.koordinat_lat}<br>
                                                Longitude: ${data.koordinat_lng}
                                            </div>
                                        ` : ''}
                                        
                                        ${facilities.length > 0 ? `
                                            <div>
                                                <strong>Fasilitas:</strong><br>
                                                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem;">
                                                    ${facilities.map(facility => `
                                                        <span style="background: #e9ecef; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">
                                                            ${facility}
                                                        </span>
                                                    `).join('')}
                                                </div>
                                            </div>
                                        ` : ''}
                                    </div>
                                `;
                                
                                document.getElementById('viewModal').classList.add('show');
                            })
                            .catch(error => {
                                console.error('Error fetching photos:', error);
                                // Show modal even if photos fail to load
                                modalBody.innerHTML = `
                                    <div style="display: grid; gap: 1.5rem;">
                                        ${data.foto_utama ? `
                                            <div>
                                                <img src="../assets/images/${data.foto_utama}" alt="${data.nama_hotel}" 
                                                     style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px;">
                                            </div>
                                        ` : ''}
                                        
                                        <div>
                                            <h4 style="margin-bottom: 0.5rem; color: #333;">${data.nama_hotel}</h4>
                                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                                <div class="stars">
                                                    ${[1,2,3,4,5].map(i => `<i class="fas fa-star ${i <= data.rating_bintang ? 'active' : ''}" style="color: ${i <= data.rating_bintang ? '#ffd700' : '#ddd'}; font-size: 0.9rem;"></i>`).join('')}
                                                </div>
                                                <span>(${data.rating_bintang} Bintang)</span>
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <strong>Harga:</strong> Rp ${new Intl.NumberFormat('id-ID').format(data.harga_per_malam)} / malam
                                        </div>
                                        
                                        <div>
                                            <strong>Status:</strong> 
                                            <span style="background: ${data.status === 'aktif' ? '#d4edda' : '#f8d7da'}; 
                                                         color: ${data.status === 'aktif' ? '#155724' : '#721c24'};
                                                         padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem;">
                                                ${data.status.charAt(0).toUpperCase() + data.status.slice(1)}
                                            </span>
                                        </div>
                                        
                                        <div>
                                            <strong>Alamat:</strong><br>
                                            ${data.alamat}
                                        </div>
                                        
                                        ${data.deskripsi ? `
                                            <div>
                                                <strong>Deskripsi:</strong><br>
                                                ${data.deskripsi}
                                            </div>
                                        ` : ''}
                                        
                                        ${data.koordinat_lat && data.koordinat_lng ? `
                                            <div>
                                                <strong>Koordinat:</strong><br>
                                                Latitude: ${data.koordinat_lat}<br>
                                                Longitude: ${data.koordinat_lng}
                                            </div>
                                        ` : ''}
                                        
                                        ${facilities.length > 0 ? `
                                            <div>
                                                <strong>Fasilitas:</strong><br>
                                                <div style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem;">
                                                    ${facilities.map(facility => `
                                                        <span style="background: #e9ecef; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem;">
                                                            ${facility}
                                                        </span>
                                                    `).join('')}
                                                </div>
                                            </div>
                                        ` : ''}
                                    </div>
                                `;
                                
                                document.getElementById('viewModal').classList.add('show');
                            });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Gagal mengambil data hotel');
                });
        }

        function closeModal() {
            document.getElementById('hotelModal').classList.remove('show');
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.remove('show');
        }

        function openPhotoModal(photoSrc) {
            document.getElementById('photoModalImg').src = photoSrc;
            document.getElementById('photoModal').classList.add('show');
        }

        function closePhotoModal() {
            document.getElementById('photoModal').classList.remove('show');
        }

        function toggleStatus(hotelId, currentStatus) {
            const newStatus = currentStatus === 'aktif' ? 'nonaktif' : 'aktif';
            const action = newStatus === 'aktif' ? 'mengaktifkan' : 'menonaktifkan';
            
            if (confirm(`Apakah Anda yakin ingin ${action} hotel ini?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="toggle_status">
                    <input type="hidden" name="hotel_id" value="${hotelId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteHotel(hotelId, hotelName) {
            if (confirm(`Apakah Anda yakin ingin menghapus hotel "${hotelName}"?\n\nTindakan ini tidak dapat dibatalkan dan akan menghapus semua data terkait termasuk foto, favorit, dan riwayat pencarian.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="hotel_id" value="${hotelId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Close modals when clicking outside
        document.addEventListener('click', function(event) {
            const hotelModal = document.getElementById('hotelModal');
            const viewModal = document.getElementById('viewModal');
            const photoModal = document.getElementById('photoModal');
            
            if (event.target === hotelModal) {
                closeModal();
            }
            
            if (event.target === viewModal) {
                closeViewModal();
            }
            
            if (event.target === photoModal) {
                closePhotoModal();
            }
        });

        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);
    </script>
</body>
</html>