<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'];

// Get dashboard statistics
// Total hotels
$total_hotels_sql = "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'";
$total_hotels_result = mysqli_query($conn, $total_hotels_sql);
$total_hotels = mysqli_fetch_assoc($total_hotels_result)['total'];

// Total users
$total_users_sql = "SELECT COUNT(*) as total FROM users";
$total_users_result = mysqli_query($conn, $total_users_sql);
$total_users = mysqli_fetch_assoc($total_users_result)['total'];

// Total searches today
$searches_today_sql = "SELECT COUNT(*) as total FROM search_history WHERE DATE(created_at) = CURDATE()";
$searches_today_result = mysqli_query($conn, $searches_today_sql);
$searches_today = mysqli_fetch_assoc($searches_today_result)['total'];

// Total favorites
$total_favorites_sql = "SELECT COUNT(*) as total FROM user_favorites";
$total_favorites_result = mysqli_query($conn, $total_favorites_sql);
$total_favorites = mysqli_fetch_assoc($total_favorites_result)['total'];

// Recent activities
$recent_activities_sql = "
    (SELECT 'user_register' as type, nama_lengkap as title, created_at, 'User baru mendaftar' as description 
     FROM users ORDER BY created_at DESC LIMIT 5)
    UNION ALL
    (SELECT 'search' as type, CONCAT('Pencarian oleh User ID ', user_id) as title, created_at, 
     CONCAT(total_hotels_found, ' hotel ditemukan') as description 
     FROM search_history ORDER BY created_at DESC LIMIT 5)
    ORDER BY created_at DESC LIMIT 10";

$recent_activities_result = mysqli_query($conn, $recent_activities_sql);
$recent_activities = mysqli_fetch_all($recent_activities_result, MYSQLI_ASSOC);

// Top hotels by favorites
$top_hotels_sql = "SELECT h.nama_hotel, h.rating_bintang, COUNT(uf.id) as favorite_count 
                   FROM hotels h 
                   LEFT JOIN user_favorites uf ON h.id = uf.hotel_id 
                   WHERE h.status = 'aktif'
                   GROUP BY h.id 
                   ORDER BY favorite_count DESC, h.rating_bintang DESC 
                   LIMIT 5";
$top_hotels_result = mysqli_query($conn, $top_hotels_sql);
$top_hotels = mysqli_fetch_all($top_hotels_result, MYSQLI_ASSOC);

// Search trends (last 7 days)
$search_trends_sql = "SELECT DATE(created_at) as date, COUNT(*) as searches 
                     FROM search_history 
                     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                     GROUP BY DATE(created_at) 
                     ORDER BY date ASC";
$search_trends_result = mysqli_query($conn, $search_trends_sql);
$search_trends = mysqli_fetch_all($search_trends_result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span class="logo-text">SPK Hotel Admin</span>
                </div>
                <!-- <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button> -->
            </div>

            <nav class="sidebar-nav">
                <ul class="nav-list">
                    <li class="nav-item active">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i>
                            <span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="hotels.php" class="nav-link">
                            <i class="fas fa-building"></i>
                            <span class="nav-text">Kelola Hotel</span>
                            <span class="nav-badge"><?= $total_hotels ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="criteria.php" class="nav-link">
                            <i class="fas fa-sliders-h"></i>
                            <span class="nav-text">Kriteria SAW</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="users.php" class="nav-link">
                            <i class="fas fa-users"></i>
                            <span class="nav-text">Kelola User</span>
                            <span class="nav-badge"><?= $total_users ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="analytics.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i>
                            <span class="nav-text">Analytics</span>
                        </a>
                    </li>
                </ul>

                <div class="sidebar-footer">
                    <div class="admin-info">
                        <div class="admin-avatar">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="admin-details">
                            <span class="admin-name"><?= htmlspecialchars($admin_name) ?></span>
                            <span class="admin-role">Administrator</span>
                        </div>
                    </div>
                    <a href="../logout.php" class="logout-btn" title="Logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="topbar">
                <div class="topbar-left">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="page-title">Dashboard</h1>
                </div>
                <div class="topbar-right">
                    <div class="topbar-item">
                        <button class="notification-btn" onclick="showNotifications()">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge">3</span>
                        </button>
                    </div>
                    <div class="topbar-item">
                        <a href="../index.php" class="view-site-btn" target="_blank">
                            <i class="fas fa-external-link-alt"></i>
                            <span>Lihat Website</span>
                        </a>
                    </div>
                    <div class="topbar-item">
                        <div class="admin-dropdown">
                            <button class="admin-dropdown-toggle" onclick="toggleAdminDropdown()">
                                <i class="fas fa-user-circle"></i>
                                <span><?= htmlspecialchars($admin_name) ?></span>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="admin-dropdown-menu" id="adminDropdown">
                                <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                                <a href="settings.php"><i class="fas fa-cog"></i> Pengaturan</a>
                                <div class="dropdown-divider"></div>
                                <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Statistics Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon hotels">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_hotels ?></div>
                            <div class="stat-label">Total Hotel</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+2 bulan ini</span>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-icon users">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_users ?></div>
                            <div class="stat-label">Total User</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+<?= $total_users > 10 ? '5' : '1' ?> minggu ini</span>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-icon searches">
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $searches_today ?></div>
                            <div class="stat-label">Pencarian Hari Ini</div>
                            <div class="stat-change neutral">
                                <i class="fas fa-clock"></i>
                                <span>Real-time</span>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card">
                        <div class="stat-icon favorites">
                            <i class="fas fa-heart"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_favorites ?></div>
                            <div class="stat-label">Total Favorit</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>+<?= round($total_favorites * 0.1) ?> minggu ini</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts and Analytics -->
                <div class="analytics-grid">
                    <div class="chart-card">
                        <div class="card-header">
                            <h3><i class="fas fa-chart-line"></i> Tren Pencarian (7 Hari Terakhir)</h3>
                            <div class="card-actions">
                                <button class="btn-icon" onclick="refreshChart()">
                                    <i class="fas fa-sync-alt"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-content">
                            <canvas id="searchTrendsChart" height="120"></canvas>
                        </div>
                    </div>

                    <div class="popular-hotels">
                        <div class="card-header">
                            <h3><i class="fas fa-star"></i> Hotel Terpopuler</h3>
                            <a href="hotels.php" class="view-all-link">Lihat Semua</a>
                        </div>
                        <div class="card-content">
                            <?php if (!empty($top_hotels)) { ?>
                                <div class="hotel-list">
                                    <?php foreach ($top_hotels as $index => $hotel) { ?>
                                    <div class="hotel-item">
                                        <div class="hotel-rank">#<?= $index + 1 ?></div>
                                        <div class="hotel-info">
                                            <div class="hotel-name"><?= htmlspecialchars($hotel['nama_hotel']) ?></div>
                                            <div class="hotel-stats">
                                                <span class="rating">
                                                    <?php for ($i = 1; $i <= 5; $i++) { ?>
                                                        <i class="fas fa-star <?= $i <= $hotel['rating_bintang'] ? 'active' : '' ?>"></i>
                                                    <?php } ?>
                                                </span>
                                                <span class="favorites"><?= $hotel['favorite_count'] ?> favorit</span>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            <?php } else { ?>
                                <div class="empty-state">
                                    <i class="fas fa-star"></i>
                                    <p>Belum ada data favorit hotel</p>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="activity-section">
                    <div class="card-header">
                        <h3><i class="fas fa-clock"></i> Aktivitas Terbaru</h3>
                        <div class="activity-filters">
                            <button class="filter-btn active" onclick="filterActivities('all')">Semua</button>
                            <button class="filter-btn" onclick="filterActivities('user')">User</button>
                            <button class="filter-btn" onclick="filterActivities('search')">Pencarian</button>
                        </div>
                    </div>
                    <div class="card-content">
                        <?php if (!empty($recent_activities)) { ?>
                            <div class="activity-timeline">
                                <?php foreach ($recent_activities as $activity) { 
                                    $icon = $activity['type'] === 'user_register' ? 'fa-user-plus' : 'fa-search';
                                    $color = $activity['type'] === 'user_register' ? 'success' : 'info';
                                ?>
                                <div class="activity-item" data-type="<?= $activity['type'] ?>">
                                    <div class="activity-icon <?= $color ?>">
                                        <i class="fas <?= $icon ?>"></i>
                                    </div>
                                    <div class="activity-content">
                                        <div class="activity-title"><?= htmlspecialchars($activity['title']) ?></div>
                                        <div class="activity-description"><?= htmlspecialchars($activity['description']) ?></div>
                                        <div class="activity-time"><?= date('d M Y, H:i', strtotime($activity['created_at'])) ?></div>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        <?php } else { ?>
                            <div class="empty-state">
                                <i class="fas fa-clock"></i>
                                <p>Belum ada aktivitas terbaru</p>
                            </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <h3>Aksi Cepat</h3>
                    <div class="actions-grid">
                        <a href="hotels.php?action=add" class="action-card">
                            <div class="action-icon">
                                <i class="fas fa-plus"></i>
                            </div>
                            <div class="action-content">
                                <div class="action-title">Tambah Hotel</div>
                                <div class="action-desc">Tambah hotel baru ke sistem</div>
                            </div>
                        </a>

                        <a href="users.php" class="action-card">
                            <div class="action-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="action-content">
                                <div class="action-title">Kelola User</div>
                                <div class="action-desc">Lihat dan kelola user terdaftar</div>
                            </div>
                        </a>

                        <a href="analytics.php" class="action-card">
                            <div class="action-icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                            <div class="action-content">
                                <div class="action-title">Lihat Analytics</div>
                                <div class="action-desc">Analisis data dan statistik</div>
                            </div>
                        </a>

                        <a href="criteria.php" class="action-card">
                            <div class="action-icon">
                                <i class="fas fa-sliders-h"></i>
                            </div>
                            <div class="action-content">
                                <div class="action-title">Atur Kriteria</div>
                                <div class="action-desc">Konfigurasi bobot SAW</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay" onclick="closeMobileSidebar()"></div>

    <script>
        // Sidebar Toggle
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');

        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });

        mobileSidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('mobile-open');
            mobileOverlay.classList.add('active');
        });

        function closeMobileSidebar() {
            sidebar.classList.remove('mobile-open');
            mobileOverlay.classList.remove('active');
        }

        // Load sidebar state
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        // Admin dropdown
        function toggleAdminDropdown() {
            const dropdown = document.getElementById('adminDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('adminDropdown');
            const toggle = document.querySelector('.admin-dropdown-toggle');
            
            if (!toggle.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Search Trends Chart
        const ctx = document.getElementById('searchTrendsChart').getContext('2d');
        const chartData = {
            labels: [<?php echo '"' . implode('", "', array_map(function($trend) { return date('d/m', strtotime($trend['date'])); }, $search_trends)) . '"'; ?>],
            datasets: [{
                label: 'Pencarian',
                data: [<?php echo implode(', ', array_column($search_trends, 'searches')); ?>],
                borderColor: '#0052cc',
                backgroundColor: 'rgba(0, 82, 204, 0.1)',
                tension: 0.4,
                fill: true
            }]
        };

        const searchTrendsChart = new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Activity filters
        function filterActivities(type) {
            const buttons = document.querySelectorAll('.filter-btn');
            const activities = document.querySelectorAll('.activity-item');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            activities.forEach(activity => {
                if (type === 'all' || activity.dataset.type === type) {
                    activity.style.display = 'flex';
                } else {
                    activity.style.display = 'none';
                }
            });
        }

        // Refresh chart
        function refreshChart() {
            location.reload();
        }

        // Show notifications
        function showNotifications() {
            alert('Fitur notifikasi akan segera hadir!');
        }

        // Auto-refresh stats every 5 minutes
        setInterval(() => {
            fetch('ajax/get_dashboard_stats.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update stat numbers
                    document.querySelector('.stat-card:nth-child(3) .stat-number').textContent = data.searches_today;
                }
            })
            .catch(error => console.error('Error refreshing stats:', error));
        }, 300000); // 5 minutes
    </script>
</body>
</html>