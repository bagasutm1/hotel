<?php
// sidebar.php
// Mendapatkan nama file halaman saat ini
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Atau bisa juga menggunakan parameter yang dikirim
if (isset($active_page)) {
    $current_page = $active_page;
}

// Function untuk mengecek apakah menu aktif
function isActive($page, $current)
{
    return $page === $current ? 'active' : '';
}
?>

<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-hotel"></i>
            <span class="logo-text">SPK Hotel Admin</span>
        </div>
    </div>

    <nav class="sidebar-nav">
        <ul class="nav-list">
            <li class="nav-item <?= isActive('dashboard', $current_page) ?>">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item <?= isActive('hotels', $current_page) ?>">
                <a href="hotels.php" class="nav-link">
                    <i class="fas fa-building"></i>
                    <span class="nav-text">Kelola Hotel</span>
                </a>
            </li>
            <li class="nav-item <?= isActive('criteria', $current_page) ?>">
                <a href="criteria.php" class="nav-link">
                    <i class="fas fa-sliders-h"></i>
                    <span class="nav-text">Kriteria SAW</span>
                </a>
            </li>
            <li class="nav-item <?= isActive('users', $current_page) ?>">
                <a href="users.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span class="nav-text">Kelola User</span>
                </a>
            </li>
            <li class="nav-item <?= isActive('admins', $current_page) ?>">
                <a href="admins.php" class="nav-link">
                    <i class="fas fa-user-shield"></i>
                    <span class="nav-text">Kelola Admin</span>
                </a>
            </li>
            <li class="nav-item <?= isActive('orders', $current_page) ?>">
                <a href="orders.php" class="nav-link">
                    <i class="fas fa-receipt"></i>
                    <span class="nav-text">Kelola Order</span>
                </a>
            </li>
            <li class="nav-item <?= isActive('orders', $current_page) ?>">
                <a href="admin_hotel_criteria_values.php" class="nav-link">
                    <i class="fas fa-receipt"></i>
                    <span class="nav-text">Kelola Nilai</span>
                </a>
            </li>


        </ul>

        <div class="sidebar-footer">
            <div class="admin-info">
                <div class="admin-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="admin-details">
                    <span class="admin-name"><?= htmlspecialchars($admin_name) ?></span>
                    <span class="admin-role">Administrator</span>
                </div>
            </div>
            <a href="../logout.php" class="logout-btn" title="Logout">
                <i class="fas fa-sign-out-alt"></i>
                <span class="nav-text">Logout</span>
            </a>
        </div>
    </nav>
</aside>