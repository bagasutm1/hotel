<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'] ?? 'Admin';


// Handle CRUD operations
$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $result = addUser($_POST, $_FILES);
                break;
            case 'edit':
                $result = editUser($_POST, $_FILES);
                break;
            case 'delete':
                $result = deleteUser($_POST['user_id']);
                break;
            case 'reset_password':
                $result = resetPassword($_POST['user_id']);
                break;
            case 'toggle_status':
                $result = toggleUserStatus($_POST['user_id']);
                break;
        }
        
        if ($result) {
            $message = $result['message'];
            $message_type = $result['type'];
        }
    }
}

// Handle AJAX requests
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    
    switch ($_GET['ajax']) {
        case 'get_user':
            $user_id = intval($_GET['id']);
            $user = getUserById($user_id);
            echo json_encode($user);
            exit();
            
        case 'check_email':
            $email = mysqli_real_escape_string($conn, $_GET['email']);
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            $exists = checkEmailExists($email, $id);
            echo json_encode(['exists' => $exists]);
            exit();
            
        case 'check_username':
            $username = mysqli_real_escape_string($conn, $_GET['username']);
            $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
            $exists = checkUsernameExists($username, $id);
            echo json_encode(['exists' => $exists]);
            exit();
            
        case 'get_user_stats':
            $user_id = intval($_GET['id']);
            $stats = getUserStats($user_id);
            echo json_encode($stats);
            exit();
            
        case 'get_user_profile_photo':
            $user_id = intval($_GET['id']);
            $user = getUserById($user_id);
            $photo_url = '';
            if ($user['foto_profil'] && file_exists('../assets/images/profiles/' . $user['foto_profil'])) {
                $photo_url = '../assets/images/profiles/' . $user['foto_profil'];
            }
            echo json_encode(['photo_url' => $photo_url]);
            exit();
    }
}

// Function to add user
function addUser($data, $files = null) {
    global $conn;
    
    $username = mysqli_real_escape_string($conn, $data['username']);
    $email = mysqli_real_escape_string($conn, $data['email']);
    $password = password_hash($data['password'], PASSWORD_DEFAULT);
    $nama_lengkap = mysqli_real_escape_string($conn, $data['nama_lengkap']);
    $no_telepon = mysqli_real_escape_string($conn, $data['no_telepon']);
    $alamat = mysqli_real_escape_string($conn, $data['alamat']);
    
    // Check if email already exists
    if (checkEmailExists($email)) {
        return array('message' => 'Email sudah digunakan', 'type' => 'error');
    }
    
    // Check if username already exists
    if (checkUsernameExists($username)) {
        return array('message' => 'Username sudah digunakan', 'type' => 'error');
    }
    
    // Handle profile photo upload
    $foto_profil = '';
    if (isset($files['foto_profil']) && $files['foto_profil']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadProfilePhoto($files['foto_profil']);
        if ($upload_result['success']) {
            $foto_profil = $upload_result['filename'];
        } else {
            return array('message' => $upload_result['message'], 'type' => 'error');
        }
    }
    
    $sql = "INSERT INTO users (username, email, password, nama_lengkap, no_telepon, alamat, foto_profil) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssss", $username, $email, $password, $nama_lengkap, $no_telepon, $alamat, $foto_profil);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'User berhasil ditambahkan!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal menambahkan user: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to edit user
function editUser($data, $files = null) {
    global $conn;
    
    $user_id = intval($data['user_id']);
    $username = mysqli_real_escape_string($conn, $data['username']);
    $email = mysqli_real_escape_string($conn, $data['email']);
    $nama_lengkap = mysqli_real_escape_string($conn, $data['nama_lengkap']);
    $no_telepon = mysqli_real_escape_string($conn, $data['no_telepon']);
    $alamat = mysqli_real_escape_string($conn, $data['alamat']);
    
    // Check if email already exists (exclude current record)
    if (checkEmailExists($email, $user_id)) {
        return array('message' => 'Email sudah digunakan', 'type' => 'error');
    }
    
    // Check if username already exists (exclude current record)
    if (checkUsernameExists($username, $user_id)) {
        return array('message' => 'Username sudah digunakan', 'type' => 'error');
    }
    
    // Handle profile photo upload
    $foto_profil_update = '';
    if (isset($files['foto_profil']) && $files['foto_profil']['error'] === UPLOAD_ERR_OK) {
        $upload_result = uploadProfilePhoto($files['foto_profil']);
        if ($upload_result['success']) {
            // Delete old photo
            $old_user = getUserById($user_id);
            if ($old_user['foto_profil'] && file_exists('../assets/images/profiles/' . $old_user['foto_profil'])) {
                unlink('../assets/images/profiles/' . $old_user['foto_profil']);
            }
            $foto_profil_update = ", foto_profil = '" . $upload_result['filename'] . "'";
        } else {
            return array('message' => $upload_result['message'], 'type' => 'error');
        }
    }
    
    $sql = "UPDATE users SET 
            username = ?, email = ?, nama_lengkap = ?, no_telepon = ?, alamat = ?, updated_at = NOW() $foto_profil_update
            WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssi", $username, $email, $nama_lengkap, $no_telepon, $alamat, $user_id);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => 'User berhasil diperbarui!', 'type' => 'success');
    } else {
        return array('message' => 'Gagal memperbarui user: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to delete user
function deleteUser($user_id) {
    global $conn;
    
    // Get user data for profile photo deletion
    $user = getUserById($user_id);
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Delete profile photo file
        if ($user['foto_profil'] && file_exists('../assets/images/profiles/' . $user['foto_profil'])) {
            unlink('../assets/images/profiles/' . $user['foto_profil']);
        }
        
        // Delete user favorites
        mysqli_query($conn, "DELETE FROM user_favorites WHERE user_id = $user_id");
        
        // Delete search history
        mysqli_query($conn, "DELETE FROM search_history WHERE user_id = $user_id");
        
        // Delete user
        mysqli_query($conn, "DELETE FROM users WHERE id = $user_id");
        
        mysqli_commit($conn);
        return array('message' => 'User berhasil dihapus!', 'type' => 'success');
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return array('message' => 'Gagal menghapus user: ' . $e->getMessage(), 'type' => 'error');
    }
}

// Function to reset password
function resetPassword($user_id) {
    global $conn;
    
    // Generate new random password
    $new_password = generateRandomPassword();
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    
    $sql = "UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $hashed_password, $user_id);
    
    if (mysqli_stmt_execute($stmt)) {
        return array('message' => "Password berhasil direset! Password baru: $new_password", 'type' => 'success');
    } else {
        return array('message' => 'Gagal reset password: ' . mysqli_error($conn), 'type' => 'error');
    }
}

// Function to toggle user status (if needed for future implementation)
function toggleUserStatus($user_id) {
    // This function can be implemented if you add a status field to users table
    return array('message' => 'Fitur status user akan segera hadir!', 'type' => 'info');
}

// Function to upload profile photo
function uploadProfilePhoto($file) {
    $target_dir = "../assets/images/profiles/";
    $allowed_types = array('jpg', 'jpeg', 'png', 'gif');
    $max_size = 2 * 1024 * 1024; // 2MB
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // Validate file type
    if (!in_array($file_extension, $allowed_types)) {
        return array('success' => false, 'message' => 'Tipe file tidak diizinkan. Gunakan JPG, JPEG, PNG, atau GIF.');
    }
    
    // Validate file size
    if ($file['size'] > $max_size) {
        return array('success' => false, 'message' => 'Ukuran file terlalu besar. Maksimal 2MB.');
    }
    
    // Generate unique filename
    $filename = 'profile_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
    $target_file = $target_dir . $filename;
    
    // Create directory if not exists
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return array('success' => true, 'filename' => $filename);
    } else {
        return array('success' => false, 'message' => 'Gagal mengupload file.');
    }
}

// Helper functions
function getUserById($user_id) {
    global $conn;
    
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    return mysqli_fetch_assoc($result);
}

function checkEmailExists($email, $exclude_id = 0) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM users WHERE email = ?";
    if ($exclude_id > 0) {
        $sql .= " AND id != ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($exclude_id > 0) {
        mysqli_stmt_bind_param($stmt, "si", $email, $exclude_id);
    } else {
        mysqli_stmt_bind_param($stmt, "s", $email);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    
    return $data['count'] > 0;
}

function checkUsernameExists($username, $exclude_id = 0) {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM users WHERE username = ?";
    if ($exclude_id > 0) {
        $sql .= " AND id != ?";
    }
    
    $stmt = mysqli_prepare($conn, $sql);
    if ($exclude_id > 0) {
        mysqli_stmt_bind_param($stmt, "si", $username, $exclude_id);
    } else {
        mysqli_stmt_bind_param($stmt, "s", $username);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = mysqli_fetch_assoc($result);
    
    return $data['count'] > 0;
}

function getUserStats($user_id) {
    global $conn;
    
    // Get user statistics
    $favorites_count = mysqli_query($conn, "SELECT COUNT(*) as count FROM user_favorites WHERE user_id = $user_id")->fetch_assoc()['count'];
    $searches_count = mysqli_query($conn, "SELECT COUNT(*) as count FROM search_history WHERE user_id = $user_id")->fetch_assoc()['count'];
    $last_search = mysqli_query($conn, "SELECT created_at FROM search_history WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
    
    return [
        'favorites_count' => $favorites_count,
        'searches_count' => $searches_count,
        'last_search' => $last_search ? $last_search['created_at'] : null
    ];
}

function generateRandomPassword($length = 8) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $password;
}

// Get users with pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 12;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$where_clause = '';
if (!empty($search)) {
    $where_clause = "WHERE nama_lengkap LIKE '%$search%' OR email LIKE '%$search%' OR username LIKE '%$search%'";
}

// Get total count
$count_sql = "SELECT COUNT(*) as total FROM users $where_clause";
$count_result = mysqli_query($conn, $count_sql);
$total_users = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_users / $limit);

// Get users with statistics
$users_sql = "SELECT u.*, 
               (SELECT COUNT(*) FROM user_favorites uf WHERE uf.user_id = u.id) as favorites_count,
               (SELECT COUNT(*) FROM search_history sh WHERE sh.user_id = u.id) as searches_count,
               (SELECT MAX(created_at) FROM search_history sh2 WHERE sh2.user_id = u.id) as last_search_date
               FROM users u 
               $where_clause 
               ORDER BY u.created_at DESC 
               LIMIT $limit OFFSET $offset";
$users_result = mysqli_query($conn, $users_sql);
$users = mysqli_fetch_all($users_result, MYSQLI_ASSOC);

// Get statistics
$total_hotels_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'")->fetch_assoc()['total'];
$total_criteria_count = mysqli_query($conn, "SELECT COUNT(*) as total FROM criteria")->fetch_assoc()['total'];
$total_users_count = $total_users;

// Get user statistics for dashboard
$new_users_this_month = mysqli_query($conn, "SELECT COUNT(*) as count FROM users WHERE DATE(created_at) >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch_assoc()['count'];
$active_users_this_week = mysqli_query($conn, "SELECT COUNT(DISTINCT user_id) as count FROM search_history WHERE DATE(created_at) >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()['count'];
$total_favorites = mysqli_query($conn, "SELECT COUNT(*) as count FROM user_favorites")->fetch_assoc()['count'];
$total_searches = mysqli_query($conn, "SELECT COUNT(*) as count FROM search_history")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola User - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Additional styles for user management */
        .user-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s ease;
            border: 1px solid #e9ecef;
        }
        
        .user-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        
        .user-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1.5rem;
            text-align: center;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2rem;
            overflow: hidden;
        }
        
        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .user-name {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .user-username {
            opacity: 0.8;
            font-size: 0.9rem;
        }
        
        .user-content {
            padding: 1.5rem;
        }
        
        .user-info {
            margin-bottom: 1.5rem;
        }
        
        .user-info-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.75rem;
            color: #666;
            font-size: 0.9rem;
        }
        
        .user-info-item i {
            width: 16px;
            color: #0052cc;
        }
        
        .user-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .user-stat {
            text-align: center;
            padding: 0.75rem;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .user-stat-value {
            font-size: 1.2rem;
            font-weight: bold;
            color: #0052cc;
            margin-bottom: 0.25rem;
        }
        
        .user-stat-label {
            font-size: 0.8rem;
            color: #666;
        }
        
        .user-actions {
            display: flex;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        
        .users-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 2rem;
            margin-top: 1.5rem;
        }
        
        .users-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .search-box {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .search-input {
            padding: 0.75rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            width: 300px;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #0052cc;
        }
        
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: #0052cc;
            color: white;
        }
        
        .btn-primary:hover {
            background: #003d99;
        }
        
        .btn-warning {
            background: #ffc107;
            color: #212529;
        }
        
        .btn-warning:hover {
            background: #e0a800;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background: #c82333;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
        }
        
        .btn-info {
            background: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background: #138496;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            padding: 1.5rem;
            border-bottom: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            padding: 1rem 1.5rem;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            border-radius: 6px;
            font-size: 0.9rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #0052cc;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .alert {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid transparent;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        
        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border-color: #bee5eb;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .pagination a, .pagination span {
            padding: 0.5rem 1rem;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
        }
        
        .pagination a:hover {
            background: #f8f9fa;
        }
        
        .pagination .current {
            background: #0052cc;
            color: white;
            border-color: #0052cc;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            border: 1px solid #e9ecef;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: #ddd;
            margin-bottom: 1rem;
        }
        
        .user-registration-date {
            font-size: 0.8rem;
            color: #999;
            margin-top: 0.5rem;
        }
        
        .validation-message {
            font-size: 0.8rem;
            margin-top: 0.25rem;
            display: none;
        }
        
        .validation-message.error {
            color: #dc3545;
        }
        
        .validation-message.success {
            color: #28a745;
        }
        
        /* Photo Modal Styles */
        .photo-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 20000;
            align-items: center;
            justify-content: center;
        }
        
        .photo-modal.show {
            display: flex;
        }
        
        .photo-modal img {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
            border-radius: 8px;
        }
        
        .photo-modal-close {
            position: absolute;
            top: 20px;
            right: 30px;
            color: white;
            font-size: 2rem;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background 0.3s ease;
        }
        
        .photo-modal-close:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        @media (max-width: 768px) {
            .users-grid {
                grid-template-columns: 1fr;
            }
            
            .users-header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .search-input {
                width: 100%;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .user-actions {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
         <?php include "sidebar.php" ?>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
             <?php include "topbar.php" ?>

            <!-- Users Content -->
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?= $message_type ?>">
                        <i class="fas fa-<?= $message_type === 'success' ? 'check-circle' : ($message_type === 'info' ? 'info-circle' : 'exclamation-circle') ?>"></i>
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <!-- Statistics Cards -->
                <div class="stats-grid" style="margin-bottom: 2rem;">
                    <div class="stat-card">
                        <div class="stat-icon users">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $total_users_count ?></div>
                            <div class="stat-label">Total User</div>
                            <div class="stat-change neutral">
                                <i class="fas fa-search"></i>
                                <span><?= empty($search) ? 'Semua User' : 'Hasil Pencarian' ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #28a745, #20c997);">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $new_users_this_month ?></div>
                            <div class="stat-label">User Baru (30 Hari)</div>
                            <div class="stat-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>Bulan ini</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="background: linear-gradient(135deg, #17a2b8, #007bff);">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-content">
                            <div class="stat-number"><?= $active_users_this_week ?></div>
                            <div class="stat-label">User Aktif (7 Hari)</div>
                            <div class="stat-change positive">
                                <i class="fas fa-users"></i>
                                <span>Minggu ini</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Users Header -->
                <div class="users-header">
                    <div class="search-box">
                        <form method="GET" class="search-form" style="display: flex; gap: 1rem;">
                            <input type="text" name="search" class="search-input" placeholder="Cari user..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i>
                            </button>
                            <?php if ($search): ?>
                                <a href="users.php" class="btn btn-warning">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </form>
                    </div>
                    <div style="display: flex; gap: 1rem;">
                        <button class="btn btn-success" onclick="openAddModal()">
                            <i class="fas fa-plus"></i> Tambah User
                        </button>
                    </div>
                </div>

                <!-- Users Grid -->
                <?php if (!empty($users)): ?>
                    <div class="users-grid">
                        <?php foreach ($users as $user): ?>
                            <div class="user-card">
                                <div class="user-header">
                                    <div class="user-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div class="user-name"><?= htmlspecialchars($user['nama_lengkap']) ?></div>
                                    <div class="user-username">@<?= htmlspecialchars($user['username']) ?></div>
                                </div>
                                
                                <div class="user-content">
                                    <div class="user-info">
                                        <div class="user-info-item">
                                            <i class="fas fa-envelope"></i>
                                            <span><?= htmlspecialchars($user['email']) ?></span>
                                        </div>
                                        <?php if ($user['no_telepon']): ?>
                                            <div class="user-info-item">
                                                <i class="fas fa-phone"></i>
                                                <span><?= htmlspecialchars($user['no_telepon']) ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if ($user['alamat']): ?>
                                            <div class="user-info-item">
                                                <i class="fas fa-map-marker-alt"></i>
                                                <span><?= htmlspecialchars(substr($user['alamat'], 0, 50)) ?><?= strlen($user['alamat']) > 50 ? '...' : '' ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="user-stats">
                                        <div class="user-stat">
                                            <div class="user-stat-value"><?= $user['favorites_count'] ?></div>
                                            <div class="user-stat-label">Favorit</div>
                                        </div>
                                        <div class="user-stat">
                                            <div class="user-stat-value"><?= $user['searches_count'] ?></div>
                                            <div class="user-stat-label">Pencarian</div>
                                        </div>
                                    </div>
                                    
                                    <div class="user-registration-date">
                                        <i class="fas fa-calendar"></i>
                                        Bergabung: <?= date('d M Y', strtotime($user['created_at'])) ?>
                                        <?php if ($user['last_search_date']): ?>
                                            <br><i class="fas fa-clock"></i>
                                            Terakhir aktif: <?= date('d M Y, H:i', strtotime($user['last_search_date'])) ?>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="user-actions">
                                        <button class="btn btn-primary" onclick="viewUser(<?= $user['id'] ?>)">
                                            <i class="fas fa-eye"></i> Detail
                                        </button>
                                        <!-- <button class="btn btn-warning" onclick="editUser(<?= $user['id'] ?>)">
                                            <i class="fas fa-edit"></i> Edit
                                        </button> -->
                                        <button class="btn btn-info" onclick="resetPassword(<?= $user['id'] ?>, '<?= htmlspecialchars($user['nama_lengkap']) ?>')">
                                            <i class="fas fa-key"></i> Reset Password
                                        </button>
                                        <button class="btn btn-danger" onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['nama_lengkap']) ?>')">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?= $page - 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == $page): ?>
                                    <span class="current"><?= $i ?></span>
                                <?php else: ?>
                                    <a href="?page=<?= $i ?><?= $search ? '&search=' . urlencode($search) : '' ?>"><?= $i ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?= $page + 1 ?><?= $search ? '&search=' . urlencode($search) : '' ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3 style="color: #666; margin-bottom: 0.5rem;">
                            <?= empty($search) ? 'Belum ada user yang terdaftar' : 'User tidak ditemukan' ?>
                        </h3>
                        <p style="color: #999;">
                            <?= empty($search) ? 'User akan muncul di sini setelah mereka mendaftar' : 'Coba kata kunci pencarian yang berbeda' ?>
                        </p>
                        <?php if (empty($search)): ?>
                            <button class="btn btn-success" onclick="openAddModal()" style="margin-top: 1rem;">
                                <i class="fas fa-plus"></i> Tambah User Manual
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay" onclick="closeMobileSidebar()"></div>

    <!-- Add/Edit User Modal -->
    <div class="modal" id="userModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Tambah User</h3>
                <button type="button" onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="userForm" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" id="formAction" value="add">
                    <input type="hidden" name="user_id" id="userId">
                    
                    <div class="form-group">
                        <label class="form-label">Foto Profil</label>
                        <input type="file" name="foto_profil" id="fotoProfil" class="form-control" accept="image/*" onchange="previewPhoto(this)">
                        <small style="color: #666;">Format: JPG, JPEG, PNG, GIF. Maksimal 2MB</small>
                        
                        <!-- Current Photo Preview -->
                        <div id="currentPhotoPreview" style="margin-top: 1rem; display: none;">
                            <label style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">Foto Saat Ini:</label>
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <img id="currentPhoto" src="" alt="Current Photo" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #e9ecef;">
                                <div>
                                    <div style="font-size: 0.9rem; color: #333; font-weight: 500;">Foto Profil Aktif</div>
                                    <div style="font-size: 0.8rem; color: #666;">Pilih file baru untuk mengubah</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- New Photo Preview -->
                        <div id="newPhotoPreview" style="margin-top: 1rem; display: none;">
                            <label style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">Preview Foto Baru:</label>
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <img id="newPhoto" src="" alt="New Photo" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #0052cc;">
                                <div>
                                    <div style="font-size: 0.9rem; color: #0052cc; font-weight: 500;">Foto Baru</div>
                                    <div style="font-size: 0.8rem; color: #666;">Akan mengganti foto lama</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Username *</label>
                        <input type="text" name="username" id="username" class="form-control" required onblur="checkUsername()">
                        <div id="usernameMessage" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" id="email" class="form-control" required onblur="checkEmail()">
                        <div id="emailMessage" class="validation-message"></div>
                    </div>
                    
                    <div class="form-group" id="passwordGroup">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" id="password" class="form-control" required>
                        <small style="color: #666;">Minimal 6 karakter</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Nama Lengkap *</label>
                        <input type="text" name="nama_lengkap" id="namaLengkap" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">No. Telepon</label>
                        <input type="tel" name="no_telepon" id="noTelepon" class="form-control" placeholder="08xxxxxxxxxx">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Alamat</label>
                        <textarea name="alamat" id="alamat" class="form-control" rows="3" placeholder="Alamat lengkap..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closeModal()" class="btn" style="background: #6c757d; color: white;">Batal</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View User Modal -->
    <div class="modal" id="viewModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Detail User</h3>
                <button type="button" onclick="closeViewModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="viewModalBody">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <!-- Profile Gallery Modal -->
    <div class="modal" id="profileGalleryModal">
        <div class="modal-content" style="max-width: 800px;">
            <div class="modal-header">
                <h3><i class="fas fa-images"></i> Galeri Foto Profil User</h3>
                <button type="button" onclick="closeProfileGallery()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body" id="profileGalleryBody">
                <!-- Content will be loaded dynamically -->
            </div>
        </div>
    </div>

    <script>
        // Sidebar functionality
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');

        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });

        mobileSidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('mobile-open');
            mobileOverlay.classList.add('active');
        });

        function closeMobileSidebar() {
            sidebar.classList.remove('mobile-open');
            mobileOverlay.classList.remove('active');
        }

        // Load sidebar state
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        // Admin dropdown
        function toggleAdminDropdown() {
            const dropdown = document.getElementById('adminDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.getElementById('adminDropdown');
            const toggle = document.querySelector('.admin-dropdown-toggle');
            
            if (toggle && !toggle.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });

        // Modal functions
        function openAddModal() {
            document.getElementById('modalTitle').textContent = 'Tambah User';
            document.getElementById('formAction').value = 'add';
            document.getElementById('userForm').reset();
            document.getElementById('userId').value = '';
            
            // Show password field for add
            document.getElementById('passwordGroup').style.display = 'block';
            document.getElementById('password').required = true;
            
            // Hide current photo preview
            document.getElementById('currentPhotoPreview').style.display = 'none';
            document.getElementById('newPhotoPreview').style.display = 'none';
            
            // Clear validation messages
            clearValidationMessages();
            
            document.getElementById('userModal').classList.add('show');
        }

        function editUser(userId) {
            document.getElementById('modalTitle').textContent = 'Edit User';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('userId').value = userId;
            
            // Hide password field for edit
            document.getElementById('passwordGroup').style.display = 'none';
            document.getElementById('password').required = false;
            
            // Hide current photo preview and new photo preview
            document.getElementById('currentPhotoPreview').style.display = 'none';
            document.getElementById('newPhotoPreview').style.display = 'none';
            
            // Clear validation messages
            clearValidationMessages();
            
            // Fetch user data
            fetch(`users.php?ajax=get_user&id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        document.getElementById('username').value = data.username || '';
                        document.getElementById('email').value = data.email || '';
                        document.getElementById('namaLengkap').value = data.nama_lengkap || '';
                        document.getElementById('noTelepon').value = data.no_telepon || '';
                        document.getElementById('alamat').value = data.alamat || '';
                        
                        // Show current photo if exists
                        if (data.foto_profil) {
                            document.getElementById('currentPhoto').src = `../assets/images/profiles/${data.foto_profil}`;
                            document.getElementById('currentPhotoPreview').style.display = 'block';
                        } else {
                            document.getElementById('currentPhotoPreview').style.display = 'none';
                        }
                        
                        document.getElementById('userModal').classList.add('show');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Gagal mengambil data user');
                });
        }

        function viewUser(userId) {
            // Fetch user data and stats
            Promise.all([
                fetch(`users.php?ajax=get_user&id=${userId}`).then(r => r.json()),
                fetch(`users.php?ajax=get_user_stats&id=${userId}`).then(r => r.json())
            ])
            .then(([userData, userStats]) => {
                const modalBody = document.getElementById('viewModalBody');
                modalBody.innerHTML = `
                    <div style="display: grid; gap: 1.5rem;">
                        <div style="text-align: center;">
                            <div style="width: 100px; height: 100px; background: linear-gradient(135deg, #667eea, #764ba2); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem; color: white; font-size: 2.5rem; overflow: hidden;">
                                ${userData.foto_profil ? 
                                    `<img src="../assets/images/profiles/${userData.foto_profil}" alt="${userData.nama_lengkap}" style="width: 100%; height: 100%; object-fit: cover;">` :
                                    `<i class="fas fa-user"></i>`
                                }
                            </div>
                            <h4 style="margin-bottom: 0.5rem; color: #333;">${userData.nama_lengkap}</h4>
                            <p style="color: #666; margin-bottom: 1rem;">@${userData.username}</p>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                            <div style="text-align: center; padding: 1rem; background: #f8f9fa; border-radius: 8px;">
                                <div style="font-size: 1.5rem; font-weight: bold; color: #0052cc;">${userStats.favorites_count}</div>
                                <div style="font-size: 0.8rem; color: #666;">Favorit</div>
                            </div>
                            <div style="text-align: center; padding: 1rem; background: #f8f9fa; border-radius: 8px;">
                                <div style="font-size: 1.5rem; font-weight: bold; color: #0052cc;">${userStats.searches_count}</div>
                                <div style="font-size: 0.8rem; color: #666;">Pencarian</div>
                            </div>
                        </div>
                        
                        <div>
                            <h5 style="margin-bottom: 1rem; color: #333;">Informasi Kontak</h5>
                            <div style="display: grid; gap: 0.75rem;">
                                <div style="display: flex; align-items: center; gap: 0.75rem;">
                                    <i class="fas fa-envelope" style="width: 20px; color: #0052cc;"></i>
                                    <span>${userData.email}</span>
                                </div>
                                ${userData.no_telepon ? `
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <i class="fas fa-phone" style="width: 20px; color: #0052cc;"></i>
                                        <span>${userData.no_telepon}</span>
                                    </div>
                                ` : ''}
                                ${userData.alamat ? `
                                    <div style="display: flex; align-items: flex-start; gap: 0.75rem;">
                                        <i class="fas fa-map-marker-alt" style="width: 20px; color: #0052cc; margin-top: 0.25rem;"></i>
                                        <span>${userData.alamat}</span>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                        
                        <div>
                            <h5 style="margin-bottom: 1rem; color: #333;">Informasi Akun</h5>
                            <div style="display: grid; gap: 0.75rem;">
                                <div style="display: flex; align-items: center; gap: 0.75rem;">
                                    <i class="fas fa-calendar" style="width: 20px; color: #0052cc;"></i>
                                    <span>Bergabung: ${new Date(userData.created_at).toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric'})}</span>
                                </div>
                                ${userStats.last_search ? `
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <i class="fas fa-clock" style="width: 20px; color: #0052cc;"></i>
                                        <span>Terakhir aktif: ${new Date(userStats.last_search).toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'})}</span>
                                    </div>
                                ` : `
                                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                                        <i class="fas fa-clock" style="width: 20px; color: #999;"></i>
                                        <span style="color: #999;">Belum pernah melakukan pencarian</span>
                                    </div>
                                `}
                            </div>
                        </div>
                    </div>
                `;
                
                document.getElementById('viewModal').classList.add('show');
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Gagal mengambil data user');
            });
        }

        function closeModal() {
            document.getElementById('userModal').classList.remove('show');
        }

        function closeViewModal() {
            document.getElementById('viewModal').classList.remove('show');
        }

        function closeProfileGallery() {
            document.getElementById('profileGalleryModal').classList.remove('show');
        }

        function viewAllProfiles() {
            // Show loading in modal
            const modalBody = document.getElementById('profileGalleryBody');
            modalBody.innerHTML = `
                <div style="text-align: center; padding: 2rem;">
                    <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: #0052cc;"></i>
                    <p style="margin-top: 1rem;">Memuat foto profil...</p>
                </div>
            `;
            
            document.getElementById('profileGalleryModal').classList.add('show');
            
            // Load all users with photos
            fetch('users.php?ajax=get_all_profiles')
                .then(response => response.text())
                .then(html => {
                    // For demo purposes, let's create the gallery from current user data
                    const users = <?= json_encode($users) ?>;
                    let galleryHTML = `
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem;">
                    `;
                    
                    users.forEach(user => {
                        const photoSrc = user.foto_profil ? 
                            `../assets/images/profiles/${user.foto_profil}` : 
                            null;
                        
                        galleryHTML += `
                            <div style="text-align: center; padding: 1rem; background: #f8f9fa; border-radius: 12px; border: 1px solid #e9ecef;">
                                <div style="width: 120px; height: 120px; margin: 0 auto 1rem; border-radius: 50%; overflow: hidden; border: 3px solid #e9ecef; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center;">
                                    ${photoSrc ? 
                                        `<img src="${photoSrc}" alt="${user.nama_lengkap}" style="width: 100%; height: 100%; object-fit: cover;" onclick="openPhotoModal('${photoSrc}')">` :
                                        `<i class="fas fa-user" style="font-size: 3rem; color: white;"></i>`
                                    }
                                </div>
                                <div style="font-weight: 600; color: #333; margin-bottom: 0.25rem;">${user.nama_lengkap}</div>
                                <div style="font-size: 0.9rem; color: #666; margin-bottom: 0.5rem;">@${user.username}</div>
                                <div style="font-size: 0.8rem; color: #999;">
                                    ${user.foto_profil ? 
                                        `<i class="fas fa-camera" style="color: #28a745;"></i> Ada Foto` :
                                        `<i class="fas fa-user-slash" style="color: #dc3545;"></i> Tidak Ada Foto`
                                    }
                                </div>
                                ${photoSrc ? 
                                    `<button onclick="openPhotoModal('${photoSrc}')" style="margin-top: 0.5rem; padding: 0.25rem 0.75rem; background: #0052cc; color: white; border: none; border-radius: 4px; font-size: 0.8rem; cursor: pointer;">
                                        <i class="fas fa-search-plus"></i> Lihat Besar
                                    </button>` : ''
                                }
                            </div>
                        `;
                    });
                    
                    galleryHTML += '</div>';
                    
                    if (users.length === 0) {
                        galleryHTML = `
                            <div style="text-align: center; padding: 3rem;">
                                <i class="fas fa-users" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
                                <h4 style="color: #666;">Belum ada user terdaftar</h4>
                                <p style="color: #999;">Foto profil akan muncul di sini setelah user mendaftar</p>
                            </div>
                        `;
                    }
                    
                    modalBody.innerHTML = galleryHTML;
                })
                .catch(error => {
                    console.error('Error:', error);
                    modalBody.innerHTML = `
                        <div style="text-align: center; padding: 2rem;">
                            <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: #dc3545;"></i>
                            <p style="margin-top: 1rem; color: #dc3545;">Gagal memuat galeri foto profil</p>
                        </div>
                    `;
                });
        }

        function openPhotoModal(photoSrc) {
            // Create photo modal if not exists
            let photoModal = document.getElementById('photoModal');
            if (!photoModal) {
                photoModal = document.createElement('div');
                photoModal.id = 'photoModal';
                photoModal.className = 'photo-modal';
                photoModal.innerHTML = `
                    <button class="photo-modal-close" onclick="closePhotoModal()">
                        <i class="fas fa-times"></i>
                    </button>
                    <img id="photoModalImg" src="" alt="Profile Photo" style="max-width: 90%; max-height: 90%; object-fit: contain;">
                `;
                document.body.appendChild(photoModal);
            }
            
            document.getElementById('photoModalImg').src = photoSrc;
            photoModal.classList.add('show');
        }

        function closePhotoModal() {
            const photoModal = document.getElementById('photoModal');
            if (photoModal) {
                photoModal.classList.remove('show');
            }
        }

        function deleteUser(userId, userName) {
            if (confirm(`Apakah Anda yakin ingin menghapus user "${userName}"?\n\nTindakan ini akan menghapus semua data terkait termasuk favorit dan riwayat pencarian. Tindakan ini tidak dapat dibatalkan.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="user_id" value="${userId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function resetPassword(userId, userName) {
            if (confirm(`Apakah Anda yakin ingin mereset password untuk user "${userName}"?\n\nPassword baru akan ditampilkan setelah reset.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" value="${userId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Validation functions
        function checkEmail() {
            const email = document.getElementById('email').value;
            const userId = document.getElementById('userId').value || 0;
            const messageElement = document.getElementById('emailMessage');
            
            if (email) {
                fetch(`users.php?ajax=check_email&email=${encodeURIComponent(email)}&id=${userId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            messageElement.textContent = 'Email sudah digunakan';
                            messageElement.className = 'validation-message error';
                            messageElement.style.display = 'block';
                        } else {
                            messageElement.textContent = 'Email tersedia';
                            messageElement.className = 'validation-message success';
                            messageElement.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            } else {
                messageElement.style.display = 'none';
            }
        }

        function checkUsername() {
            const username = document.getElementById('username').value;
            const userId = document.getElementById('userId').value || 0;
            const messageElement = document.getElementById('usernameMessage');
            
            if (username) {
                fetch(`users.php?ajax=check_username&username=${encodeURIComponent(username)}&id=${userId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.exists) {
                            messageElement.textContent = 'Username sudah digunakan';
                            messageElement.className = 'validation-message error';
                            messageElement.style.display = 'block';
                        } else {
                            messageElement.textContent = 'Username tersedia';
                            messageElement.className = 'validation-message success';
                            messageElement.style.display = 'block';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            } else {
                messageElement.style.display = 'none';
            }
        }

        function clearValidationMessages() {
            document.getElementById('emailMessage').style.display = 'none';
            document.getElementById('usernameMessage').style.display = 'none';
        }

        function previewPhoto(input) {
            const newPhotoPreview = document.getElementById('newPhotoPreview');
            const newPhoto = document.getElementById('newPhoto');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    newPhoto.src = e.target.result;
                    newPhotoPreview.style.display = 'block';
                };
                
                reader.readAsDataURL(input.files[0]);
            } else {
                newPhotoPreview.style.display = 'none';
            }
        }

        // Close modals when clicking outside
        document.addEventListener('click', function(event) {
            const userModal = document.getElementById('userModal');
            const viewModal = document.getElementById('viewModal');
            const profileGalleryModal = document.getElementById('profileGalleryModal');
            const photoModal = document.getElementById('photoModal');
            
            if (event.target === userModal) {
                closeModal();
            }
            
            if (event.target === viewModal) {
                closeViewModal();
            }
            
            if (event.target === profileGalleryModal) {
                closeProfileGallery();
            }
            
            if (event.target === photoModal) {
                closePhotoModal();
            }
        });

        // Auto-hide alerts after 5 seconds
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-20px)';
                setTimeout(() => alert.remove(), 300);
            });
        }, 5000);
    </script>
</body>
</html>