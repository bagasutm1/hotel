<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['nama_lengkap'];

// Get date range filter
$date_range = isset($_GET['range']) ? $_GET['range'] : '30';

// Set date conditions based on filter
switch ($date_range) {
    case '7':
        $date_condition = "DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        break;
    case '30':
        $date_condition = "DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
        break;
    case '90':
        $date_condition = "DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)";
        break;
    default:
        $date_condition = "DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
}

// 1. Summary Statistics
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users"))['total'];
$total_hotels = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM hotels WHERE status = 'aktif'"))['total'];
$total_searches = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM search_history WHERE $date_condition"))['total'];
$total_favorites = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM user_favorites"))['total'];

// 2. User registration trend (last 10 days)
$user_trend_sql = "
    SELECT DATE(created_at) as date, COUNT(*) as registrations 
    FROM users 
    WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)
    GROUP BY DATE(created_at) 
    ORDER BY date ASC";
$user_trend_result = mysqli_query($conn, $user_trend_sql);
$user_trend_data = mysqli_fetch_all($user_trend_result, MYSQLI_ASSOC);

// 3. Search trend (last 10 days)
$search_trend_sql = "
    SELECT DATE(created_at) as date, COUNT(*) as searches 
    FROM search_history 
    WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)
    GROUP BY DATE(created_at) 
    ORDER BY date ASC";
$search_trend_result = mysqli_query($conn, $search_trend_sql);
$search_trend_data = mysqli_fetch_all($search_trend_result, MYSQLI_ASSOC);

// 4. Top hotels by favorites
$top_hotels_sql = "
    SELECT h.nama_hotel, h.rating_bintang, h.harga_per_malam, COUNT(uf.id) as favorite_count 
    FROM hotels h 
    LEFT JOIN user_favorites uf ON h.id = uf.hotel_id 
    WHERE h.status = 'aktif'
    GROUP BY h.id 
    ORDER BY favorite_count DESC, h.rating_bintang DESC 
    LIMIT 10";
$top_hotels_result = mysqli_query($conn, $top_hotels_sql);
$top_hotels_data = mysqli_fetch_all($top_hotels_result, MYSQLI_ASSOC);

// 5. Active users (users with searches or favorites)
$active_users_sql = "
    SELECT u.nama_lengkap, u.created_at,
           COUNT(DISTINCT uf.id) as total_favorites,
           COUNT(DISTINCT sh.id) as total_searches
    FROM users u
    LEFT JOIN user_favorites uf ON u.id = uf.user_id
    LEFT JOIN search_history sh ON u.id = sh.user_id
    GROUP BY u.id, u.nama_lengkap, u.created_at
    HAVING (COUNT(DISTINCT uf.id) > 0 OR COUNT(DISTINCT sh.id) > 0)
    ORDER BY (COUNT(DISTINCT uf.id) + COUNT(DISTINCT sh.id)) DESC
    LIMIT 10";
$active_users_result = mysqli_query($conn, $active_users_sql);
$active_users_data = mysqli_fetch_all($active_users_result, MYSQLI_ASSOC);

// 6. Recent activities (last 20)
$recent_activities_sql = "
    (SELECT 'user_register' as type, u.nama_lengkap as title, u.created_at, 'User baru mendaftar' as description 
     FROM users u ORDER BY u.created_at DESC LIMIT 10)
    UNION ALL
    (SELECT 'search' as type, CONCAT('Pencarian oleh ', u.nama_lengkap) as title, sh.created_at, 
     CONCAT(sh.total_hotels_found, ' hotel ditemukan') as description 
     FROM search_history sh 
     JOIN users u ON sh.user_id = u.id 
     ORDER BY sh.created_at DESC LIMIT 10)
    ORDER BY created_at DESC LIMIT 20";
$recent_activities_result = mysqli_query($conn, $recent_activities_sql);
$recent_activities_data = mysqli_fetch_all($recent_activities_result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - SPK Hotel Mataram Admin</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .analytics-container {
            padding: 20px;
        }

        .analytics-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .date-filter {
            display: flex;
            gap: 10px;
        }

        .filter-btn {
            padding: 8px 16px;
            background: white;
            border: 2px solid #e1e5e9;
            border-radius: 6px;
            text-decoration: none;
            color: #495057;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .filter-btn.active {
            background: #0052cc;
            color: white;
            border-color: #0052cc;
        }

        .filter-btn:hover {
            border-color: #0052cc;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #0052cc;
        }

        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #0052cc;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 16px;
            color: #6c757d;
            margin-bottom: 10px;
        }

        .stat-change {
            font-size: 14px;
            color: #28a745;
        }

        .analytics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .analytics-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .card-title {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card-title i {
            color: #0052cc;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th,
        .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e1e5e9;
        }

        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }

        .data-table tr:hover {
            background: #f8f9fa;
        }

        .rating-stars {
            color: #ffc107;
        }

        .trend-chart {
            display: flex;
            align-items: end;
            gap: 5px;
            height: 150px;
            padding: 10px 0;
        }

        .trend-bar {
            background: linear-gradient(180deg, #0052cc, #667eea);
            min-width: 20px;
            border-radius: 3px 3px 0 0;
            position: relative;
            transition: all 0.3s ease;
        }

        .trend-bar:hover {
            opacity: 0.8;
        }

        .trend-label {
            position: absolute;
            bottom: -25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 11px;
            color: #6c757d;
            white-space: nowrap;
        }

        .trend-value {
            position: absolute;
            top: -25px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 11px;
            color: #495057;
            font-weight: 500;
        }

        .activity-timeline {
            max-height: 400px;
            overflow-y: auto;
        }

        .activity-item {
            display: flex;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #e9ecef;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .activity-icon.user {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .activity-icon.search {
            background: rgba(0, 82, 204, 0.1);
            color: #0052cc;
        }

        .activity-content {
            flex: 1;
        }

        .activity-title {
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 3px;
        }

        .activity-description {
            color: #6c757d;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .activity-time {
            color: #adb5bd;
            font-size: 12px;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 3em;
            margin-bottom: 15px;
            opacity: 0.3;
        }

        @media (max-width: 768px) {
            .analytics-header {
                flex-direction: column;
                align-items: stretch;
            }

            .date-filter {
                justify-content: center;
                flex-wrap: wrap;
            }

            .analytics-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span class="logo-text">SPK Hotel Admin</span>
                </div>
            </div>

            <nav class="sidebar-nav">
                <ul class="nav-list">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i>
                            <span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="hotels.php" class="nav-link">
                            <i class="fas fa-building"></i>
                            <span class="nav-text">Kelola Hotel</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="criteria.php" class="nav-link">
                            <i class="fas fa-sliders-h"></i>
                            <span class="nav-text">Kriteria SAW</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="users.php" class="nav-link">
                            <i class="fas fa-users"></i>
                            <span class="nav-text">Kelola User</span>
                        </a>
                    </li>
                    <li class="nav-item active">
                        <a href="analytics.php" class="nav-link">
                            <i class="fas fa-chart-bar"></i>
                            <span class="nav-text">Analytics</span>
                        </a>
                    </li>
                </ul>

                <div class="sidebar-footer">
                    <div class="admin-info">
                        <div class="admin-avatar">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="admin-details">
                            <span class="admin-name"><?= htmlspecialchars($admin_name) ?></span>
                            <span class="admin-role">Administrator</span>
                        </div>
                    </div>
                    <a href="../logout.php" class="logout-btn" title="Logout">
                        <i class="fas fa-sign-out-alt"></i>
                        <span class="nav-text">Logout</span>
                    </a>
                </div>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <header class="topbar">
                <div class="topbar-left">
                    <button class="mobile-sidebar-toggle" id="mobileSidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="page-title">Analytics</h1>
                </div>
                <div class="topbar-right">
                    <div class="topbar-item">
                        <a href="../index.php" class="view-site-btn" target="_blank">
                            <i class="fas fa-external-link-alt"></i>
                            <span>Lihat Website</span>
                        </a>
                    </div>
                </div>
            </header>

            <!-- Analytics Content -->
            <div class="analytics-container">
                <!-- Analytics Header -->
                <div class="analytics-header">
                    <div>
                        <h2>Analisis Data Sistem</h2>
                        <p>Statistik penggunaan sistem rekomendasi hotel</p>
                    </div>
                    
                    <div class="date-filter">
                        <a href="analytics.php?range=7" class="filter-btn <?= $date_range == '7' ? 'active' : '' ?>">7 Hari</a>
                        <a href="analytics.php?range=30" class="filter-btn <?= $date_range == '30' ? 'active' : '' ?>">30 Hari</a>
                        <a href="analytics.php?range=90" class="filter-btn <?= $date_range == '90' ? 'active' : '' ?>">90 Hari</a>
                    </div>
                </div>

                <!-- Summary Statistics -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-number"><?= number_format($total_users) ?></div>
                        <div class="stat-label">Total User Terdaftar</div>
                        <div class="stat-change">
                            <i class="fas fa-users"></i>
                            Semua waktu
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-number"><?= number_format($total_hotels) ?></div>
                        <div class="stat-label">Total Hotel Aktif</div>
                        <div class="stat-change">
                            <i class="fas fa-building"></i>
                            Status aktif
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-number"><?= number_format($total_searches) ?></div>
                        <div class="stat-label">Total Pencarian</div>
                        <div class="stat-change">
                            <i class="fas fa-search"></i>
                            <?= $date_range ?> hari terakhir
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-number"><?= number_format($total_favorites) ?></div>
                        <div class="stat-label">Total Favorit</div>
                        <div class="stat-change">
                            <i class="fas fa-heart"></i>
                            Semua waktu
                        </div>
                    </div>
                </div>

                <!-- Analytics Cards -->
                <div class="analytics-grid">
                    <!-- User Registration Trend -->
                    <div class="analytics-card">
                        <h3 class="card-title">
                            <i class="fas fa-user-plus"></i>
                            Tren Registrasi User (10 Hari)
                        </h3>
                        <?php if (!empty($user_trend_data)) { 
                            $max_reg = max(array_column($user_trend_data, 'registrations'));
                        ?>
                            <div class="trend-chart">
                                <?php foreach ($user_trend_data as $data) { 
                                    $height = $max_reg > 0 ? ($data['registrations'] / $max_reg) * 100 : 0;
                                ?>
                                    <div class="trend-bar" style="height: <?= $height ?>%; flex: 1;">
                                        <div class="trend-value"><?= $data['registrations'] ?></div>
                                        <div class="trend-label"><?= date('d/m', strtotime($data['date'])) ?></div>
                                    </div>
                                <?php } ?>
                            </div>
                        <?php } else { ?>
                            <div class="empty-state">
                                <i class="fas fa-user-plus"></i>
                                <p>Belum ada data registrasi</p>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- Search Trend -->
                    <div class="analytics-card">
                        <h3 class="card-title">
                            <i class="fas fa-search"></i>
                            Tren Pencarian (10 Hari)
                        </h3>
                        <?php if (!empty($search_trend_data)) { 
                            $max_search = max(array_column($search_trend_data, 'searches'));
                        ?>
                            <div class="trend-chart">
                                <?php foreach ($search_trend_data as $data) { 
                                    $height = $max_search > 0 ? ($data['searches'] / $max_search) * 100 : 0;
                                ?>
                                    <div class="trend-bar" style="height: <?= $height ?>%; flex: 1;">
                                        <div class="trend-value"><?= $data['searches'] ?></div>
                                        <div class="trend-label"><?= date('d/m', strtotime($data['date'])) ?></div>
                                    </div>
                                <?php } ?>
                            </div>
                        <?php } else { ?>
                            <div class="empty-state">
                                <i class="fas fa-search"></i>
                                <p>Belum ada data pencarian</p>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- Top Hotels -->
                    <div class="analytics-card">
                        <h3 class="card-title">
                            <i class="fas fa-star"></i>
                            Hotel Terpopuler (Top 10)
                        </h3>
                        <?php if (!empty($top_hotels_data)) { ?>
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Hotel</th>
                                        <th>Rating</th>
                                        <th>Harga</th>
                                        <th>Favorit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($top_hotels_data as $hotel) { ?>
                                    <tr>
                                        <td><?= htmlspecialchars($hotel['nama_hotel']) ?></td>
                                        <td>
                                            <span class="rating-stars">
                                                <?php for ($i = 1; $i <= 5; $i++) { ?>
                                                    <i class="fas fa-star <?= $i <= $hotel['rating_bintang'] ? '' : 'text-muted' ?>" style="<?= $i > $hotel['rating_bintang'] ? 'color: #dee2e6;' : '' ?>"></i>
                                                <?php } ?>
                                            </span>
                                        </td>
                                        <td>Rp <?= number_format($hotel['harga_per_malam'], 0, ',', '.') ?></td>
                                        <td><?= $hotel['favorite_count'] ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        <?php } else { ?>
                            <div class="empty-state">
                                <i class="fas fa-star"></i>
                                <p>Belum ada data favorit hotel</p>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- Active Users -->
                    <div class="analytics-card">
                        <h3 class="card-title">
                            <i class="fas fa-users"></i>
                            User Paling Aktif (Top 10)
                        </h3>
                        <?php if (!empty($active_users_data)) { ?>
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Nama User</th>
                                        <th>Bergabung</th>
                                        <th>Favorit</th>
                                        <th>Pencarian</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($active_users_data as $user) { ?>
                                    <tr>
                                        <td><?= htmlspecialchars($user['nama_lengkap']) ?></td>
                                        <td><?= date('d/m/Y', strtotime($user['created_at'])) ?></td>
                                        <td><?= $user['total_favorites'] ?></td>
                                        <td><?= $user['total_searches'] ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        <?php } else { ?>
                            <div class="empty-state">
                                <i class="fas fa-users"></i>
                                <p>Belum ada user aktif</p>
                            </div>
                        <?php } ?>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="analytics-card">
                    <h3 class="card-title">
                        <i class="fas fa-clock"></i>
                        Aktivitas Terbaru
                    </h3>
                    <?php if (!empty($recent_activities_data)) { ?>
                        <div class="activity-timeline">
                            <?php foreach ($recent_activities_data as $activity) { 
                                $icon_class = $activity['type'] === 'user_register' ? 'user' : 'search';
                                $icon = $activity['type'] === 'user_register' ? 'fa-user-plus' : 'fa-search';
                            ?>
                            <div class="activity-item">
                                <div class="activity-icon <?= $icon_class ?>">
                                    <i class="fas <?= $icon ?>"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title"><?= htmlspecialchars($activity['title']) ?></div>
                                    <div class="activity-description"><?= htmlspecialchars($activity['description']) ?></div>
                                    <div class="activity-time"><?= date('d M Y, H:i', strtotime($activity['created_at'])) ?></div>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    <?php } else { ?>
                        <div class="empty-state">
                            <i class="fas fa-clock"></i>
                            <p>Belum ada aktivitas terbaru</p>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay" onclick="closeMobileSidebar()"></div>

    <script>
        // Simple mobile sidebar toggle
        const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const mobileOverlay = document.getElementById('mobileOverlay');

        mobileSidebarToggle.addEventListener('click', function() {
            sidebar.classList.add('mobile-open');
            mobileOverlay.classList.add('active');
        });

        function closeMobileSidebar() {
            sidebar.classList.remove('mobile-open');
            mobileOverlay.classList.remove('active');
        }

        // Auto refresh every 5 minutes
        setTimeout(() => {
            location.reload();
        }, 300000);
    </script>
</body>
</html>