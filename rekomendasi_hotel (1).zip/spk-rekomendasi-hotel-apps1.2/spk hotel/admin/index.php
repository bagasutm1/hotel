<?php
header('location: dashboard.php')
?>