<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

include '../koneksi.php';

$errors = [];
$success = '';

// Ambil data hotel dan kriteria untuk pilihan dropdown
$hotels = mysqli_query($conn, "SELECT id, nama_hotel FROM hotels WHERE status = 'aktif'");
$criteria = mysqli_query($conn, "SELECT id, nama_kriteria FROM criteria");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hotel_id = intval($_POST['hotel_id']);
    $criteria_id = intval($_POST['criteria_id']);
    $nilai = floatval($_POST['nilai']);

    if ($hotel_id && $criteria_id && $nilai >= 0) {
        $insert_sql = "INSERT INTO hotel_criteria_values (hotel_id, criteria_id, nilai) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt, 'iid', $hotel_id, $criteria_id, $nilai);
        mysqli_stmt_execute($stmt);

        if (mysqli_stmt_affected_rows($stmt) > 0) {
            $success = "Data nilai berhasil ditambahkan.";
        } else {
            $errors[] = "Gagal menambahkan data.";
        }
    } else {
        $errors[] = "Semua kolom wajib diisi dengan benar.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Nilai Hotel - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h3 class="mb-4">Tambah Nilai Hotel per Kriteria</h3>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <div><?= htmlspecialchars($error) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"> <?= htmlspecialchars($success) ?> </div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="hotel_id" class="form-label">Hotel</label>
            <select name="hotel_id" id="hotel_id" class="form-select" required>
                <option value="">-- Pilih Hotel --</option>
                <?php while ($h = mysqli_fetch_assoc($hotels)): ?>
                    <option value="<?= $h['id'] ?>"><?= htmlspecialchars($h['nama_hotel']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="criteria_id" class="form-label">Kriteria</label>
            <select name="criteria_id" id="criteria_id" class="form-select" required>
                <option value="">-- Pilih Kriteria --</option>
                <?php while ($c = mysqli_fetch_assoc($criteria)): ?>
                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nama_kriteria']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="nilai" class="form-label">Nilai</label>
            <input type="number" name="nilai" id="nilai" class="form-control" step="0.01" min="0" required>
        </div>

        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="admin_hotel_criteria_values.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
