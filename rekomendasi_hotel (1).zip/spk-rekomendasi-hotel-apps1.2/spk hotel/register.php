<?php
session_start();
include 'koneksi.php';

// Jika sudah login
if (isset($_SESSION['login'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: dashboard_admin.php');
    } else {
        header('Location: dashboard_user.php');
    }
    exit();
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Ambil & bersihkan input
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $no_telepon = trim($_POST['no_telepon']);
    $alamat = trim($_POST['alamat']);
   $role = isset($_POST['role']) && $_POST['role'] === 'admin'
    ? 'admin'
    : 'user';

    // Validasi
    if ($password !== $confirm_password) {
        $error_message = 'Konfirmasi password tidak cocok!';
    } elseif (strlen($password) < 6) {
        $error_message = 'Password minimal 6 karakter!';
    } else {

        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Query INSERT SESUAI DATABASE
        $sql = "INSERT INTO users 
            (username, email, password, nama_lengkap, no_telepon, alamat, role) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param(
            $stmt,
            "sssssss",
            $username,
            $email,
            $hashed_password,
            $nama_lengkap,
            $no_telepon,
            $alamat,
            $role
        );

        if (mysqli_stmt_execute($stmt)) {
            $success_message = 'Registrasi berhasil! Silakan login.';
        } else {
            $error_message = 'Registrasi gagal! Username atau email sudah digunakan.';
        }
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0194f3 0%, #0066cc 100%);
            padding: 20px;
        }

        .auth-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            overflow: hidden;
            width: 100%;
            max-width: 500px;
            padding: 40px;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .auth-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .auth-logo i {
            font-size: 2.5em;
            color: #0194f3;
        }

        .auth-logo span {
            font-size: 1.8em;
            font-weight: bold;
            color: #2c3e50;
        }

        .auth-title {
            font-size: 1.8em;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .auth-subtitle {
            color: #6c757d;
            font-size: 1em;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e50;
            font-weight: 500;
        }

        .form-input {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e5e9;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-input:focus {
            outline: none;
            border-color: #0194f3;
            box-shadow: 0 0 0 3px rgba(1, 148, 243, 0.1);
        }

        .input-group {
            position: relative;
        }

        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            z-index: 2;
        }

        .input-group .form-input {
            padding-left: 45px;
        }

        .input-group textarea.form-input {
            padding-left: 45px;
            padding-top: 15px;
        }

        .password-strength {
            margin-top: 5px;
            font-size: 12px;
        }

        .strength-meter {
            height: 4px;
            background: #e1e5e9;
            border-radius: 2px;
            margin: 5px 0;
        }

        .strength-fill {
            height: 100%;
            border-radius: 2px;
            transition: all 0.3s ease;
            width: 0%;
        }

        .strength-weak .strength-fill {
            background: #dc3545;
            width: 33%;
        }

        .strength-medium .strength-fill {
            background: #ffc107;
            width: 66%;
        }

        .strength-strong .strength-fill {
            background: #28a745;
            width: 100%;
        }

        .btn-register {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #0194f3 0%, #0066cc 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(1, 148, 243, 0.3);
        }

        .btn-register:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .auth-links {
            text-align: center;
            margin-top: 20px;
        }

        .auth-links a {
            color: #0194f3;
            text-decoration: none;
            font-weight: 500;
        }

        .auth-links a:hover {
            text-decoration: underline;
        }

        .divider {
            text-align: center;
            margin: 20px 0;
            position: relative;
            color: #6c757d;
        }

        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e1e5e9;
        }

        .divider span {
            background: white;
            padding: 0 15px;
        }

        .form-note {
            font-size: 12px;
            color: #6c757d;
            margin-top: 5px;
        }

        @media (max-width: 768px) {
            .auth-card {
                padding: 30px 20px;
                margin: 10px;
            }

            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .auth-logo span {
                font-size: 1.5em;
            }

            .auth-title {
                font-size: 1.5em;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <div class="auth-logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel</span>
                </div>
                <h1 class="auth-title">Buat Akun Baru</h1>
                <p class="auth-subtitle">Daftar untuk mendapatkan rekomendasi hotel terbaik</p>
            </div>

            <?php if ($error_message): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i>
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="registerForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="username" class="form-label">Username *</label>
                        <div class="input-group">
                            <input type="text" id="username" name="username" class="form-input" 
                                   placeholder="Username unik" required minlength="3"
                                   value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                            <i class="fas fa-user"></i>
                        </div>
                        <div class="form-note">Minimal 3 karakter, hanya huruf, angka, dan underscore</div>
                    </div>

                    <div class="form-group">
                        <label for="email" class="form-label">Email *</label>
                        <div class="input-group">
                            <input type="email" id="email" name="email" class="form-input" 
                                   placeholder="email@example.com" required
                                   value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                            <i class="fas fa-envelope"></i>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="nama_lengkap" class="form-label">Nama Lengkap *</label>
                    <div class="input-group">
                        <input type="text" id="nama_lengkap" name="nama_lengkap" class="form-input" 
                               placeholder="Nama lengkap Anda" required
                               value="<?= isset($_POST['nama_lengkap']) ? htmlspecialchars($_POST['nama_lengkap']) : '' ?>">
                        <i class="fas fa-id-card"></i>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="password" class="form-label">Password *</label>
                        <div class="input-group">
                            <input type="password" id="password" name="password" class="form-input" 
                                   placeholder="Minimal 6 karakter" required minlength="6">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="password-strength">
                            <div class="strength-meter">
                                <div class="strength-fill"></div>
                            </div>
                            <span class="strength-text">Masukkan password</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="confirm_password" class="form-label">Konfirmasi Password *</label>
                        <div class="input-group">
                            <input type="password" id="confirm_password" name="confirm_password" class="form-input" 
                                   placeholder="Ulangi password" required minlength="6">
                            <i class="fas fa-lock"></i>
                        </div>
                        <div class="form-note" id="passwordMatch"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="no_telepon" class="form-label">No. Telepon</label>
                    <div class="input-group">
                        <input type="tel" id="no_telepon" name="no_telepon" class="form-input" 
                               placeholder="08xxxxxxxxxx" pattern="[0-9]{10,15}"
                               value="<?= isset($_POST['no_telepon']) ? htmlspecialchars($_POST['no_telepon']) : '' ?>">
                        <i class="fas fa-phone"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label for="alamat" class="form-label">Alamat</label>
                    <div class="input-group">
                        <textarea id="alamat" name="alamat" class="form-input" rows="3" 
                                  placeholder="Alamat lengkap (opsional)"><?= isset($_POST['alamat']) ? htmlspecialchars($_POST['alamat']) : '' ?></textarea>
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                </div>

                <button type="submit" class="btn-register" id="submitBtn">
                    <i class="fas fa-user-plus"></i>
                    Daftar Sekarang
                </button>
            </form>

            <div class="divider">
                <span>atau</span>
            </div>

            <div class="auth-links">
                <p>Sudah punya akun? <a href="login.php">Masuk sekarang</a></p>
                <p><a href="index.php">← Kembali ke Beranda</a></p>
            </div>
        </div>
    </div>

    <script>
        // Password strength checker
        const passwordInput = document.getElementById('password');
        const strengthMeter = document.querySelector('.strength-meter');
        const strengthText = document.querySelector('.strength-text');
        const confirmPasswordInput = document.getElementById('confirm_password');
        const passwordMatchDiv = document.getElementById('passwordMatch');

        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = checkPasswordStrength(password);
            
            strengthMeter.className = 'strength-meter';
            if (strength.score > 0) {
                strengthMeter.classList.add(`strength-${strength.level}`);
            }
            strengthText.textContent = strength.text;
        });

        function checkPasswordStrength(password) {
            let score = 0;
            let text = 'Masukkan password';
            let level = '';

            if (password.length === 0) {
                return { score: 0, text: 'Masukkan password', level: '' };
            }

            // Length check
            if (password.length >= 6) score += 1;
            if (password.length >= 8) score += 1;

            // Character variety checks
            if (/[a-z]/.test(password)) score += 1;
            if (/[A-Z]/.test(password)) score += 1;
            if (/[0-9]/.test(password)) score += 1;
            if (/[^A-Za-z0-9]/.test(password)) score += 1;

            if (score < 3) {
                text = 'Password lemah';
                level = 'weak';
            } else if (score < 5) {
                text = 'Password sedang';
                level = 'medium';
            } else {
                text = 'Password kuat';
                level = 'strong';
            }

            return { score, text, level };
        }

        // Password match checker
        function checkPasswordMatch() {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (confirmPassword.length === 0) {
                passwordMatchDiv.textContent = '';
                passwordMatchDiv.style.color = '#6c757d';
                return true;
            }

            if (password === confirmPassword) {
                passwordMatchDiv.textContent = '✓ Password cocok';
                passwordMatchDiv.style.color = '#28a745';
                return true;
            } else {
                passwordMatchDiv.textContent = '✗ Password tidak cocok';
                passwordMatchDiv.style.color = '#dc3545';
                return false;
            }
        }

        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
        passwordInput.addEventListener('input', checkPasswordMatch);

        // Username validation
        const usernameInput = document.getElementById('username');
        usernameInput.addEventListener('input', function() {
            let value = this.value;
            // Remove invalid characters
            value = value.replace(/[^a-zA-Z0-9_]/g, '');
            if (value !== this.value) {
                this.value = value;
            }
        });

        // Phone number validation
        const phoneInput = document.getElementById('no_telepon');
        phoneInput.addEventListener('input', function() {
            let value = this.value;
            // Remove non-numeric characters
            value = value.replace(/[^0-9]/g, '');
            if (value !== this.value) {
                this.value = value;
            }
        });

        // Form validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const namaLengkap = document.getElementById('nama_lengkap').value.trim();

            // Basic validation
            if (!username || !email || !password || !namaLengkap) {
                e.preventDefault();
                alert('Mohon lengkapi semua field yang wajib diisi!');
                return;
            }

            // Username validation
            if (username.length < 3) {
                e.preventDefault();
                alert('Username minimal 3 karakter!');
                document.getElementById('username').focus();
                return;
            }

            if (!/^[a-zA-Z0-9_]+$/.test(username)) {
                e.preventDefault();
                alert('Username hanya boleh mengandung huruf, angka, dan underscore!');
                document.getElementById('username').focus();
                return;
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Format email tidak valid!');
                document.getElementById('email').focus();
                return;
            }

            // Password validation
            if (password.length < 6) {
                e.preventDefault();
                alert('Password minimal 6 karakter!');
                document.getElementById('password').focus();
                return;
            }

            // Password match validation
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Konfirmasi password tidak cocok!');
                document.getElementById('confirm_password').focus();
                return;
            }

            // Phone validation (if provided)
            const phone = document.getElementById('no_telepon').value.trim();
            if (phone && (phone.length < 10 || phone.length > 15)) {
                e.preventDefault();
                alert('Nomor telepon harus 10-15 digit!');
                document.getElementById('no_telepon').focus();
                return;
            }

            // Disable submit button to prevent double submit
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mendaftar...';
        });

        // Auto-focus username input
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('username').focus();
        });

        // Real-time validation feedback
        document.getElementById('email').addEventListener('blur', function() {
            const email = this.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (email && !emailRegex.test(email)) {
                this.style.borderColor = '#dc3545';
            } else {
                this.style.borderColor = '#e1e5e9';
            }
        });

        document.getElementById('username').addEventListener('blur', function() {
            const username = this.value.trim();
            
            if (username && (username.length < 3 || !/^[a-zA-Z0-9_]+$/.test(username))) {
                this.style.borderColor = '#dc3545';
            } else {
                this.style.borderColor = '#e1e5e9';
            }
        });
    </script>
</body>
</html>