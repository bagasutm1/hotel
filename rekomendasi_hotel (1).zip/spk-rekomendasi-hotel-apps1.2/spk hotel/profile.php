<?php
session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Handle form submission untuk update profil
if (isset($_POST['action']) && $_POST['action'] == 'update_profile') {
    $nama_lengkap = mysqli_real_escape_string($conn, $_POST['nama_lengkap']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $no_telepon = mysqli_real_escape_string($conn, $_POST['no_telepon']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);
    
    // Cek apakah email sudah digunakan user lain
    $check_email = "SELECT id FROM users WHERE email = '$email' AND id != $user_id";
    $email_result = mysqli_query($conn, $check_email);
    
    if (mysqli_num_rows($email_result) > 0) {
        $error_message = "Email sudah digunakan oleh user lain!";
    } else {
        // Handle upload foto profil
        $foto_profil_name = '';
        if (isset($_FILES['foto_profil']) && $_FILES['foto_profil']['error'] == 0) {
            $target_dir = "assets/images/profiles/";
            if (!file_exists($target_dir)) {
                mkdir($target_dir, 0777, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['foto_profil']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
            
            if (in_array($file_extension, $allowed_extensions)) {
                $foto_profil_name = "profile_" . $user_id . "_" . time() . "." . $file_extension;
                $target_file = $target_dir . $foto_profil_name;
                
                if (move_uploaded_file($_FILES['foto_profil']['tmp_name'], $target_file)) {
                    // Hapus foto lama jika ada
                    $old_photo_query = "SELECT foto_profil FROM users WHERE id = $user_id";
                    $old_photo_result = mysqli_query($conn, $old_photo_query);
                    $old_photo = mysqli_fetch_assoc($old_photo_result);
                    
                    if ($old_photo['foto_profil'] && file_exists($target_dir . $old_photo['foto_profil'])) {
                        unlink($target_dir . $old_photo['foto_profil']);
                    }
                } else {
                    $error_message = "Gagal mengupload foto profil!";
                }
            } else {
                $error_message = "Format file tidak didukung! Gunakan JPG, JPEG, PNG, atau GIF.";
            }
        }
        
        if (empty($error_message)) {
            // Update data profil
            if ($foto_profil_name) {
                $update_query = "UPDATE users SET 
                    nama_lengkap = '$nama_lengkap',
                    email = '$email',
                    no_telepon = '$no_telepon',
                    alamat = '$alamat',
                    foto_profil = '$foto_profil_name',
                    updated_at = NOW()
                    WHERE id = $user_id";
            } else {
                $update_query = "UPDATE users SET 
                    nama_lengkap = '$nama_lengkap',
                    email = '$email',
                    no_telepon = '$no_telepon',
                    alamat = '$alamat',
                    updated_at = NOW()
                    WHERE id = $user_id";
            }
            
            if (mysqli_query($conn, $update_query)) {
                $_SESSION['nama_lengkap'] = $nama_lengkap;
                $success_message = "Profil berhasil diperbarui!";
            } else {
                $error_message = "Gagal memperbarui profil!";
            }
        }
    }
}

// Handle form submission untuk update password
if (isset($_POST['action']) && $_POST['action'] == 'update_password') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Ambil password lama dari database
    $check_password_query = "SELECT password FROM users WHERE id = $user_id";
    $password_result = mysqli_query($conn, $check_password_query);
    $user_data = mysqli_fetch_assoc($password_result);
    
    if (!password_verify($current_password, $user_data['password'])) {
        $error_message = "Password lama tidak sesuai!";
    } elseif ($new_password !== $confirm_password) {
        $error_message = "Konfirmasi password tidak sesuai!";
    } elseif (strlen($new_password) < 6) {
        $error_message = "Password baru minimal 6 karakter!";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_password_query = "UPDATE users SET password = '$hashed_password', updated_at = NOW() WHERE id = $user_id";
        
        if (mysqli_query($conn, $update_password_query)) {
            $success_message = "Password berhasil diperbarui!";
        } else {
            $error_message = "Gagal memperbarui password!";
        }
    }
}

// Ambil data user
$user_query = "SELECT * FROM users WHERE id = $user_id";
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - SPK Hotel Mataram</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .profile-container {
            max-width: 800px;
            margin: 120px auto 40px;
            padding: 0 20px;
        }
        
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            padding: 40px;
            color: white;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid rgba(255,255,255,0.3);
            overflow: hidden;
            background: rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .profile-avatar i {
            font-size: 48px;
            color: rgba(255,255,255,0.7);
        }
        
        .profile-header h1 {
            margin: 0 0 10px 0;
            font-size: 2.5em;
            font-weight: 700;
        }
        
        .member-since {
            opacity: 0.9;
            font-size: 1.1em;
        }
        
        .profile-content {
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            border: 1px solid rgba(0,0,0,0.05);
        }
        
        .tabs {
            display: flex;
            border-bottom: 2px solid #e1e1e1;
            margin-bottom: 30px;
        }
        
        .tab {
            padding: 15px 30px;
            background: none;
            border: none;
            cursor: pointer;
            font-weight: 500;
            color: #666;
            transition: all 0.3s ease;
            border-bottom: 3px solid transparent;
            font-size: 16px;
        }
        
        .tab.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e1e1;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .file-upload {
            border: 2px dashed #e1e1e1;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            background: #f8f9fa;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .file-upload:hover {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.05);
        }
        
        .file-upload input[type="file"] {
            display: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 768px) {
            .profile-container {
                margin-top: 100px;
                padding: 0 15px;
            }
            
            .profile-content {
                padding: 25px;
            }
            
            .profile-header {
                padding: 25px;
            }
            
            .tabs {
                flex-direction: column;
            }
            
            .tab {
                padding: 12px 20px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="index.php">Beranda</a>
                    <a href="index.php#hotels">Hotel</a>
                    <a href="favorites.php">Favorit</a>
                    <a href="history.php">Riwayat</a>
                    
                    <div class="user-menu">
                        <div class="user-info" onclick="toggleUserDropdown()">
                            <i class="fas fa-user-circle"></i>
                            <span>Hi, <?= htmlspecialchars($user['nama_lengkap']) ?>!</span>
                            <i class="fas fa-chevron-down dropdown-arrow"></i>
                        </div>
                        <div class="user-dropdown" id="userDropdown">
                            <a href="profile.php" class="active"><i class="fas fa-user"></i> Profil Saya</a>
                            <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                            <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="profile-avatar">
                <?php if ($user['foto_profil'] && file_exists('assets/images/profiles/' . $user['foto_profil'])) { ?>
                    <img src="assets/images/profiles/<?= $user['foto_profil'] ?>" alt="Foto Profil">
                <?php } else { ?>
                    <i class="fas fa-user-circle"></i>
                <?php } ?>
            </div>
            <h1><?= htmlspecialchars($user['nama_lengkap']) ?></h1>
            <p class="member-since">
                <i class="fas fa-calendar-alt"></i>
                Member sejak <?= date('d F Y', strtotime($user['created_at'])) ?>
            </p>
        </div>

        <!-- Alerts -->
        <?php if ($success_message) { ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?= $success_message ?>
            </div>
        <?php } ?>
        
        <?php if ($error_message) { ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?= $error_message ?>
            </div>
        <?php } ?>

        <!-- Profile Content -->
        <div class="profile-content">
            <div class="tabs">
                <button class="tab active" onclick="switchTab('profile-tab', this)">
                    <i class="fas fa-user"></i> Data Profil
                </button>
                <button class="tab" onclick="switchTab('password-tab', this)">
                    <i class="fas fa-lock"></i> Ubah Password
                </button>
            </div>

            <!-- Profile Tab -->
            <div id="profile-tab" class="tab-content active">
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-group">
                        <label>Foto Profil</label>
                        <div class="file-upload" onclick="document.getElementById('foto_profil').click()">
                            <input type="file" name="foto_profil" accept="image/*" id="foto_profil">
                            <i class="fas fa-camera" style="font-size: 2em; margin-bottom: 10px; color: #667eea;"></i>
                            <p>Klik untuk upload foto profil</p>
                            <small>Format: JPG, JPEG, PNG, GIF</small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="nama_lengkap">Nama Lengkap *</label>
                        <input type="text" id="nama_lengkap" name="nama_lengkap" 
                               value="<?= htmlspecialchars($user['nama_lengkap']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" 
                               value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="no_telepon">No. Telepon</label>
                        <input type="tel" id="no_telepon" name="no_telepon" 
                               value="<?= htmlspecialchars($user['no_telepon']) ?>" 
                               placeholder="Contoh: 08123456789">
                    </div>
                    
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <textarea id="alamat" name="alamat" 
                                  placeholder="Masukkan alamat lengkap Anda"><?= htmlspecialchars($user['alamat']) ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-save"></i>
                        Simpan Perubahan
                    </button>
                </form>
            </div>

            <!-- Password Tab -->
            <div id="password-tab" class="tab-content">
                <form method="POST">
                    <input type="hidden" name="action" value="update_password">
                    
                    <div class="form-group">
                        <label for="current_password">Password Lama *</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">Password Baru *</label>
                        <input type="password" id="new_password" name="new_password" required>
                        <small style="color: #666;">Minimal 6 karakter</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Konfirmasi Password Baru *</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>
                    
                    <button type="submit" class="btn-primary">
                        <i class="fas fa-key"></i>
                        Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="logo">
                        <i class="fas fa-hotel"></i>
                        <span>SPK Hotel Mataram</span>
                    </div>
                    <p>Sistem Pendukung Keputusan untuk rekomendasi hotel terbaik di Kota Mataram menggunakan metode SAW.</p>
                </div>
                <div class="footer-section">
                    <h4>Kontak</h4>
                    <p><i class="fas fa-map-marker-alt"></i> Mataram, Nusa Tenggara Barat</p>
                    <p><i class="fas fa-envelope"></i> info@spkhotel.com</p>
                    <p><i class="fas fa-phone"></i> +62 370 123456</p>
                </div>
                <div class="footer-section">
                    <h4>Link Cepat</h4>
                    <ul>
                        <li><a href="index.php">Beranda</a></li>
                        <li><a href="index.php#hotels">Hotel</a></li>
                        <li><a href="favorites.php">Favorit</a></li>
                        <li><a href="history.php">Riwayat</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2025 SPK Hotel Mataram. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Switch tabs function
        function switchTab(tabId, tabElement) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabId).classList.add('active');
            
            // Add active class to clicked tab
            tabElement.classList.add('active');
        }

        // Toggle user dropdown
        function toggleUserDropdown() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');
            
            if (userMenu && !userMenu.contains(event.target)) {
                dropdown?.classList.remove('show');
            }
        });

        // File input preview
        document.getElementById('foto_profil').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const fileUpload = document.querySelector('.file-upload');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    fileUpload.innerHTML = `
                        <img src="${e.target.result}" style="max-width: 150px; max-height: 150px; border-radius: 10px; margin-bottom: 10px;">
                        <p style="color: #28a745; font-weight: 500;">✓ Foto dipilih: ${file.name}</p>
                        <small>Klik "Simpan Perubahan" untuk mengupload</small>
                    `;
                };
                reader.readAsDataURL(file);
            }
        });

        // Header scroll effect
        window.addEventListener('scroll', function() {
            const header = document.querySelector('.header');
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });

        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    alert.style.transform = 'translateY(-20px)';
                    setTimeout(() => {
                        if (alert.parentNode) {
                            alert.parentNode.removeChild(alert);
                        }
                    }, 300);
                }, 5000);
            });
        });

        // Form validation
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitBtn = this.querySelector('button[type="submit"]');
                if (submitBtn) {
                    const originalText = submitBtn.innerHTML;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
                    submitBtn.disabled = true;
                    
                    // Reset button after 10 seconds (fallback)
                    setTimeout(() => {
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    }, 10000);
                }
            });
        });
    </script>
</body>
</html>