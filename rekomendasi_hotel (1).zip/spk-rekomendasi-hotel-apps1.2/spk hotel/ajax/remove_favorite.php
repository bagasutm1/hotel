
<?php
// ajax/remove_favorite.php
header('Content-Type: application/json');
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $hotel_id = (int) $input['hotel_id'];
    $user_id = (int) $input['user_id'];
    
    if ($hotel_id && $user_id) {
        $sql = "DELETE FROM user_favorites WHERE user_id = ? AND hotel_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $user_id, $hotel_id);
        
        if (mysqli_stmt_execute($stmt)) {
            if (mysqli_affected_rows($conn) > 0) {
                echo json_encode(['success' => true, 'message' => 'Hotel dihapus dari favorit']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Hotel tidak ditemukan di favorit']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal menghapus dari favorit']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
}
?>