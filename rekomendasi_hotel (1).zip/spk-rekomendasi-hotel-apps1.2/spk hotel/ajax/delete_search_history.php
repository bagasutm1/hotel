<?php
// ajax/delete_search_history.php
session_start();
header('Content-Type: application/json');
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User tidak login']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$user_id = $_SESSION['user_id'];
$action = $input['action'] ?? '';

if ($action === 'delete_single') {
    // Delete single search history item
    $search_id = (int)($input['search_id'] ?? 0);
    
    if ($search_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'ID pencarian tidak valid']);
        exit();
    }
    
    // Verify that the search belongs to the current user
    $verify_sql = "SELECT id FROM search_history WHERE id = ? AND user_id = ?";
    $verify_stmt = mysqli_prepare($conn, $verify_sql);
    mysqli_stmt_bind_param($verify_stmt, "ii", $search_id, $user_id);
    mysqli_stmt_execute($verify_stmt);
    $verify_result = mysqli_stmt_get_result($verify_stmt);
    
    if (mysqli_num_rows($verify_result) === 0) {
        echo json_encode(['success' => false, 'message' => 'Riwayat pencarian tidak ditemukan atau bukan milik Anda']);
        exit();
    }
    
    // Delete the search history
    $delete_sql = "DELETE FROM search_history WHERE id = ? AND user_id = ?";
    $delete_stmt = mysqli_prepare($conn, $delete_sql);
    mysqli_stmt_bind_param($delete_stmt, "ii", $search_id, $user_id);
    
    if (mysqli_stmt_execute($delete_stmt)) {
        if (mysqli_affected_rows($conn) > 0) {
            echo json_encode(['success' => true, 'message' => 'Riwayat pencarian berhasil dihapus']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Tidak ada data yang dihapus']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal menghapus riwayat pencarian']);
    }
    
    mysqli_stmt_close($delete_stmt);

} elseif ($action === 'delete_all') {
    // Delete all search history for the user
    $delete_all_sql = "DELETE FROM search_history WHERE user_id = ?";
    $delete_all_stmt = mysqli_prepare($conn, $delete_all_sql);
    mysqli_stmt_bind_param($delete_all_stmt, "i", $user_id);
    
    if (mysqli_stmt_execute($delete_all_stmt)) {
        $deleted_count = mysqli_affected_rows($conn);
        echo json_encode([
            'success' => true, 
            'message' => "Semua riwayat pencarian berhasil dihapus ($deleted_count item)",
            'deleted_count' => $deleted_count
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal menghapus semua riwayat pencarian']);
    }
    
    mysqli_stmt_close($delete_all_stmt);

} elseif ($action === 'delete_by_date') {
    // Delete search history by date range
    $start_date = $input['start_date'] ?? '';
    $end_date = $input['end_date'] ?? '';
    
    if (empty($start_date) || empty($end_date)) {
        echo json_encode(['success' => false, 'message' => 'Tanggal tidak valid']);
        exit();
    }
    
    $delete_date_sql = "DELETE FROM search_history WHERE user_id = ? AND DATE(created_at) BETWEEN ? AND ?";
    $delete_date_stmt = mysqli_prepare($conn, $delete_date_sql);
    mysqli_stmt_bind_param($delete_date_stmt, "iss", $user_id, $start_date, $end_date);
    
    if (mysqli_stmt_execute($delete_date_stmt)) {
        $deleted_count = mysqli_affected_rows($conn);
        echo json_encode([
            'success' => true, 
            'message' => "Riwayat pencarian dari $start_date sampai $end_date berhasil dihapus ($deleted_count item)",
            'deleted_count' => $deleted_count
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal menghapus riwayat pencarian berdasarkan tanggal']);
    }
    
    mysqli_stmt_close($delete_date_stmt);

} elseif ($action === 'delete_old') {
    // Delete search history older than specified days
    $days_old = (int)($input['days_old'] ?? 30);
    
    if ($days_old <= 0) {
        echo json_encode(['success' => false, 'message' => 'Jumlah hari tidak valid']);
        exit();
    }
    
    $delete_old_sql = "DELETE FROM search_history WHERE user_id = ? AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
    $delete_old_stmt = mysqli_prepare($conn, $delete_old_sql);
    mysqli_stmt_bind_param($delete_old_stmt, "ii", $user_id, $days_old);
    
    if (mysqli_stmt_execute($delete_old_stmt)) {
        $deleted_count = mysqli_affected_rows($conn);
        echo json_encode([
            'success' => true, 
            'message' => "Riwayat pencarian lebih dari $days_old hari berhasil dihapus ($deleted_count item)",
            'deleted_count' => $deleted_count
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal menghapus riwayat pencarian lama']);
    }
    
    mysqli_stmt_close($delete_old_stmt);

} else {
    echo json_encode(['success' => false, 'message' => 'Aksi tidak dikenali']);
}

mysqli_close($conn);
?>