
<?php
// ajax/get_favorites.php
header('Content-Type: application/json');
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user_id = (int) $_GET['user_id'];
    
    if ($user_id) {
        $sql = "SELECT hotel_id FROM user_favorites WHERE user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        $favorites = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $favorites[] = $row['hotel_id'];
        }
        
        echo json_encode(['success' => true, 'favorites' => $favorites]);
    } else {
        echo json_encode(['success' => false, 'message' => 'User ID tidak valid']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
}
?>