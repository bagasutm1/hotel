<?php
// ajax/add_favorite.php
header('Content-Type: application/json');
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $hotel_id = (int) $input['hotel_id'];
    $user_id = (int) $input['user_id'];
    
    if ($hotel_id && $user_id) {
        // Cek apakah sudah ada di favorit
        $check_sql = "SELECT id FROM user_favorites WHERE user_id = ? AND hotel_id = ?";
        $check_stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($check_stmt, "ii", $user_id, $hotel_id);
        mysqli_stmt_execute($check_stmt);
        $result = mysqli_stmt_get_result($check_stmt);
        
        if (mysqli_num_rows($result) == 0) {
            // Tambah ke favorit
            $sql = "INSERT INTO user_favorites (user_id, hotel_id) VALUES (?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ii", $user_id, $hotel_id);
            
            if (mysqli_stmt_execute($stmt)) {
                echo json_encode(['success' => true, 'message' => 'Hotel ditambahkan ke favorit']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Gagal menambahkan ke favorit']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Hotel sudah ada di favorit']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
}
?>