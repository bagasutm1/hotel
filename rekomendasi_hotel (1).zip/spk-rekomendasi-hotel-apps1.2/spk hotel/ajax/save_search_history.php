<?php
// ajax/save_search_history.php
session_start();
header('Content-Type: application/json');
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User tidak login']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

$user_id = $_SESSION['user_id'];
$search_params = $input['search_params'] ?? [];
$saw_results = $input['saw_results'] ?? [];
$total_hotels_found = (int)($input['total_hotels_found'] ?? 0);

// Validate input
if (empty($search_params) && empty($saw_results)) {
    echo json_encode(['success' => false, 'message' => 'Data pencarian tidak valid']);
    exit();
}

// Convert arrays to JSON
$search_params_json = json_encode($search_params);
$saw_results_json = json_encode($saw_results);

// Insert into search_history table
$sql = "INSERT INTO search_history (user_id, search_params, saw_results, total_hotels_found) VALUES (?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . mysqli_error($conn)]);
    exit();
}

mysqli_stmt_bind_param($stmt, "issi", $user_id, $search_params_json, $saw_results_json, $total_hotels_found);

if (mysqli_stmt_execute($stmt)) {
    $search_id = mysqli_insert_id($conn);
    echo json_encode([
        'success' => true, 
        'message' => 'Riwayat pencarian berhasil disimpan',
        'search_id' => $search_id
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menyimpan riwayat pencarian: ' . mysqli_error($conn)]);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>