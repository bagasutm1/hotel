<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$hotel_id = isset($_GET['hotel_id']) ? (int)$_GET['hotel_id'] : 0;

$sql = "SELECT id, nama_hotel, harga_per_malam, alamat FROM hotels WHERE id = ? AND status = 'aktif'";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $hotel_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$hotel = mysqli_fetch_assoc($result);

if (!$hotel) {
    echo "<script>alert('Hotel tidak ditemukan.'); window.location.href='index.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $tanggal_checkin = $_POST['tanggal_checkin'];
    $tanggal_checkout = $_POST['tanggal_checkout'];
    $jumlah_kamar = (int) $_POST['jumlah_kamar'];

    if (empty($tanggal_checkin) || empty($tanggal_checkout) || $jumlah_kamar <= 0) {
        $error_message = 'Isi semua data dengan benar.';
    } else {
        $insert_sql = "INSERT INTO orders (user_id, hotel_id, tanggal_checkin, tanggal_checkout, jumlah_kamar, created_at) 
                       VALUES (?, ?, ?, ?, ?, NOW())";
        $insert_stmt = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($insert_stmt, "iissi", $user_id, $hotel_id, $tanggal_checkin, $tanggal_checkout, $jumlah_kamar);

        if (mysqli_stmt_execute($insert_stmt)) {
            $success = true;
        } else {
            $error_message = 'Gagal menyimpan pesanan.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pesan Kamar - <?= htmlspecialchars($hotel['nama_hotel']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background: #f2f6fc; }
        .card { border: none; border-radius: 1rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .btn-primary { background-color: #2e86de; border: none; }
        .btn-primary:hover { background-color: #1b4f72; }
        .navbar-custom { background-color: #ffffff; border-bottom: 1px solid #ddd; }
        .navbar-brand span { font-weight: bold; color: #2e86de; }
    </style>
</head>
<body>

<!-- Navbar -->
<header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="index.php">Beranda</a>
                    <a href="index.php#hotels">Hotel</a>
                    <a href="index.php#about">Tentang SAW</a>

                    <?php
                    if (isset($_SESSION['user_id']) || isset($_SESSION['admin_id'])) {
                        $user_name = $_SESSION['nama_lengkap'] ?? 'User';
                        $user_type = $_SESSION['user_type'] ?? 'user';
                    ?>
                        <div class="user-menu">
                            <div class="user-info" onclick="toggleUserDropdown()">
                                <i class="fas fa-user-circle"></i>
                                <span>Hi, <?= htmlspecialchars($user_name) ?>!</span>
                                <i class="fas fa-chevron-down dropdown-arrow"></i>
                            </div>
                            <div class="user-dropdown" id="userDropdown">
                                <?php if ($user_type === 'admin') { ?>
                                    <a href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard Admin</a>
                                <?php } else { ?>
                                    <!-- <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a> -->
                                    <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                                    <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                                <?php } ?>
                                <div class="dropdown-divider"></div>
                                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    <?php
                    } else {
                    ?>
                        <a href="login.php" class="btn-login">Login</a>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>

<!-- Form Pemesanan -->
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <h2 class="text-center mb-4">Formulir Pemesanan Kamar</h2>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success text-center">
                    🎉 Pesanan berhasil! Silakan lihat <a href="history.php">Riwayat Pesanan</a>.
                </div>
            <?php endif; ?>

            <div class="card mb-4">
                <div class="card-body">
                    <h4><?= htmlspecialchars($hotel['nama_hotel']) ?></h4>
                    <p><strong>Alamat:</strong> <?= htmlspecialchars($hotel['alamat']) ?></p>
                    <p><strong>Harga per Malam:</strong> Rp <?= number_format($hotel['harga_per_malam'], 0, ',', '.') ?></p>
                </div>
            </div>

            <form action="" method="POST" class="card p-4">
                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($error_message) ?></div>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="tanggal_checkin" class="form-label">Tanggal Check-In</label>
                    <input type="date" class="form-control" id="tanggal_checkin" name="tanggal_checkin" min="<?= date('Y-m-d') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="tanggal_checkout" class="form-label">Tanggal Check-Out</label>
                    <input type="date" class="form-control" id="tanggal_checkout" name="tanggal_checkout" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                </div>

                <div class="mb-3">
                    <label for="jumlah_kamar" class="form-label">Jumlah Kamar</label>
                    <input type="number" class="form-control" id="jumlah_kamar" name="jumlah_kamar" min="1" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-bed"></i> Pesan Sekarang
                </button>
            </form>

            <div class="text-center mt-4">
                <a href="index.php" class="btn btn-secondary">← Kembali ke Beranda</a>
            </div>
        </div>
    </div>
</div>

<!-- Font Awesome + Bootstrap JS -->
<script src="https://kit.fontawesome.com/a2d02d6a5e.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
