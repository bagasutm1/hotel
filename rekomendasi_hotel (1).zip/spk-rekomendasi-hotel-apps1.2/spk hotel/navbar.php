<header class="header">
        <div class="container">
            <div class="nav">
                <div class="logo">
                    <i class="fas fa-hotel"></i>
                    <span>SPK Hotel Mataram</span>
                </div>
                <div class="nav-links">
                    <a href="index.php">Beranda</a>
                    <a href="index.php#hotels">Hotel</a>
                    <a href="index.php#about">Tentang SAW</a>

                    <?php
                    if (isset($_SESSION['user_id']) || isset($_SESSION['admin_id'])) {
                        $user_name = $_SESSION['nama_lengkap'] ?? 'User';
                        $user_type = $_SESSION['user_type'] ?? 'user';
                    ?>
                        <div class="user-menu">
                            <div class="user-info" onclick="toggleUserDropdown()">
                                <i class="fas fa-user-circle"></i>
                                <span>Hi, <?= htmlspecialchars($user_name) ?>!</span>
                                <i class="fas fa-chevron-down dropdown-arrow"></i>
                            </div>
                            <div class="user-dropdown" id="userDropdown">
                                <?php if ($user_type === 'admin') { ?>
                                    <a href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard Admin</a>
                                <?php } else { ?>
                                    <!-- <a href="profile.php"><i class="fas fa-user"></i> Profil Saya</a> -->
                                    <a href="favorites.php"><i class="fas fa-heart"></i> Favorit Saya</a>
                                    <a href="history.php"><i class="fas fa-history"></i> Riwayat Pencarian</a>
                                <?php } ?>
                                <div class="dropdown-divider"></div>
                                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </div>
                    <?php
                    } else {
                    ?>
                        <a href="login.php" class="btn-login">Login</a>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </header>